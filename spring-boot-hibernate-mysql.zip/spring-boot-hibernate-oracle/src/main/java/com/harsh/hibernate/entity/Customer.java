package com.harsh.hibernate.entity;

import java.util.Date;
import java.util.List;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;

@Entity
//@EntityListeners( { TrackingListener.class }) //no need as worke done by value generator
@Table(name = "CUSTOMER")
@GenericGenerator(name = "SequenceGenerator", strategy = "native", parameters = { @Parameter(name = "sequence", value = "Customer_Seq")})
public class Customer extends BaseEntity<Customer> {

	@Id
	@GeneratedValue(generator = "SequenceGenerator")
	@Column(nullable = false, updatable = false)
	private Long id;
	
	@Embedded
	private CustomerName customerName;
	
	@Column(name="EMAIL")
	private String email;
	
	//bidirectional one to many (no need of extra table)
	@OneToMany(mappedBy = "customer", fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	private Set<Contact> contacts;
	
// DO NOT USE THIS APPROACH AS IT QUERIES FOR EACH COLLECTION
//	@OneToMany(mappedBy = "customer", fetch = FetchType.EAGER, cascade = CascadeType.ALL)
//	@Where(clause = "CONTACT_TYPE = 'MOBILE'")
//	private Set<Contact> mobileContacts;
//	
//	@OneToMany(mappedBy = "customer", fetch = FetchType.EAGER, cascade = CascadeType.ALL)
//	@Where(clause = "CONTACT_TYPE = 'OFFICE'")
//	private Set<Contact> officeContacts;
//	
//	@OneToMany(mappedBy = "customer", fetch = FetchType.EAGER, cascade = CascadeType.ALL)
//	@Where(clause = "CONTACT_TYPE = 'TELEPHONE'")
//	private Set<Contact> otherContacts;
	
	/* 
	 * TemporalType.TIMESTAMP will store date with full time stamp (28-JUL-17 12.17.01.144000000 PM)
	 * TemporalType.DATE will store only hours (28-JUL-17 12.00.00.000000000 AM)
	 * TemporalType.TIME will store only hour,minute and second rest part is 0 (28-JUL-17 12.14.30.000000000 PM)
	*/
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "REGISTERED_DATE")
	@CreationTimestamp
	private Date registerdDate;
	
	//unidirectional one to many (need link table)
	@OneToMany(cascade=CascadeType.ALL, fetch = FetchType.LAZY, orphanRemoval=true)
	@JoinTable(
		name = "customer_address",
		joinColumns = { @JoinColumn(name="customer_id", referencedColumnName="id") },
		inverseJoinColumns = { @JoinColumn(name="address_id", referencedColumnName="id", unique = true) }
	)
	private List<Address> addresses;
	
	@ManyToMany(cascade = { CascadeType.PERSIST, CascadeType.MERGE })
	@JoinTable(name="customer_course",
		joinColumns = { @JoinColumn(name = "customer_id", referencedColumnName = "id") },
		inverseJoinColumns = { @JoinColumn(name = "course_id", referencedColumnName = "id")}
	)
	private List<Course> courses;
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public CustomerName getCustomerName() {
		return customerName;
	}
	public void setCustomerName(CustomerName customerName) {
		this.customerName = customerName;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}	
	public Date getRegisterdDate() {
		return registerdDate;
	}
	public void setRegisterdDate(Date registerdDate) {
		this.registerdDate = registerdDate;
	}
	public Set<Contact> getContacts() {
		return contacts;
	}
	public void setContacts(Set<Contact> contacts) {
		this.contacts = contacts;
	}
	public List<Address> getAddresses() {
		return addresses;
	}
	public void setAddresses(List<Address> addresses) {
		this.addresses = addresses;
	}
	public List<Course> getCourses() {
		return courses;
	}
	public void setCourses(List<Course> courses) {
		this.courses = courses;
	}
	@Override
	public String toString() {
		return "Customer [id=" + id + ", customerName=" + customerName + ", email=" + email + ", contacts=" + contacts
				+ ", registerdDate=" + registerdDate + ", addresses=" + addresses + ", courses=" + courses + "]";
	}
	
}

