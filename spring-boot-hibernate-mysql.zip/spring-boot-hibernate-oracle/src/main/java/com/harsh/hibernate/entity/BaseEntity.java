package com.harsh.hibernate.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.MappedSuperclass;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.GenerationTime;
import org.hibernate.annotations.GeneratorType;
import org.hibernate.annotations.UpdateTimestamp;

import com.harsh.hibernate.basic.Tracking;
import com.harsh.hibernate.generator.LoggedInUserGenerator;

@MappedSuperclass 
public class BaseEntity<T> implements Tracking {

	@Column(name = "CREATED_DATE")
	@CreationTimestamp
	private Date createdDate;
	
	@Column(name = "CREATED_BY")
	@GeneratorType(type = LoggedInUserGenerator.class, when = GenerationTime.INSERT)
	private String createdBy;
	
	@Column(name = "MODIFIED_DATE")
	@UpdateTimestamp
	private Date modifiedDate;

	@Column(name = "MODIFIED_BY")
	@GeneratorType(type = LoggedInUserGenerator.class, when = GenerationTime.ALWAYS)
	private String modifiedBy;

	public Date getCreatedDate() {
		return createdDate;
	}

	@Override
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	@Override
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	@Override
	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Date getModifiedDate() {
		System.out.println("set modified date");
		return modifiedDate;
	}

	@Override
	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	@Override
	public String toString() {
		return "BaseEntity [createdDate=" + createdDate + ", createdBy=" + createdBy + ", modifiedBy=" + modifiedBy
				+ ", modifiedDate=" + modifiedDate + "]";
	}
	
}
