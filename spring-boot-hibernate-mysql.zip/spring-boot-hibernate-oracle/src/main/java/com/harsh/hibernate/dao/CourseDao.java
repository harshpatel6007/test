package com.harsh.hibernate.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.harsh.hibernate.entity.Course;

public interface CourseDao extends JpaRepository<Course, Long>{

}
