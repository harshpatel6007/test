package com.harsh.hibernate.cmdRunner;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.harsh.hibernate.dao.CustomerDao;
import com.harsh.hibernate.entity.Address;
import com.harsh.hibernate.entity.Contact;
import com.harsh.hibernate.entity.Customer;
import com.harsh.hibernate.entity.CustomerName;
import com.harsh.hibernate.enums.ContactType;
import com.harsh.hibernate.enums.ProjectStatus;

//@Component
public class UnidirectionalOneToManyDemo implements CommandLineRunner {
	
	@Autowired
	private CustomerDao customerDao;

	@Override
	@Transactional
	public void run(String... arg0) throws Exception {
		
//		customerDao.findAll().forEach(customer -> {
//			System.out.println("Customer Name " + customer.getCustomerName());
//			System.out.println("Contact size : " + customer.getContacts().size());
//			System.out.println("Address size : " + customer.getAddresses().size());
//		});
		
		customerDao.deleteAll();
		
//		System.out.println("all customers deleted");
//		
//		Customer customer = new Customer();
//		
//		customer.setCustomerName(new CustomerName("Harsh", "Sureshbhai", "Patel", "Munno"));
//		customer.setEmail("harshpatel6007@gmail.com");
//		
//		Contact contact = new Contact();
//		contact.setContactNumber("9874512360");
//		contact.setStatus(ProjectStatus.ACTIVE);
//		contact.setType(ContactType.MOBILE);
//		contact.setCustomer(customer);
//		
//		Contact contact1 = new Contact();
//		contact1.setContactNumber("2289021256");
//		contact1.setStatus(ProjectStatus.ACTIVE);
//		contact1.setType(ContactType.OFFICE);
//		contact1.setCustomer(customer);
//		
//		Set<Contact> contacts = new HashSet<>();
//		contacts.add(contact);
//		contacts.add(contact1);
//
//		customer.setContacts(contacts);
//		
//		Address address = new Address();
//		address.setHouseNumber("A-8");
//		address.setArea("Area 51");
//		address.setCity("Atlanta");
//		address.setCountry("America");
//		address.setState("Texas");
//		address.setStreet("Alien Street");
//		address.setPincode("784512");
//		
//		Address address1 = new Address();
//		address1.setHouseNumber("A-9");
//		address1.setArea("Area 51");
//		address1.setCity("Atlanta");
//		address1.setCountry("America");
//		address1.setState("Texas");
//		address1.setStreet("Alien Street");
//		address1.setPincode("784512");
//		
//		List<Address> addresses = new ArrayList<>();
//		addresses.add(address);
//		addresses.add(address1);
//		
//		customer.setAddresses(addresses);
//		
//		customerDao.save(customer);
//		
//		//remove in unidirectional vs bidirectional
//		
//		//unidirectional - remove entry in customer_address table
//		customer.getAddresses().remove(address);
//		
//		//bidirectional - set customer_id = null in contact
//		contact.setCustomer(null);
		
		System.out.println("customer added");
	}

}
