package com.harsh.hibernate.cmdRunner;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;

import com.harsh.hibernate.dao.AddressDao;
import com.harsh.hibernate.dao.ContactDao;
import com.harsh.hibernate.dao.CustomerDao;
import com.harsh.hibernate.entity.Contact;
import com.harsh.hibernate.entity.Customer;
import com.harsh.hibernate.entity.CustomerName;
import com.harsh.hibernate.enums.ContactType;
import com.harsh.hibernate.enums.ProjectStatus;

public class DefaultRunner implements CommandLineRunner {
	
	@Autowired
	private CustomerDao customerDao;
	
	@Autowired
	private AddressDao addressDao;
	
	@PersistenceContext
	private EntityManager entityManager;
	
	@Autowired
	private ContactDao contactDao;

	@Override
	public void run(String... arg0) throws Exception {

		customerDao.deleteAll();
		
		Customer customer = new Customer();
		
		CustomerName customerName = new CustomerName();
		customerName.setFirstName("First Name - 1");
		customerName.setLastName("Last Name - 1");
		customerName.setSurname("Surname - 1");
		customerName.setNickName("Nickname - 1");
		
		customer.setCustomerName(customerName);
		customer.setEmail("customer5@gmail.com");
		customer.setRegisterdDate(new Date());

		Contact contact = new Contact();
		contact.setContactNumber("9874512360");
		contact.setStatus(ProjectStatus.ACTIVE);
		contact.setType(ContactType.MOBILE);
		contact.setCustomer(customer);
		
		Contact contact1 = new Contact();
		contact1.setContactNumber("2289021256");
		contact1.setStatus(ProjectStatus.ACTIVE);
		contact1.setType(ContactType.OFFICE);
		contact1.setCustomer(customer);
		
		Set<Contact> contacts = new HashSet<>();
		contacts.add(contact);
		contacts.add(contact1);

		customer.setContacts(contacts);
		
		customerDao.save(customer);
		
		//contact.setCustomer(null);
		contactDao.delete(contact);
		
		System.out.println("complete");
//		List<Customer> customers = customerDao.findAll();
//		System.out.println("Customers fetched : " + customers.size());
//		customers.stream().forEach((cust) -> {
//			cust.getContacts().stream().forEach(cont -> {
//				System.out.print("Customer " + cont.getCustomer().getId() + " " + cont.getCustomer().getCustomerName());
//				System.out.println("Contact : " + cont.getType() + " " + cont.getContactNumber());
//			});
//		});
		
//		System.out.println("Customer contact size : " + customer.getContacts().size());
//		entityManager.persist(contact);
//		System.out.println("coontact id : " + contact.getId());
//		entityManager.flush();
//		//SURPRISINGLY THIS SET CUSTOMER_ID TO NULL
//		contact.setCustomer(null);
		
//		Address address = new Address();
//		address.setHouseNumber("A-8");
//		address.setArea("Area 51");
//		address.setCity("Atlanta");
//		address.setCountry("America");
//		address.setState("Texas");
//		address.setStreet("Alien Street");
//		address.setPincode("784512");
//		
//		addressDao.save(address);
		
//		System.out.println("address saved");

	}

}
