package com.harsh.hibernate.entity;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.Transient;

import org.hibernate.annotations.GenericGenerator;

import com.harsh.hibernate.converter.ProjectStatusConverter;
import com.harsh.hibernate.enums.ProjectStatus;

@Entity(name="COURSE")
@GenericGenerator(name="increment", strategy = "increment")
public class Course extends BaseEntity<Course> {

	@Id
	@GeneratedValue(generator = "increment")
	private Long id;
	
	@Column(name="COURSE_NAME")
	private String name;
	
	@Column(name="COURSE_CODE")
	private String code;
	
	@Column(name = "STATUS")
	@Convert(converter = ProjectStatusConverter.class)
	private ProjectStatus status;
	
	@Transient
	private List<String> tags;

	@ManyToMany(mappedBy = "courses")
	private List<Customer> customers;
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public ProjectStatus getStatus() {
		return status;
	}
	public void setStatus(ProjectStatus status) {
		this.status = status;
	}
	public List<String> getTags() {
		return tags;
	}
	public void setTags(List<String> tags) {
		this.tags = tags;
	}
	public List<Customer> getCustomers() {
		return customers;
	}
	public void setCustomers(List<Customer> customers) {
		this.customers = customers;
	}
	
	@Override
	public String toString() {
		return "Course [id=" + id + ", name=" + name + ", code=" + code + ", status=" + status + ", tags=" + tags
				+ ", customers=" + customers + "]";
	}
	
}
