package com.harsh.hibernate.cmdRunner;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import com.harsh.hibernate.dao.CourseDao;
import com.harsh.hibernate.dao.CustomerDao;
import com.harsh.hibernate.entity.Course;
import com.harsh.hibernate.entity.Customer;
import com.harsh.hibernate.entity.CustomerName;
import com.harsh.hibernate.enums.ProjectStatus;

@Component
public class ManyToManyDemo implements CommandLineRunner {

	@Autowired
	private CourseDao courseDao;
	
	@Autowired
	private CustomerDao customerDao;

	@Override
	public void run(String... arg0) throws Exception {
		
		customerDao.deleteAll();
		
		System.out.println("Many to Many demo Start");
		
		Customer customer = new Customer();
		
		customer.setCustomerName(new CustomerName("FN -1", "LN -1", "SN -1", "NN -1"));
		customer.setEmail("email-1@test.com");
		customer.setRegisterdDate(new Date());
		
		Course course1 = new Course();
		course1.setCode("Code-1");
		course1.setName("Name -1");
		course1.setStatus(ProjectStatus.ACTIVE);
		
		Course course2 = new Course();
		course2.setCode("Code-2");
		course2.setName("Name -2");
		course2.setStatus(ProjectStatus.ACTIVE);
		
		Course course3 = new Course();
		course3.setCode("Code-3");
		course3.setName("Name -3");
		course3.setStatus(ProjectStatus.ACTIVE);
		
		List<Course> courses = new ArrayList<>();
		courses.add(course1);
		courses.add(course2);
		courses.add(course3);
		
		customer.setCourses(courses);
		
		customerDao.save(customer);
		
//		courses.remove(0);
//		customer.setCourses(courses);
		
//		courses.get(0).getCustomers().remove(customer);
		
		System.out.println("Complete");
	}
	
	
}
