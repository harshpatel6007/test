package com.harsh.hibernate.cmdRunner;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.harsh.hibernate.dao.CustomerDao;
import com.harsh.hibernate.entity.Customer;

//@Component
public class LazyInitializationError implements CommandLineRunner {
	
	@Autowired
	private CustomerDao customerDao;

	@Override
	@Transactional //remove this to get lazy initialization exception
	public void run(String... arg0) throws Exception {

		List<Customer> customers = customerDao.findAll();
		System.out.println("Customers fetched : " + customers.size());
		customers.stream().forEach((cust) -> {
			System.out.println("address size : " + cust.getAddresses().size());
			
			try {
				Thread.sleep(1000 * 15);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			cust.getContacts().stream().forEach(cont -> {
				System.out.print("Customer " + cont.getCustomer().getId() + " " + cont.getCustomer().getCustomerName());
				System.out.println("Contact : " + cont.getType() + " " + cont.getContactNumber());
			});
		});
	}

}
