package com.harsh.hibernate;

import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.transaction.annotation.Transactional;

import com.harsh.hibernate.dao.AddressDao;
import com.harsh.hibernate.dao.ContactDao;
import com.harsh.hibernate.dao.CustomerDao;
import com.harsh.hibernate.entity.Contact;
import com.harsh.hibernate.entity.Customer;
import com.harsh.hibernate.entity.CustomerName;
import com.harsh.hibernate.enums.ContactType;
import com.harsh.hibernate.enums.ProjectStatus;


@SpringBootApplication
@EnableTransactionManagement
public class SpringBootHibernateOracleApplication {
	
	@Autowired
	private CustomerDao customerDao;
	
	@Autowired
	private AddressDao addressDao;
	
	@PersistenceContext
	private EntityManager entityManager;
	
	@Autowired
	private ContactDao contactDao;
	
//	@Bean
//	public FilterRegistrationBean someFilterRegistration() {
//
//	    FilterRegistrationBean registration = new FilterRegistrationBean();
//	    registration.setFilter(new OpenSessionInViewFilter());
//	    registration.addUrlPatterns("/*");
//	    return registration;
//	} 
	

	public static void main(String[] args) {
		SpringApplication.run(SpringBootHibernateOracleApplication.class, args);
	}
}
