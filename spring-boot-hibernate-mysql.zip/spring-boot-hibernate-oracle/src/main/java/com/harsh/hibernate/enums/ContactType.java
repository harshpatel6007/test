package com.harsh.hibernate.enums;

public enum ContactType {

	MOBILE,
	OFFICE,
	TELEPHONE
	
}
