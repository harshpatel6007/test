package com.harsh.hibernate.entity;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class CustomerName {
	
	@Column(name="FIRST_NAME")
	private String firstName;
	
	@Column(name="LAST_NAME")
	private String lastName;
	
	@Column(name="SURNAME")
	private String surname;
	
	@Column(name="NICK_NAME")
	private String nickName;
	
	public CustomerName() {
		super();
	}
	
	public CustomerName(String firstName, String lastName, String surname, String nickName) {
		this.firstName = firstName;
		this.lastName = lastName;
		this.surname = surname;
		this.nickName = nickName;
	}
	
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getSurname() {
		return surname;
	}
	public void setSurname(String surname) {
		this.surname = surname;
	}
	public String getNickName() {
		return nickName;
	}
	public void setNickName(String nickName) {
		this.nickName = nickName;
	}

	@Override
	public String toString() {
		return "CustomerName [firstName=" + firstName + ", lastName=" + lastName + ", surname=" + surname
				+ ", nickName=" + nickName + "]";
	}
}
