package com.harsh.hibernate.listener;

import java.util.Date;

import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;

import com.harsh.hibernate.basic.Tracking;

public class TrackingListener {

	private final String DEFAULT_USER = "System";
	
	@PrePersist
	public void setCreationDetail(Tracking customer) {
		System.out.println("In base entity listener for insert");
		customer.setCreatedBy(DEFAULT_USER);
		customer.setCreatedDate(new Date());
	}
	
	@PreUpdate
	public void setUpdationDetail(Tracking customer) {
		System.out.println("In base entity listener for update");
		customer.setModifiedBy(DEFAULT_USER);
		customer.setModifiedDate(new Date());
	}
}
