package com.harsh.hibernate.generator;

import org.hibernate.Session;
import org.hibernate.tuple.ValueGenerator;

import com.harsh.hibernate.message.CommonSubstitute;

public class LoggedInUserGenerator implements ValueGenerator<String> {

	@Override
	public String generateValue(Session arg0, Object arg1) {
		System.out.println("passed object : " + arg1);
		return CommonSubstitute.DEFAULT_LOGGED_USER;
	}

}
