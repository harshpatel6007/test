package com.harsh.hibernate.entity;

import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.harsh.hibernate.converter.ProjectStatusConverter;
import com.harsh.hibernate.enums.ContactType;
import com.harsh.hibernate.enums.ProjectStatus;

@Entity
//@EntityListeners( { TrackingListener.class }) //no need as worke done by value generator
@Table(name = "CONTACT")
public class Contact extends BaseEntity<Contact> {

	@Id
	@GeneratedValue()
	private Long id;
	
	@Column(name = "CONTACT_TYPE")
	@Enumerated(EnumType.STRING)
	private ContactType type;
	
	@Column(name = "CONTACT_NUMBER")
	private String contactNumber;
	
	@Column(name = "STATUS")
	@Convert(converter = ProjectStatusConverter.class)
	private ProjectStatus status;
	
	@ManyToOne
	@JoinColumn(name = "CUSTOMER_ID")
	private Customer customer;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public ContactType getType() {
		return type;
	}

	public void setType(ContactType type) {
		this.type = type;
	}

	public String getContactNumber() {
		return contactNumber;
	}

	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}

	public ProjectStatus getStatus() {
		return status;
	}

	public void setStatus(ProjectStatus status) {
		this.status = status;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

}
