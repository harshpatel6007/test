package com.harsh.hibernate.enums;

public enum ProjectStatus {

	ACTIVE('1'),
	INACTIVE('0');
	
	private char statusIndicator;
	
	private ProjectStatus(char indiactor) {
		this.statusIndicator = indiactor;
	}

	public char getStatusIndicator() {
		return statusIndicator;
	}
	
	public static ProjectStatus getStatusFromIndicator(char indicator) {
		for(ProjectStatus status : ProjectStatus.values()) {
			if(status.getStatusIndicator() == indicator) {
				return status;
			}
		}
		return null;
	}
}
