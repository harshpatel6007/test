package com.harsh.hibernate.converter;

import javax.persistence.AttributeConverter;

import com.harsh.hibernate.enums.ProjectStatus;

public class ProjectStatusConverter implements AttributeConverter<ProjectStatus, Character> {

	@Override
	public Character convertToDatabaseColumn(ProjectStatus status) {
		return status.getStatusIndicator();
	}

	@Override
	public ProjectStatus convertToEntityAttribute(Character indicator) {
		return ProjectStatus.getStatusFromIndicator(indicator);
	}

}
