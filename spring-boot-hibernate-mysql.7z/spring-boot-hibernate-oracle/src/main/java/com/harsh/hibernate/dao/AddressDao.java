package com.harsh.hibernate.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.harsh.hibernate.entity.Address;

public interface AddressDao extends JpaRepository<Address, Long> {

}
