package com.harsh.hibernate.basic;

import java.util.Date;

public interface Tracking {

	public void setCreatedDate(Date createdDate);
	public void setCreatedBy(String createdBy);
	public void setModifiedDate(Date modifiedDate);
	public void setModifiedBy(String modifiedBy);
	
}
