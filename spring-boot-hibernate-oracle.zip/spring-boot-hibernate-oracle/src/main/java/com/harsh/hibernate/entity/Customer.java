package com.harsh.hibernate.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;

import com.harsh.hibernate.listener.TrackingListener;

@Entity
@EntityListeners( { TrackingListener.class })
@Table(name = "CUSTOMER")
@GenericGenerator(name = "SequenceGenerator", strategy = "native", parameters = { @Parameter(name = "sequence", value = "Customer_Seq")})
public class Customer extends BaseEntity<Customer> {

	@Id
	@GeneratedValue(generator = "SequenceGenerator")
	@Column(nullable = false, updatable = false)
	private Long id;
	
	@Column(name="CUSTOMERNAME")
	private String customerName;
	
	@Column(name="EMAIL")
	private String email;
	
	
	/* 
	 * TemporalType.TIMESTAMP will store date with full time stamp (28-JUL-17 12.17.01.144000000 PM)
	 * TemporalType.DATE will store only hours (28-JUL-17 12.00.00.000000000 AM)
	 * TemporalType.TIME will store only hour,minute and second rest part is 0 (28-JUL-17 12.14.30.000000000 PM)
	*/
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "REGISTERED_DATE")
	private Date registerdDate;
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}	
	public Date getRegisterdDate() {
		return registerdDate;
	}
	public void setRegisterdDate(Date registerdDate) {
		this.registerdDate = registerdDate;
	}
	
	@Override
	public String toString() {
		return "Customer [id=" + id + ", customerName=" + customerName + ", email=" + email + ", registerdDate="
				+ registerdDate + "]";
	}
	
}

