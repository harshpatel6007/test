package com.harsh.hibernate;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.transaction.annotation.Transactional;

import com.harsh.hibernate.dao.AddressDao;
import com.harsh.hibernate.dao.CustomerDao;
import com.harsh.hibernate.entity.Address;
import com.harsh.hibernate.entity.Customer;


@SpringBootApplication
public class SpringBootHibernateOracleApplication {
	
	@Autowired
	private CustomerDao customerDao;
	
	@Autowired
	private AddressDao addressDao;

	@Bean
	@Transactional
	public CommandLineRunner getBean() {
		
		return new CommandLineRunner() {
			
			@Override
			public void run(String... arg0) throws Exception {
				
//				Customer customer = new Customer();
//				customer.setCustomerName("Customer Name 5");
//				customer.setEmail("customer5@gmail.com");
//				customer.setRegisterdDate(new Date());
//				customerDao.save(customer);
//				
//				System.out.println("customer id : " + customer.getId());
//				
//				System.out.println("Customer List : " + customerDao.findAll().size());
				
//				customer.setCustomerName("Harsh Patel");
//				customer.setEmail("harsh.patel@amdocs.com");
				
//				System.out.println("start sleeping");				
//				Thread.sleep(1000 * 60 * 20);				
				
				Address address = new Address();
				address.setHouseNumber("A-8");
				address.setArea("Area 51");
				address.setCity("Atlanta");
				address.setCountry("America");
				address.setState("Texas");
				address.setStreet("Alien Street");
				address.setPincode("784512");
				
				addressDao.save(address);
				
				System.out.println("address saved");
			}
		};
		
	}
	
	
	public static void main(String[] args) {
		SpringApplication.run(SpringBootHibernateOracleApplication.class, args);
	}
}
