package com.opshub.program;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

/**
 *	Program to convert json string into 
 *	Assumption :
 *		string should be valid json 
 *		No extra Space exists in string
 *		json should consist only { and [ bracket for json object and array  
 *
 */
public class JsonParsing {
	
	private static final char COMA = ',';
	private static final char COLON = ':';
	private static final char OPERNING_CURLY_BRACE = '{';
	private static final char CLOSING_CURLY_BRACE = '}';
	private static final char OPERNING_SQUARE_BRACE = '[';
	private static final char CLOSING_SQUARE_BRACE = ']';

	public static void main(String[] args) {
		String input = "{\"name\":\"Harsh\",\"age\":12,\"single\":true,\"next\":{\"name\":\"student2\",\"age\":13,\"single\":true,\"next\":{\"name\":\"student2\",\"age\":13,\"single\": true}},\"hobbies\":[\"Cricket\",\"Table Tennis\"],\"email\":\"harshpatel6007@gmail.com\",'testing':'IST',\"arrayOfObjects\":[{'name':'test1'},{'name2':'test2'}]}";
//		String input = "[{\"postId\":1,\"id\":1,\"name\":\"id labore ex et quam laborum\",\"email\":\"Eliseo@gardner.biz\",\"body\":\"laudantium enim quasi est quidem magnam voluptate ipsam eostempora quo necessitatibusdolor quam autem quasireiciendis et nam sapiente accusantium\"},{\"postId\":1,\"id\":2,\"name\":\"quo vero reiciendis velit similique earum\",\"email\":\"Jayne_Kuhic@sydney.com\",\"body\":\"est natus enim nihil est dolore omnis voluptatem numquamet omnis occaecati quod ullam atvoluptatem error expedita pariaturnihil sint nostrum voluptatem reiciendis et\"},{\"postId\":1,\"id\":3,\"name\":\"odio adipisci rerum aut animi\",\"email\":\"Nikita@garfield.biz\",\"body\":\"quia molestiae reprehenderit quasi aspernaturaut expedita occaecati aliquam eveniet laudantiumomnis quibusdam delectus saepe quia accusamus maiores nam estcum et ducimus et vero voluptates excepturi deleniti ratione\"},{\"postId\":1,\"id\":4,\"name\":\"alias odio sit\",\"email\":\"Lew@alysha.tv\",\"body\":\"non et atqueoccaecati deserunt quas accusantium unde odit nobis qui voluptatemquia voluptas consequuntur itaque doloret qui rerum deleniti ut occaecati\"},{\"postId\":1,\"id\":5,\"name\":\"vero eaque aliquid doloribus et culpa\",\"email\":\"Hayden@althea.biz\",\"body\":\"harum non quasi et rationetempore iure ex voluptates in rationeharum architecto fugit inventore cupiditatevoluptates magni quo et\"}]";
		System.out.println(JsonPrettyPrinter.printPrettyJson(input));
		System.out.println();
		printPrettyJson(input);
	}

	private static Map<String, String> getMapFromJsonString() {
		
		return null;
	}

	private static void printPrettyJson(String input) {
		
		int curlyBraceCounter = 0;
		String result = ""; 
		boolean isArray = false;
		String key = "";
		String value = ""; 
		Map<String, String> map = new HashMap<>();
		
		
		for(char ch : input.toCharArray()) {		
			
			if (ch == COLON && curlyBraceCounter < 2) {
				key = getKey(result);
				result = "";
			} else if((ch == COMA || ch == CLOSING_CURLY_BRACE) && curlyBraceCounter < 2) {
				if(!isArray) {
					value = result;
					result = "";
					map.put(key, value);
				} else {
					result += new Character(ch).toString();
				}
			} else if(ch == OPERNING_CURLY_BRACE) {
				curlyBraceCounter++;
				result += new Character(ch).toString();
			} else if(ch == CLOSING_CURLY_BRACE) {
				curlyBraceCounter--;
				result += new Character(ch).toString();
			} else {
				result += new Character(ch).toString();
				if(ch == OPERNING_SQUARE_BRACE)
					isArray = true;
				if (ch == CLOSING_SQUARE_BRACE)
					isArray = false;
			}
			
		}
		
		for(Entry<String, String> entry : map.entrySet()) {
			System.out.println(entry.getKey() + " : " + entry.getValue());
		}
		
	}

	private static String getKey(String result) {
		char[] arr = new char[result.length()];
		int counter = 0;
		for(char ch : result.toCharArray()) {
			if(Character.isAlphabetic(ch)) {
				arr[counter] = ch;
			}
			counter++;
		}
		return new String(arr).trim();
	}
	
}
