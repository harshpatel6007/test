package com.opshub.program;

public class JsonPrettyPrinter {

	private static final String TAB = "\t";
	private static final String NEW_LINE = "\n";
	private static final char COMA = ',';
	private static final char OPERNING_CURLY_BRACE = '{';
	private static final char CLOSING_CURLY_BRACE = '}';
	private static final char OPERNING_SQUARE_BRACE = '[';
	private static final char CLOSING_SQUARE_BRACE = ']';
	
	public static String printPrettyJson(String input) {
		
		int curlyBraceCounter = 0;
		String result = ""; 
		boolean isArray = false;
		
		for(char ch : input.toCharArray()) {		
			
			switch(ch) {
				
				case COMA:
					if(isArray) {
						result += new Character(ch).toString();
					} else {
						result += COMA;
						result += getNewLineAndTab(curlyBraceCounter);
					}
					break;
					
				case OPERNING_CURLY_BRACE:
					if(isArray) {
						isArray = false; 
					}
//					result += getNewLineAndTab(curlyBraceCounter);
					result += OPERNING_CURLY_BRACE;
					curlyBraceCounter++;
					result += getNewLineAndTab(curlyBraceCounter);
					break;
					
				case CLOSING_CURLY_BRACE:
					curlyBraceCounter--;
					result += getNewLineAndTab(curlyBraceCounter);
					result += CLOSING_CURLY_BRACE;
					break;
					
				case OPERNING_SQUARE_BRACE:
					isArray = true;
					result += OPERNING_SQUARE_BRACE;
					break;
				
				case CLOSING_SQUARE_BRACE:
					isArray = false;
					result += CLOSING_SQUARE_BRACE;
					break;
				
				default:
					result += new Character(ch).toString();
					break;
			}
		
		}
		return result;
	}
	
	private static String getNewLineAndTab(int counter) {
		String str = NEW_LINE;
		for(int i = 0; i < counter; i++) {
			str += TAB;
		}
		return str;
	}
}
