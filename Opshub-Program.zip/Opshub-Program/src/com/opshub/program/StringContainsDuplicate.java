package com.opshub.program;

/**
 * Algorithm : 
 * 
 * last = 0000 0000 (add shift for character)
 * for a its become 0000 0001
 * for b its become 0000 0010
 * for c its become 0000 0100
 * same for all characters
 * 
 * a = 0(move 1 by 0 shift) 0000 0001 = current,
 * 		current & last = 0000 0000 = 0
 * 		last = last | current = 0000 0001
 * 
 * b = 1(move 1 by 1 shift) 0000 0010 = current,
 * 		current & last = 0000 0000 = 0
 * 		last = last | current = 0000 0011
 * 
 * c = 2(move 1 by 2 shift) 0000 0100 = current,
 * 		current & last = 0000 0000 = 0
 * 		last = last | current = 0000 0111
 * 
 * a = 0(move 1 by 0 shift) 0000 0001 = current,
 *		current $ last =  0000 0001 > 0
 * 		last = last | current = 0000 0111
 *
 */
public class StringContainsDuplicate {

	public static void main(String[] args) {
		
		String input = "mnopqabcdefghijklrstuvwxyz";
		boolean output = containsDuplicate(input);
		System.out.println("String Contains Duplicate ? " + output);
	}

	//Assumption : String only contains lower case characters
	private static boolean containsDuplicate(String input) {
		int last = 0;
		for(char ch : input.toCharArray()) {
			int indexOfChar = ch - 'a';
			int current = 1 << indexOfChar;
			if((current & last) > 0) {
				return true;
			}
			last = last | current;
		}
		return false;
	}
	
}
