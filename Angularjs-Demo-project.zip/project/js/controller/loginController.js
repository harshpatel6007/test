myAppControllers.controller('loginCtrl', function ($scope) {
    $scope.message = "Welcome to login Page";
});