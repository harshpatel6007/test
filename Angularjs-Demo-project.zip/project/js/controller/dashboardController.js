myAppControllers.controller('dashboardCtrl', function ($scope) {
    $scope.dsMessage = "Welcome to dashboard";
});