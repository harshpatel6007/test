var myAppControllers = angular.module('myApp.controllers',[]);
var myAppDirectives = angular.module('myApp.directives', []);