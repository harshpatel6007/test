app.controller("drugAllergyMasterAdd", ['$scope', '$state', 'ajaxService', '$stateParams',
       function ($scope, $state, ajaxService, $stateParams) {
	
	$scope.init = function(){
		$scope.drugAllergyFromData = {};
		$scope.drugAllergyFromData.status = true;
		$scope.id = $stateParams.id;
		$scope.editMode = false;
		if($scope.id != null){
			$scope.getDrugAllergyById($scope.id);
			$scope.editMode = true;
		}
	};
	
	$scope.cancel = function(){
		$state.go('app.drugAllergyMasterView', { reload : false });
	};
	
	$scope.getDrugAllergyById = function(id){
		var getObj = {};
			getObj.id = id;
		ajaxService.firePostRequest('/drugAllergy/get',
				getObj,
				$scope.getEditObjSuccess,
				$scope.getEditObjFailed
		);
	};
	
	$scope.getEditObjFailed = function ( response ) {			
		console.log("error");
	};
	
	$scope.getEditObjSuccess = function ( response ) {
		$scope.drugAllergyFromData =  response.data;
		
		if($scope.drugAllergyFromData.status == "ACTIVE"){
			$scope.drugAllergyFromData.status = true;
		}else{
			$scope.drugAllergyFromData.status = false;
		}
	};
	
	$scope.submit= function(){
		if($scope.drugAllergyFrom.$valid){
		var data = {};
		var URL = "";
		data = $scope.drugAllergyFromData;
		if($scope.editMode){
			$scope.drugAllergyFromData.id = $scope.id;
			URL = '/drugAllergy/update' ;
		} 
		else {
			URL = '/drugAllergy/add';
		}
		if($scope.drugAllergyFromData.status == true){
			data.status = "ACTIVE";
		}else{
			data.status = "INACTIVE";
		}
		ajaxService.firePostRequest(URL,
				data,
				$scope.requestSuccess,
				$scope.requestFailed
		);
		}else{
			$scope.drugAllergyFrom.submitted = true;
		}
	};
	$scope.requestSuccess = function ( response ) {			
		$state.go('app.drugAllergyMasterView');
	};
	
	$scope.requestFailed = function ( response ) {			
		console.log("error");
	};
}]);