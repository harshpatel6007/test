app.controller("documentSubTypeMaterAddCtrl", function($scope, ajaxService, $stateParams, $state){
	
	$scope.documentSubTypeManageInit = function(){
		$scope.id = $stateParams.id;
		$scope.documentSubType = {};
		$scope.documentSubType.status = true;
		$scope.editMode = false;
		if($scope.id != null){
			$scope.getdocumentSubTypeById($scope.id);
			$scope.editMode = true;
		}
		
	};
	
	$scope.getdocumentSubTypeById = function(id){
		var getObj = {};
			getObj.id = id;
		ajaxService.firePostRequest('/documentSubTypeMaster/get',
				getObj,
				$scope.getEditObjSuccess,
				$scope.getEditObjFailed
		);
	};
	
	$scope.getEditObjSuccess = function ( response ) {
		$scope.documentSubType =  response.data;
		
		if($scope.documentSubType.status == "ACTIVE"){
			$scope.documentSubType.status = true;
		}else{
			$scope.documentSubType.status = false;
		}
	};
	
	$scope.getEditObjFailed = function ( response ) {
		console.log("error");
	};
	
	$scope.submit = function(isValid){
		if(isValid){
			var documentSubTypeMasterObj = {};
			var url = '';
			if($scope.editMode){
				$scope.documentSubType.id = $scope.id;
				 url = '/documentSubTypeMaster/update' ;
			}else{
				url = '/documentSubTypeMaster/add' ;
			}
			
			documentSubTypeMasterObj = $scope.documentSubType;
			if($scope.documentSubType.status == true){
				documentSubTypeMasterObj.status = "ACTIVE";
			}else{
				documentSubTypeMasterObj.status = "INACTIVE";
			}
			ajaxService.firePostRequest(url,
					documentSubTypeMasterObj,
					$scope.requestSuccess,
					$scope.requestFailed
			);
		}
	};
	
	$scope.requestSuccess = function ( response ) {	
		$state.go('app.documentSubTypeMasterView');
	};
	
	$scope.requestFailed = function ( response ) {
		$state.go('app.documentSubTypeMasterView');
	};
	
	$scope.canceldocumentSubType = function(){
		$state.go('app.documentSubTypeMasterView');
	};
});