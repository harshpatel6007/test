app.controller("countryMasterViewCtrl", ['$scope', '$state', 'ajaxService', 'modalUtil', 'toaster',
       function ($scope, $state, ajaxService, modalUtil, toaster) {
	$scope.initCountry = function(){
		$scope.countryData = [];
		
		$scope.itemsPerPage = 10;
	    $scope.currentPage = 1;
	    $scope.maxSize = 5;
		
		$scope.searchCriteria_Country = '';
		$scope.search_Country();
		countryMasterMap = {};
	};
	
	$scope.search_Country = function(){
		$scope.countryTable = false;
		var search = {
			key : "name",
			value : $scope.searchCriteria_Country,
			operation  : "or",
		};		

		ajaxService.firePostRequest('/countryMaster/search',
				search,
				$scope.searchSuccess,
				$scope.searchFailed
		);
		
	};
	
	$scope.searchSuccess = function ( response ) {
		if(response.data != null && response.data != ""){
			$scope.countryData = response.data;
			
			$scope.totalItems = $scope.countryData.length;
		    $scope.pageCount = function () {
			     return Math.ceil($scope.countryData.length / $scope.itemsPerPage);
			   };

		   $scope.$watch('currentPage + itemsPerPage', function() {
			     var begin = (($scope.currentPage - 1) * $scope.itemsPerPage),
			         end = begin + $scope.itemsPerPage;
			     	$scope.filteredCountryData = $scope.countryData.slice(begin, end);
			   });
			
			$scope.countryTable = true;
			angular.forEach($scope.countryData, function(value, key){
				countryMasterMap[value.id] = value;
				});
		}else{
			toaster.clear();
	    	toaster.pop('warning', "No Record Found", '');
		}
	};
	
	$scope.searchFailed = function ( response ) {			
	};
	
	$scope.delete_Country = function(countryId){
		var contryObj = countryMasterMap[countryId];
		modalUtil.createModalWithControllerUrl(
					'Confirm', 
				 	'Are you sure you want to delete '+contryObj.name+' record ?',
				 	'countryMasterModalViewCtrl' ,'md', countryId, $scope);
	};
	
}]);

app.controller("countryMasterModalViewCtrl", function($scope, $modalInstance, datas, ajaxService){
	$scope.ok = function(){
		var deleteObj = {};
		deleteObj.id = datas;
		ajaxService.firePostRequest('/countryMaster/delete',
				deleteObj,
				$scope.deleteSuccess,
				$scope.deleteFailed
		);
		$modalInstance.close();
	};
	
	$scope.cancel = function () {
        $modalInstance.dismiss('cancel');
    };
    
    $scope.deleteSuccess = function ( response ) {			
		console.log(response.message);
		$scope.search_Country();
	};
	
	$scope.deleteFailed = function ( response ) {			
		console.log("error");
	};
	
});