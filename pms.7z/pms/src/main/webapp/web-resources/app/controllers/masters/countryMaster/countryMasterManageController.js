app.controller("countryMasterAddCtrl", ['$scope', '$state', '$window', 'ajaxService', '$stateParams', 
       function ($scope, $state, $window, ajaxService, $stateParams) {
	
	$scope.countryManageInit = function(){
		$scope.id = $stateParams.id;
		$scope.country = {};
		$scope.country.status = true;
		
		$scope.editMode = false;
		if($scope.id != null){
			$scope.getcountryById($scope.id);
			$scope.editMode = true;
		}
	};
	
	$scope.getcountryById = function(id){
		var getObj = {};
			getObj.id = id;
		ajaxService.firePostRequest('/countryMaster/get',
				getObj,
				$scope.getEditObjSuccess,
				$scope.getEditObjFailed
		);
	};
	
	$scope.getEditObjSuccess = function ( response ) {
		$scope.country =  response.data;
		
		if($scope.country.status == "ACTIVE"){
			$scope.country.status = true;
		}else{
			$scope.country.status = false;
		}
	};
	
	$scope.getEditObjFailed = function ( response ) {
		console.log("error");
	};
	
	$scope.submit = function(isValid){
		if(isValid){
			var countryMasterObj = {};
			var url = '';
			if($scope.editMode){
				$scope.country.id = $scope.id;
				 url = '/countryMaster/update' ;
			}else{
				url = '/countryMaster/add' ;
			}
			
			countryMasterObj = $scope.country;
			if($scope.country.status == true){
				countryMasterObj.status = "ACTIVE";
			}else{
				countryMasterObj.status = "INACTIVE";
			}
			ajaxService.firePostRequest(url,
					countryMasterObj,
					$scope.requestSuccess,
					$scope.requestFailed
			);
		}
	};
	
	$scope.requestSuccess = function ( response ) {	
		$state.go('app.countryMaster');
	};
	
	$scope.requestFailed = function ( response ) {
		alert(response.message);
		$state.go('app.countryMaster');
	};
	
	$scope.cancelCountry = function(){
		$state.go('app.countryMaster');
	};
}]);