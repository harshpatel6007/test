app.controller("userProfileController", function($scope, $http, ajaxService, $state , toaster, fileUpload, $window){
	$scope.init = function(){
		$scope.editMode = false;
		$scope.userProfileData = {};
		$scope.userPhoto = contextPath+"/user/getPhoto/"+userId;
		$scope.getUser();
	};  
	
	$scope.getUser = function(){
		var getObj = {};
			getObj.id = userId;
		ajaxService.firePostRequest('/user/get',
				getObj,
				$scope.getEditObjSuccess,
				$scope.getEditObjFailed
		);
	};
	
	$scope.getEditObjFailed = function ( response ) {			
		console.log("error");
	};
	
	$scope.getEditObjSuccess = function ( response ) {
		$scope.userProfileData = response.data;
		$scope.userProfileData.role = response.data.role.name;
	};
	
	
	$scope.userUpdateData = function(){
		if($scope.userProfileform.$valid){
		var userObj = {};
			userObj.id = $scope.userProfileData.id;
			userObj.displayName = $scope.userProfileData.displayName;
			userObj.email = $scope.userProfileData.email;
			userObj.phoneno = $scope.userProfileData.phoneno;  
			
		ajaxService.firePostRequest('/user/updateByUser',
				userObj,
				$scope.getUpdateObjSuccess,
				$scope.getUpdateObjFailed
		);
		}else{
			$scope.userProfileform.submitted=true;
		}
	};
	
	$scope.getUpdateObjFailed = function ( response ) {			
		console.log("error");
	};
	
	$scope.getUpdateObjSuccess = function ( response ) {
//		$state.go('app.userProfile');
		$scope.editMode = false;
	};
	
	$scope.submit = function(){
		var file = $scope.myFile;
        var uploadUrl = contextPath+"/user/uploadPhoto";
        fileUpload.uploadFileToUrl(file, uploadUrl);
        window.location.reload(true); 
	};
	
	$scope.callEditMode = function(){
		$scope.editMode = true;
	};
	$scope.cancel = function(){
		$scope.editMode = false;
	};
	
});

app.service('fileUpload', ['$http', function ($http) {
    this.uploadFileToUrl = function(file, uploadUrl){
       var fd = new FormData();
       fd.append('userPhoto', file);
	   fd.append("id", userId);
       $http.post(uploadUrl, fd, {
          transformRequest: angular.identity,
          headers: {'Content-Type': undefined}
       })
       .success(function(){
    	   console.log("Successfully Photo Uploaded");
       })
    
       .error(function(){
    	   console.log("Fail in Photo Uploaded");
       });
    }
 }]);



