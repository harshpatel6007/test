app.controller("occupationView", ['$scope', '$state', 'ajaxService','modalUtil','toaster', '$stateParams',
       function ($scope, $state, ajaxService,modalUtil,toaster, $stateParams) {
	
	$scope.init = function() {
		$scope.occupationFromData = [];
		
		$scope.itemsPerPage = 1;
	    $scope.currentPage = 1;
	    $scope.maxSize = 5;
		
		$scope.searchCriteria_Occupation = '';
		$scope.search_Occupation();
		occupationMap = {};
	};
	
	$scope.search_Occupation = function(){
		$scope.occupationTable = false;
		var search = {
			key : "name",
			value : $scope.searchCriteria_Occupation,
			operation  : "or",
		};		
		ajaxService.firePostRequest('/occupation/search',
				search,
				$scope.searchSuccess,
				$scope.searchFailed
		);
	};
	
	$scope.searchSuccess = function ( response ) {
		if(response.data != null && response.data != ""){
		$scope.occupationFromData = response.data;
		
		$scope.totalItems = $scope.occupationFromData.length;
	    $scope.pageCount = function () {
		     return Math.ceil($scope.occupationFromData.length / $scope.itemsPerPage);
		   };

	   $scope.$watch('currentPage + itemsPerPage', function() {
		     var begin = (($scope.currentPage - 1) * $scope.itemsPerPage),
		         end = begin + $scope.itemsPerPage;
		     	$scope.filteredOccupationFromData = $scope.occupationFromData.slice(begin, end);
		   });
		
		$scope.occupationTable = true;
		angular.forEach($scope.occupationFromData, function(value, key){
			occupationMap[value.id] = value;
			});
		}else{
			toaster.clear();
	    	toaster.pop('warning', "No Record Found", '');
		}
	};
	
	$scope.searchFailed = function ( response ) {			
		console.log("error");
	};
	
	$scope.delete_Occupation = function(occpationId){
		var occupationObj = occupationMap[occpationId];
		modalUtil.createModalWithControllerUrl(
			 	'Confirm', 
			 	'Are you sure you want to delete '+occupationObj.name+' record ?',
			 	'userTypeMasterModalViewCtrl' ,'md', occpationId, $scope);
	};
	
}]);

app.controller("userTypeMasterModalViewCtrl", function($scope, $modalInstance, datas, ajaxService){
	$scope.ok = function(){
		var deleteObj = {};
		deleteObj.id = datas;
		ajaxService.firePostRequest('/occupation/delete',
				deleteObj,
				$scope.deleteSuccess,
				$scope.deleteFailed
		);
		$modalInstance.close();
	};
	
	$scope.cancel = function () {
        $modalInstance.dismiss('cancel');
    };
    
    $scope.deleteSuccess = function ( response ) {			
		$scope.search_Occupation();
	};
	
	$scope.deleteFailed = function ( response ) {			
		console.log("error");
	};
});
