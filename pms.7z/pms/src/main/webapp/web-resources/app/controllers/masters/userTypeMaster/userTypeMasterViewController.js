app.controller("userTypeView", ['$scope', '$state', '$window', 'ajaxService', 'modalUtil', 'toaster','$stateParams',
       function ($scope, $state, $window, ajaxService, modalUtil, toaster, $stateParams) {
	
	$scope.init = function() {
		$scope.userTypeData = [];
		
		$scope.itemsPerPage = 10;
	    $scope.currentPage = 1;
	    $scope.maxSize = 5;
	    
		$scope.searchCriteria_UserType = '';
		$scope.search_UserType();
		userTypeMap = {};
	};
	
	$scope.search_UserType = function(){
		$scope.UserTypeTable = false;
		var search = {
			key : "name",
			value : $scope.searchCriteria_UserType,
			operation  : "or",
		};		
		ajaxService.firePostRequest('/userType/search',
				search,
				$scope.searchSuccess,
				$scope.searchFailed
		);
	};
	
	$scope.searchSuccess = function ( response ) {
		if(response.data != null && response.data != ""){
		$scope.userTypeData = response.data;
		
		
		$scope.totalItems = $scope.userTypeData.length;
	    $scope.pageCount = function () {
		     return Math.ceil($scope.userTypeData.length / $scope.itemsPerPage);
		   };

	   $scope.$watch('currentPage + itemsPerPage', function() {
		     var begin = (($scope.currentPage - 1) * $scope.itemsPerPage),
		         end = begin + $scope.itemsPerPage;
		     	$scope.filteredUserTypeData = $scope.userTypeData.slice(begin, end);
		   });
		
		
		$scope.UserTypeTable = true;
		angular.forEach($scope.userTypeData, function(value, key){
			userTypeMap[value.id] = value;
			});
		}else{
			toaster.clear();
	    	toaster.pop('warning', "No Record Found", '');
		}
	};
	
	$scope.searchFailed = function ( response ) {			
		console.log("error");
	};
	
	$scope.delete_UserType = function(userTypeId){
		var userTypeObj = userTypeMap[userTypeId];
		modalUtil.createModalWithControllerUrl(
			 	'Confirm', 
			 	'Are you sure you want to delete '+userTypeObj.name+' record ?',
			 	'userTypeMasterModalViewCtrl' ,'md', userTypeId, $scope);
	};
	
}]);

app.controller("userTypeMasterModalViewCtrl", function($scope, $modalInstance, datas, ajaxService){
	$scope.ok = function(){
		var deleteObj = {};
		deleteObj.id = datas;
		ajaxService.firePostRequest('/userType/delete',
				deleteObj,
				$scope.deleteSuccess,
				$scope.deleteFailed
		);
		$modalInstance.close();
	};
	
	$scope.cancel = function () {
        $modalInstance.dismiss('cancel');
    };
    
    $scope.deleteSuccess = function ( response ) {			
		$scope.search_UserType();
	};
	
	$scope.deleteFailed = function ( response ) {			
		console.log("error");
	};
});

