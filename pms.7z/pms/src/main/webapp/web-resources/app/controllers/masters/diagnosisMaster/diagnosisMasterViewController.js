app.controller("diagnosisView", ['$scope', '$state', 'ajaxService','toaster', 'modalUtil', '$stateParams',
       function ($scope, $state, ajaxService, toaster, modalUtil, $stateParams) {
	
	$scope.init = function() {
		$scope.diagnosisFromData = [];
		
		$scope.itemsPerPage = 1;
	    $scope.currentPage = 1;
	    $scope.maxSize = 5;
		
		$scope.searchCriteria_Diagnosis = '';
		$scope.search_Diagnosis();
		diagnosisMap = {};
	};
	
	$scope.search_Diagnosis = function(){
		$scope.diagnosisTable = false;
		var search = {
			key : "name",
			value : $scope.searchCriteria_Diagnosis,
			operation  : "or",
		};		
		ajaxService.firePostRequest('/diagnosis/search',
				search,
				$scope.searchSuccess,
				$scope.searchFailed
		);
	};
	
	$scope.searchSuccess = function ( response ) {
		if(response.data != null && response.data != ""){
		$scope.diagnosisFromData = response.data;
		
		$scope.totalItems = $scope.diagnosisFromData.length;
	    $scope.pageCount = function () {
		     return Math.ceil($scope.diagnosisFromData.length / $scope.itemsPerPage);
		   };

	   $scope.$watch('currentPage + itemsPerPage', function() {
		     var begin = (($scope.currentPage - 1) * $scope.itemsPerPage),
		         end = begin + $scope.itemsPerPage;
		     	$scope.filteredDiagnosisFromData = $scope.diagnosisFromData.slice(begin, end);
		   });
		
		$scope.diagnosisTable = true;
		angular.forEach($scope.diagnosisFromData, function(value, key){
			diagnosisMap[value.id] = value;
		});
		}else{
			toaster.clear();
	    	toaster.pop('warning', "No Record Found", '');
		}
	};
	
	$scope.searchFailed = function ( response ) {			
		console.log("error");
	};
	
	$scope.delete_Diagnosis = function(diagnosisId){
		var diagnosisObj = diagnosisMap[diagnosisId];
		modalUtil.createModalWithControllerUrl(
			 	'Confirm', 
			 	'Are you sure you want to delete '+diagnosisObj.name+' record ?',
			 	'diagnosisMasterModalViewCtrl' ,'md', diagnosisId, $scope);
	};
	
}]);
app.controller("diagnosisMasterModalViewCtrl", function($scope, $modalInstance, datas, ajaxService){
	$scope.ok = function(){
		var deleteObj = {};
		deleteObj.id = datas;
		ajaxService.firePostRequest('/diagnosis/delete',
				deleteObj,
				$scope.deleteSuccess,
				$scope.deleteFailed
		);
		$modalInstance.close();
	};
	
	$scope.cancel = function () {
        $modalInstance.dismiss('cancel');
    };
    
    $scope.deleteSuccess = function ( response ) {			
		$scope.search_Diagnosis();
	};
	
	$scope.deleteFailed = function ( response ) {			
		console.log("error");
	};
});