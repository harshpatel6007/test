app.controller("userTypeMasterAdd", ['$scope', '$state', 'ajaxService', '$stateParams',
       function ($scope, $state, ajaxService, $stateParams) {
	
	$scope.init = function(){
		$scope.userFormData = {};
		$scope.userFormData.status = true;
		$scope.id = $stateParams.id;
		$scope.editMode = false;
		if($scope.id != null){
			$scope.getUserById($scope.id);
			$scope.editMode = true;
		}
	};
	
	$scope.cancel = function(){
		$state.go('app.userTypeMasterView', { reload : false });
	};
	
	$scope.getUserById = function(id){
		var getObj = {};
			getObj.id = id;
		ajaxService.firePostRequest('/userType/get',
				getObj,
				$scope.getEditObjSuccess,
				$scope.getEditObjFailed
		);
	};
	
	$scope.getEditObjFailed = function ( response ) {			
		console.log("error");
	};
	
	$scope.getEditObjSuccess = function ( response ) {
		$scope.userFormData =  response.data;
		
		if($scope.userFormData.status == "ACTIVE"){
			$scope.userFormData.status = true;
		}else{
			$scope.userFormData.status = false;
		}
	};
	
	$scope.submit= function(){
		if($scope.userForm.$valid){
			
		var data = {};
		var URL = "";
		data = $scope.userFormData;
		
		if($scope.editMode){
			$scope.userFormData.id = $scope.id;
			URL = '/userType/update' ;
		} 
		else {
			URL = '/userType/add';
		}
		if($scope.userFormData.status == true){
			data.status = "ACTIVE";
		}else{
			data.status = "INACTIVE";
		}
		ajaxService.firePostRequest(URL,
				data,
				$scope.requestSuccess,
				$scope.requestFailed
		);
		}else{
			$scope.userForm.submitted=true;
		}
	};
	$scope.requestSuccess = function ( response ) {			
		$state.go('app.userTypeMasterView');
	};
	
	$scope.requestFailed = function ( response ) {			
		$state.go('app.userTypeMasterView');
	};
}]);