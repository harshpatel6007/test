app.controller("relationMasterAddCtrl", ['$scope', '$state', 'ajaxService', '$stateParams', 
       function ($scope, $state, ajaxService, $stateParams) {
	
	$scope.relationManageInit = function(){
		$scope.id = $stateParams.id;
		$scope.relation = {};
		$scope.relation.status = true;
		$scope.editMode = false;
		if($scope.id != null){
			$scope.getRelationById($scope.id);
			$scope.editMode = true;
		}
	};
	
	$scope.getRelationById = function(id){
		var getObj = {};
			getObj.id = id;
		ajaxService.firePostRequest('/relationMaster/get',
				getObj,
				$scope.getEditObjSuccess,
				$scope.getEditObjFailed
		);
	};
	
	$scope.getEditObjSuccess = function ( response ) {
		$scope.relation =  response.data;
		
		if($scope.relation.status == "ACTIVE"){
			$scope.relation.status = true;
		}else{
			$scope.relation.status = false;
		}
	};
	
	$scope.getEditObjFailed = function ( response ) {
		console.log("error");
	};
	
	$scope.submit = function(isValid){
		if(isValid){
			var relationMasterObj = {};
			var url = '';
			if($scope.editMode){
				$scope.relation.id = $scope.id;
				url = '/relationMaster/update' ;
			}else{
				url = '/relationMaster/add' ;
			}
			
			relationMasterObj = $scope.relation;
			if($scope.relation.status == true){
				relationMasterObj.status = "ACTIVE";
			}else{
				relationMasterObj.status = "INACTIVE";
			}
			ajaxService.firePostRequest(url,
					relationMasterObj,
					$scope.requestSuccess,
					$scope.requestFailed
			);
		}
		
	};
	
	$scope.requestSuccess = function ( response ) {	
		$state.go('app.relationMaster');
	};
	
	$scope.requestFailed = function ( response ) {
		alert(response.message);
		$state.go('app.relationMaster');
	};
	
	$scope.cancelRelation = function (){
		$state.go('app.relationMaster');
	};
}]);