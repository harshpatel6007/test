app.controller("drugAllergyView", ['$scope', '$state', 'ajaxService', 'toaster', 'modalUtil', '$stateParams',
       function ($scope, $state, ajaxService, toaster, modalUtil,  $stateParams) {
	
	$scope.init = function() {
		$scope.drugAllergyFromData = [];
		
		$scope.itemsPerPage = 10;
	    $scope.currentPage = 1;
	    $scope.maxSize = 5;
		
		$scope.searchCriteria_DrugAllergy = '';
		$scope.search_DrugAllergy();
		drugMap = {};
	};
	
	
	$scope.search_DrugAllergy = function(){
		$scope.drugAllergyTable = false;
		var search = {
			key : "name",
			value : $scope.searchCriteria_DrugAllergy,
			operation  : "or",
		};		
		ajaxService.firePostRequest('/drugAllergy/search',
				search,
				$scope.searchSuccess,
				$scope.searchFailed
		);
	};
	
	$scope.searchSuccess = function ( response ) {
		if(response.data != null && response.data != ""){
			$scope.drugAllergyFromData = response.data;
			
			$scope.totalItems = $scope.drugAllergyFromData.length;
		    $scope.pageCount = function () {
			     return Math.ceil($scope.drugAllergyFromData.length / $scope.itemsPerPage);
			   };

		   $scope.$watch('currentPage + itemsPerPage', function() {
			     var begin = (($scope.currentPage - 1) * $scope.itemsPerPage),
			         end = begin + $scope.itemsPerPage;
			     	$scope.filteredDrugAllergyFromData = $scope.drugAllergyFromData.slice(begin, end);
			   });
			
			$scope.drugAllergyTable = true;
			angular.forEach($scope.drugAllergyFromData, function(value, key){
				drugMap[value.id] = value;
			});
		}else{
			toaster.clear();
	    	toaster.pop('warning', "No Record Found", '');
		}
	};
	
	$scope.searchFailed = function ( response ) {			
		console.log("error");
	};
	
	$scope.delete_DrugAllergy = function(drugAllergyId){
		var drugObj = drugMap[drugAllergyId];
		modalUtil.createModalWithControllerUrl(
			 	'Confirm', 
			 	'Are you sure you want to delete '+drugObj.name+' record ?',
			 	'drugAllergyMasterModalViewCtrl' ,'md', drugAllergyId, $scope);
	};
	
}]);

app.controller("drugAllergyMasterModalViewCtrl", function($scope, $modalInstance, datas, ajaxService){
	$scope.ok = function(){
		var deleteObj = {};
		deleteObj.id = datas;
		ajaxService.firePostRequest('/drugAllergy/delete',
				deleteObj,
				$scope.deleteSuccess,
				$scope.deleteFailed
		);
		$modalInstance.close();
	};
	
	$scope.cancel = function () {
        $modalInstance.dismiss('cancel');
    };
    
    $scope.deleteSuccess = function ( response ) {			
		$scope.search_DrugAllergy();
	};
	
	$scope.deleteFailed = function ( response ) {			
		console.log("error");
	};
});
