app.controller("patientTypeMasterAdd", ['$scope', '$state', 'ajaxService', '$stateParams',
       function ($scope, $state, ajaxService, $stateParams) {
	
	$scope.init = function(){
		$scope.patientFormData = {};
		$scope.patientFormData.status = true;
		$scope.id = $stateParams.id;
		$scope.editMode = false;
		if($scope.id != null){
			$scope.getPatientTypeById($scope.id);
			$scope.editMode = true;
		}
		
	};
	
	$scope.cancel = function(){
		$state.go('app.patientTypeMasterView', { reload : false });
	};
	
	$scope.getPatientTypeById = function(id){
		var getObj = {};
			getObj.id = id;
		ajaxService.firePostRequest('/patientType/get',
				getObj,
				$scope.getEditObjSuccess,
				$scope.getEditObjFailed
		);
	};
	
	$scope.getEditObjFailed = function ( response ) {			
		console.log("error");
	};
	
	$scope.getEditObjSuccess = function ( response ) {
		$scope.patientFormData =  response.data;
		
		if($scope.patientFormData.status == "ACTIVE"){
			$scope.patientFormData.status = true;
		}else{
			$scope.patientFormData.status = false;
		}
	};
	
	$scope.submit= function(){
		if($scope.formPatientType.$valid){
		var data = {};
		var URL = "";
		data = $scope.patientFormData;
		
		if($scope.editMode){
			$scope.patientFormData.id = $scope.id;
			URL = '/patientType/update' ;
		} 
		else {
			URL = '/patientType/add';
		}
		if($scope.patientFormData.status == true){
			data.status = "ACTIVE";
		}else{
			data.status = "INACTIVE";
		}
		ajaxService.firePostRequest(URL,
				data,
				$scope.requestSuccess,
				$scope.requestFailed
		);
		}else{
			$scope.formPatientType.submitted = true;
		}
	};
	$scope.requestSuccess = function ( response ) {			
		$state.go('app.patientTypeMasterView', { reload : false });
	};
	
	$scope.requestFailed = function ( response ) {			
		console.log("error");
	};
}]);