'use strict';

app.controller('lockCtrl', ['$scope', '$state', '$window', 'ajaxService', '$rootScope', 
    function ($scope, $state, $window, ajaxService, $rootScope) {
	
		$scope.isError = false;		
		
		$scope.login = function () {
			if(!$scope.user_password) {
				$scope.isError = true;				
				console.log("display error message");
				$scope.errorMessage = "Password must be required";				
			} else {
				this.fireLoginRequest();
			}			
		};
		
		$scope.fireLoginRequest = function () {		
			
			ajaxService.firePostRequest(
					'/user/webLogin',
					this.getUser(),
					$scope.requestSuccess,
					$scope.loginFailed
			);
		};
		
		$scope.getUser = function () {			
			var user = new Object();
			user.userId = $rootScope.displayUserId;
			user.password = $scope.user_password;			
			user.clientDateTime = new Date();
			return user;
		};
		
		$scope.requestSuccess = function ( response ) {			
			$scope.loginSuccess(response["data"]);
		};
		
		$scope.loginSuccess = function ( response ) {
			$window.location.href = '/pms/user/welcome';
		};
		
		$scope.loginFailed = function ( response ) {
			console.log("display error message from server");
			$scope.isError = true;			
			$scope.errorMessage = response["message"];			
		};


	}	
]);