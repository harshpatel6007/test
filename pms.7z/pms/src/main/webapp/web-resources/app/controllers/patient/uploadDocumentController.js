app.controller("uploadDocumentCtrl",  function ($scope, ajaxService, $stateParams, fileUpload, $http) {
	
	$scope.uploadDocumentInit = function(){
		$scope.showForm = false;
	};
	
	$scope.getSubtypeFormData = function(docTypeId){
		$scope.docTypeId = docTypeId;
		var getObj = {};
		getObj.docTypeId = docTypeId;
		ajaxService.firePostRequest('/documentSubTypeMaster/getByDocTypeId',
				getObj,
				$scope.getDocTypeIdSuccess,
				$scope.getDocTypeIdFailed
		);
	};
	
	$scope.getDocTypeIdSuccess = function( response ){
		$scope.documentSubTypeDatas = response.data;
		$scope.uploadDate = new Date();
		$scope.showForm = true;
	};
	
	$scope.uploadFile = function(isValid){
		
		if(isValid){
			var fd = new FormData();
			fd.append('file', $scope.documentFile1);
			fd.append("documentSubTypeId", $scope.documentSubTypeId);
			fd.append("documentTypeId", $scope.docTypeId);
			fd.append("visitId", $stateParams.visit.id);
			console.log("fd >>>" +JSON.stringify(fd));
			$http.post(contextPath+"/visit/uploadScanDocuments", fd, {
				transformRequest: angular.identity,
				headers: {'Content-Type': undefined}
			})
			.success(function( response ){
				console.log("response.data >>>" +JSON.stringify(response.data));
				/*angular.forEach(response.data , function(value, key){
					$scope.getTemplateForDocument(value);
				});*/
			})
			
			.error(function(){
				console.log("Fail in Uploaded");
			});
		}
	};
	
	$scope.getTemplateForDocument = function(scanDocumentObj){
		var scanDoc = scanDocumentObj;
		console.log("scanDoc >>" +JSON.stringify(scanDoc));
		var html = '<td>'+scanDoc.documentSubTypeMaster.name+'</td>'
				+'<td>'+scanDoc.uploadDate+'</td>'
				+'<td>'+scanDoc.documentFileName+'</td>'
				+'<td><button class="btn btn-default" data-ng-click="viewScanDocument('+ scanDoc.uuid +')" type="button" title="View"><i class="glyphicon glyphicon-eye-open"></i></button>'
				+'<button class="btn btn-default" type="button" title="Delete" data-ng-click="deleteScanDocument('+ scanDoc.uuid +')" ><i class="glyphicon glyphicon-trash"></i></button></td>';
			angular.element(document.getElementById('documentTypeDivId')).append($compile(html)($scope));
	};
	
	$scope.viewScanDocument = function(documentDetailUuid){
		
	};
	
	$scope.deleteScanDocument = function(documentDetailUuid){
		
	};
	
});

app.service('fileUpload', ['$http', function ($http) {
    this.uploadFileToUrl = function(file,scanObj ,visitId ,uploadUrl){
       var fd = new FormData();
       fd.append('file', file);
	   fd.append("scanDocumentDetails", scanObj);
	   fd.append("visitId", visitId);
       $http.post(uploadUrl, fd, {
          transformRequest: angular.identity,
          headers: {'Content-Type': undefined}
       })
       .success(function(){
    	   console.log("Successfully Uploaded");
       })
    
       .error(function(){
    	   console.log("Fail in Uploaded");
       });
    };
 }]);