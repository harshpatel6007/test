/**
 * 
 */
app.controller("commonViewCtrl", ['$scope', 'ajaxService', '$stateParams',
    
    function ($scope, ajaxService, $stateParams) {
		
		$scope.patientDetail; 
		
		$scope.getPatient = function () {
			ajaxService.firePostRequest(
					'/patient/getPatientDetail',
					$stateParams.patientId,
					$scope.displayPatient					
			);
		};
		
		$scope.displayPatient = function ( response ) {
			$scope.patientDetail = response["data"];
			console.log("patientDetail : " + $scope.patientDetail);
		};
		
		$scope.getPatientAgeYear = function (birthDate) {
			birthDate = new Date(birthDate); 
			var today = new Date();
			var age = today.getFullYear() - birthDate.getFullYear();
		    var m = today.getMonth() - birthDate.getMonth();
		    if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) 
		    {
		        age--;
		    }
		    return age;
		};
		
		$scope.getPatientAgeMonth = function (birthDate) {
			birthDate = new Date(birthDate);
			var today = new Date();			
		    var month = today.getMonth() - birthDate.getMonth();
		    var days = today.getDate() - birthDate.getDate();	
		    
		    if(month > 0) {
		    	if (days < 0 || (days === 0 && today.getTime() < birthDate.getTime())) 
			    {
			        month--;
			    }
		    } else {
		    	month = 12 + month;
		    }
		    
		    return month;
		};
		
		$scope.getPatientAgeDays = function (birthDate) {
			birthDate = new Date(birthDate);
			var today = new Date();
			var days = today.getDate() - birthDate.getDate();
		    return Math.abs(days); 
		};
		
		$scope.getVisitTimeDiff = function (visitTime) {
			var visitDate = new Date(visitTime);
			var today = new Date();
			
			var yearDiff = today.getFullYear() - visitDate.getFullYear();
			if(yearDiff > 0) {
				return yearDiff +  " yrs ago";
			}
			
			var monthDiff = today.getMonth() - visitDate.getMonth();
			
			if(monthDiff > 0) {
				return monthDiff + " months ago";
			}
			
			var dayDiff = today.getDate() - visitDate.getDate();
			if(dayDiff > 0) {
				return dayDiff + " days ago";
			}
			
			var hrDiff = today.getHours() - visitDate.getHours();
			if(hrDiff > 0) {
				return hrDiff + " hours ago";
			}
			
			var minDiff = today.getMinutes() - visitDate.getMinutes();
			if(minDiff > 0) {
				return minDiff + " minutes ago";
			}
			
			return "just created";
		};
		
	}
]);