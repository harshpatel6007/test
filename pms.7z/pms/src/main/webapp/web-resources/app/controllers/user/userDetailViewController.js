app.controller("userDetailViewController", function($scope, $http, ajaxService, $state, $stateParams){
	$scope.init = function(){
		$scope.userFormData = {};
		$scope.id = $stateParams.id;
		if($scope.id != null){
			$scope.getUserById($scope.id);
		}
	};
	
	$scope.getUserById = function(id){
		var getObj = {};
			getObj.id = id;
		ajaxService.firePostRequest('/user/get',
				getObj,
				$scope.getEditObjSuccess,
				$scope.getEditObjFailed
		);
	};
	
	$scope.getEditObjFailed = function ( response ) {			
		console.log("error");
	};
	
	$scope.getEditObjSuccess = function ( response ) {
		$scope.userFormData =  response.data;
	};
	
	$scope.back = function(){
		$state.go('app.userView');
	};
	
});


		