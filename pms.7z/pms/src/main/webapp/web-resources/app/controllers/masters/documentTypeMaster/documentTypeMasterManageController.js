app.controller("documentTypeMaterAddCtrl", function($scope, ajaxService, $state, $stateParams){
	
	$scope.documentTypeManageInit = function(){
		$scope.id = $stateParams.id;
		$scope.documentType = {};
		$scope.documentType.status = true;
		$scope.editMode = false;
		if($scope.id != null){
			$scope.getDocumentById($scope.id);
			$scope.editMode = true;
		}
	};
	
	$scope.getDocumentById = function(id){
		var getObj = {};
			getObj.id = id;
		ajaxService.firePostRequest('/documentTypeMaster/get',
				getObj,
				$scope.getEditObjSuccess,
				$scope.getEditObjFailed
		);
	};
	
	$scope.getEditObjSuccess = function ( response ) {
		$scope.documentType =  response.data;
		
		if($scope.documentType.status == "ACTIVE"){
			$scope.documentType.status = true;
		}else{
			$scope.documentType.status = false;
		}
	};
	
	$scope.getEditObjFailed = function ( response ) {			
		console.log("error");
	};
	
	$scope.submitDocumentType = function(isValid){
		if(isValid){
			var documentTypeMasterObj = {};
			var url = '';
			if($scope.editMode){
				$scope.documentType.id = $scope.id;
				 url = '/documentTypeMaster/update' ;
			}else{
				url = '/documentTypeMaster/add' ;
				
			}
			documentTypeMasterObj = $scope.documentType;
			if($scope.documentType.status == true){
				documentTypeMasterObj.status = "ACTIVE";
			}else{
				documentTypeMasterObj.status = "INACTIVE";
			}
			ajaxService.firePostRequest(url,
					documentTypeMasterObj,
					$scope.requestSuccess,
					$scope.requestFailed
			);
		}
	};
	
	$scope.requestSuccess = function ( response ) {			
		$state.go('app.documentTypeMasterView');
	};
	
	$scope.requestFailed = function ( response ) {			
		$state.go('app.documentTypeMasterView');
	};
	
	$scope.cancelDocumentType = function(){
		$state.go('app.documentTypeMasterView');
	};
	
});