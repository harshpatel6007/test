app.controller("documentSubTypeMasterViewCtrl", function($scope, ajaxService, modalUtil, toaster){
	
	$scope.initDocumentSubType = function(){
		$scope.documentSubTypeMaster = {};
		
		$scope.documentSubTypeData = [];
		$scope.itemsPerPage = 10;
	    $scope.currentPage = 1;
	    $scope.maxSize = 5;
		
		$scope.search_documentSubType();
		documentSubTypeMap = {};
	};
	
	$scope.search_documentSubType = function(){
		$scope.documentSubTypeTable = false;
		var search = {};
		search = $scope.documentSubTypeMaster;
		ajaxService.firePostRequest('/documentSubTypeMaster/search',
				search,
				$scope.searchSuccess,
				$scope.searchFailed
		);
		
	};
	
	$scope.searchSuccess = function ( response ) {
		if(response.data != null && response.data != ""){
			$scope.documentSubTypeData = response.data;
			
			$scope.totalItems = $scope.documentSubTypeData.length;
		    $scope.pageCount = function () {
			     return Math.ceil($scope.documentSubTypeData.length / $scope.itemsPerPage);
			   };

		   $scope.$watch('currentPage + itemsPerPage', function() {
			     var begin = (($scope.currentPage - 1) * $scope.itemsPerPage),
			         end = begin + $scope.itemsPerPage;
			     	$scope.filteredDocumentSubTypeData = $scope.documentSubTypeData.slice(begin, end);
			   });
			
			$scope.documentSubTypeTable = true;
			angular.forEach($scope.documentSubTypeData, function(value, key){
				documentSubTypeMap[value.id] = value;
			});
		}else{
			toaster.clear();
	    	toaster.pop('warning', "No Record Found", '');
		}
	};
	
	$scope.searchFailed = function ( response ) {			
		console.log("error");
	};
	
	$scope.delete_documentSubType = function(documentSubTypeId){
		var documentSubTypeObj = documentSubTypeMap[documentSubTypeId];
		modalUtil.createModalWithControllerUrl(
				'Confirm', 
			 	'Are you sure you want to delete '+documentSubTypeObj.name+' record ?',
			 	'documentSubTypeMasterModalViewCtrl' ,'md', documentSubTypeId, $scope);
		};

});

app.controller("documentSubTypeMasterModalViewCtrl", function($scope, $modalInstance, datas, ajaxService){
	$scope.ok = function(){
		var deleteObj = {};
		deleteObj.id = datas;
		ajaxService.firePostRequest('/documentSubTypeMaster/delete',
				deleteObj,
				$scope.deleteSuccess,
				$scope.deleteFailed
		);
		$modalInstance.close();
	};
	
	$scope.cancel = function () {
        $modalInstance.dismiss('cancel');
    };
    
    $scope.deleteSuccess = function ( response ) {			
		$scope.search_State();
	};
	
	$scope.deleteFailed = function ( response ) {			
	};
	
});