app.controller("occupationMasterAdd", ['$scope', '$state', 'ajaxService', '$stateParams',
       function ($scope, $state, ajaxService, $stateParams) {
	
	$scope.init = function(){
		$scope.occupationFromData = {};
		$scope.occupationFromData.status = true;
		$scope.id = $stateParams.id;
		$scope.editMode = false;
		if($scope.id != null){
			$scope.getOccupationById($scope.id);
			$scope.editMode = true;
		}
		
	};
	
	$scope.cancel = function(){
		$state.go('app.occupationMasterView', { reload : false });
	};
	
	$scope.getOccupationById = function(id){
		var getObj = {};
			getObj.id = id;
		ajaxService.firePostRequest('/occupation/get',
				getObj,
				$scope.getEditObjSuccess,
				$scope.getEditObjFailed
		);
	};
	
	$scope.getEditObjFailed = function ( response ) {			
		console.log("error");
	};
	
	$scope.getEditObjSuccess = function ( response ) {
		$scope.occupationFromData =  response.data;
		
		if($scope.occupationFromData.status == "ACTIVE"){
			$scope.occupationFromData.status = true;
		}else{
			$scope.occupationFromData.status = false;
		}
	};
	
	$scope.submit= function(){
		if ($scope.occupationFrom.$valid){
		var data = {};
		var URL = "";
		data = $scope.occupationFromData;
		
		if($scope.editMode){
			$scope.occupationFromData.id = $scope.id;
			URL = '/occupation/update' ;
		} 
		else {
			URL = '/occupation/add';
		}
		if($scope.occupationFromData.status == true){
			data.status = "ACTIVE";
		}else{
			data.status = "INACTIVE";
		}
		ajaxService.firePostRequest(URL,
				data,
				$scope.requestSuccess,
				$scope.requestFailed
		);
		} else {
			$scope.occupationFrom.submitted = true;
		}
	};
	$scope.requestSuccess = function ( response ) {			
		$state.go('app.occupationMasterView', { reload : false });
	};
	
	$scope.requestFailed = function ( response ) {			
		console.log("error");
	};
}]);