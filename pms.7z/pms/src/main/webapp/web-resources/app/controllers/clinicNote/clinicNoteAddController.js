
app.controller("clinicNoteAddController", function($scope, $http, ajaxService,$stateParams,$timeout) {
	
	 $scope.init = function(){
		 	$scope.editMode = false;
		 	$scope.diagnosisData = [];
		 	$scope.drugAllergyData = [];
		    $scope.clinicNoteData = {};
		    $scope.getDiagnosisData();
		    $scope.get_DrugAllergyData();
		    $scope.getClinicData();
		  };
		  
		  $scope.callEditMode= function(){
			 	$scope.editMode = true;
		  };
		  
		  $scope.getClinicData = function(){
			$scope.clinicNoteData = $stateParams.visit;
		  };
		  
	$scope.getDiagnosisData = function(){
		ajaxService.firePostRequest('/diagnosis/getAllName',
				"",
				$scope.dignosisSuccess,
				$scope.dignosisFailed
		);
	};
	
	$scope.dignosisSuccess = function ( response ) {
		$scope.diagnosisData = response.data;
	};
	$scope.dignosisFailed = function ( response ) {
		console.log("Error");
	};
	
	$scope.get_DrugAllergyData = function(){
		console.log("call drug function");
		ajaxService.firePostRequest('/drugAllergy/getAllName',
				"",
				$scope.drugDataSuccess,
				$scope.drugDataFailed
		);
	};
	
	$scope.drugDataSuccess = function (response) {
		$scope.drugAllergyData = response.data;
		 
	};
	$scope.drugDataFailed = function ( response ) {
		console.log("Error");
	};
	
	$scope.submit= function(){
		if($scope.clinicNote.$valid){
			
		var visitObj = $stateParams.visit;
		var data = {};
		var URL = "";
		data = $scope.clinicNoteData;
		data.id = visitObj.id;
			URL = '/visit/update';
		
		ajaxService.firePostRequest(URL,
				data,
				$scope.requestSuccessOfClinicNote,
				$scope.requestFailedOfClinicNote
		);
		
		}else{
			$scope.clinicNote.submitted=true;
		}
	};
	
	$scope.requestSuccessOfClinicNote = function ( response ) {
		$scope.editMode = false;
	};
	
	$scope.requestFailedOfClinicNote = function ( response ) {			
		alert("fail");
	};

});
