app.controller("religionMaterAddCtrl", ['$scope', '$state', 'ajaxService', '$stateParams',
       function ($scope, $state, ajaxService, $stateParams) {
	
	$scope.religionManageInit = function(){
		$scope.id = $stateParams.id;
		$scope.religion = {};
		$scope.religion.status = true;
		$scope.editMode = false;
		if($scope.id != null){
			$scope.getReligionById($scope.id);
			$scope.editMode = true;
		}
	};
	
	$scope.getReligionById = function(id){
		var getObj = {};
			getObj.id = id;
		ajaxService.firePostRequest('/religionMaster/get',
				getObj,
				$scope.getEditObjSuccess,
				$scope.getEditObjFailed
		);
	};
	
	$scope.getEditObjSuccess = function ( response ) {
		$scope.religion =  response.data;
		
		if($scope.religion.status == "ACTIVE"){
			$scope.religion.status = true;
		}else{
			$scope.religion.status = false;
		}
	};
	
	$scope.getEditObjFailed = function ( response ) {			
		console.log("error");
	};
	
	$scope.submit = function(isValid){
		if(isValid){
			var religionMasterObj = {};
			var url = '';
			if($scope.editMode){
				$scope.religion.id = $scope.id;
				 url = '/religionMaster/update' ;
			}else{
				url = '/religionMaster/add' ;
			}
			religionMasterObj = $scope.religion;
			if($scope.religion.status == true){
				religionMasterObj.status = "ACTIVE";
			}else{
				religionMasterObj.status = "INACTIVE";
			}
			ajaxService.firePostRequest(url,
					religionMasterObj,
					$scope.requestSuccess,
					$scope.requestFailed
			);
		}
		
	};
	
	$scope.requestSuccess = function ( response ) {			
		$state.go('app.religionMaster');
	};
	
	$scope.requestFailed = function ( response ) {			
		$state.go('app.religionMaster');
	};
	
	$scope.cancelReligion = function(){
		$state.go('app.religionMaster');
	};
}]);
