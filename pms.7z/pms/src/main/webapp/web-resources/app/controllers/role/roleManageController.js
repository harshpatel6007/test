app.controller("roleManageController", function($scope, $http, ajaxService, $state, modalUtil, $stateParams, $document){
	$scope.roleManageInit = function(){
		$scope.id = $stateParams.id;
		$scope.getRoleList();
		$scope.editMode = false;
		if($scope.id != null){
			$scope.editMode = true;
			$scope.getRoleById($scope.id);
		}
		roleMap = {};
		$scope.roleObj = {};
		$scope.roleObj.access = {};
		$scope.enumObj = {};
	};
	
	$scope.getRoleById = function(id){
		var getId = {};
			getId.id = id;
		ajaxService.firePostRequest('/role/get',
				getId,
				$scope.getRoleByIdSuccess,
				$scope.getRoleByIdFailed
		);
	};
	
	$scope.getRoleByIdSuccess = function( response ){
		$scope.roleObj = response.data;
		
		if($scope.roleObj.status == "ACTIVE"){
			$scope.roleObj.status = true;
		}else{
			$scope.roleObj.status = false;
		}
	};
	
	$scope.getRoleList = function(){
		var search = {
			key : "name",
			value : '',
			operation  : "or",
		};
		ajaxService.firePostRequest('/role/list',
				search,
				$scope.getRoleListObjSuccess,
				$scope.getRoleListObjFailed
		);
	};
	
	$scope.getRoleListObjSuccess = function( response ){
		$scope.roleList = response.data;
		angular.forEach($scope.roleList, function(value, key){
			roleMap[value.id] = value;
		});
	};
	
	$scope.getRoleListObjFailed = function( response ){
		
	};
	
	$scope.checkRoleAccess = function( id ){
		$scope.roleObj.access = {};
		var roleObject = roleMap[id];
		$.each(roleObject.access, function(key, value) {
			$scope.roleObj.access[key] = value;
		});
	};
	
	$scope.submitRole = function(isValid){
		if(isValid){
			var roleObj = $scope.roleObj;
			var url = '';
			if($scope.editMode){
				roleObj.id = $scope.id;
				url = "/role/update";
			}else{
				url = "/role/add";
			}
			
			if($scope.roleObj.status == true){
				roleObj.status = "ACTIVE";
			}else{
				roleObj.status = "INACTIVE";
			}
			ajaxService.firePostRequest(url,
					roleObj,
					$scope.requestSuccess,
					$scope.requestFailed
			);
		}
	};
	
	$scope.requestSuccess = function( response ){
		$state.go('app.roleView');
	};
	
	$scope.requestFailed = function( response ){
		
	};
	
	/* SetUnset All Access */
	$scope.allRoleCheckFn = function(){
		var message = '';
		if($scope.allRoleAccess){
			message = 'All privileges will be granted, Are you sure you want to continue ?'; 
		}else{
			message = 'All Privileges Will be revoked, Are You Sure You Want to Continue ?';
		}
		
		modalUtil.createModalWithControllerUrl(
				'Confirm', 
				message,
				'roleModalRoleAccessCtrl' ,'xs', '',$scope);
	};
	
	$scope.setAccess = function(allRole){
		$scope.allRoleAccess = allRole;
		$scope.roleObj.access = {};
		$scope.enumObj = {};
		$.each(enums, function(key, value) {
			$scope.enumObj[key] = allRole;
			$.each(value, function(key1, value1) {
				$scope.roleObj.access[value1] = allRole;
			});
		});
	};
	
	/* RoleGroupEnum Check Function */
	$scope.allRoleGroupCheckFn = function( roleGrpValue ){
			$.each(enums[roleGrpValue], function(roleAccessKey, roleAccessValue) {
				$scope.roleObj.access[roleAccessValue] = $scope.enumObj[roleGrpValue];
			});
			
			var grpCount = 0;
			var enumLength = 0;
			$.each(enums, function(key, value) {
				enumLength++;
				if($scope.enumObj[key]){
					grpCount++;	
				}
			});
			
			if(enumLength == grpCount){
				$scope.allRoleAccess = true;
			}else{
				$scope.allRoleAccess = false;
			}
			
	};
	
	/*  Role Access Check function*/
	$scope.checkUncheckAccess = function( accessGrpName ){
		var count = 0;
		$.each(enums[accessGrpName], function(roleAccessKey, roleAccessValue) {
			if($scope.roleObj.access[roleAccessValue]){
				count++;
			};
		});
		
		if(enums[accessGrpName].length == count){
			$scope.enumObj[accessGrpName] = true;
		}else{
			$scope.enumObj[accessGrpName] = false;
		};
		
		var grpCount = 0;
		var enumLength = 0;
		$.each(enums, function(key, value) {
			enumLength++;
			if($scope.enumObj[key]){
				grpCount++;	
			}
		});
		
		if(enumLength == grpCount){
			$scope.allRoleAccess = true;
		}else{
			$scope.allRoleAccess = false;
		}
	};
	
	$scope.cancelRole = function(){
		$state.go('app.roleView');
	};
	
	$scope.setCancelAccess = function(value){
		$scope.allRoleAccess = value;
	};
	
	
	/* set scrolling Function */
	$scope.scrollGroupFn = function(){
		document.getElementById($scope.roleGroupOptions).scrollIntoView(true);
	};
});

app.controller("roleModalRoleAccessCtrl", function($scope, $modalInstance){
	$scope.ok = function(){
		$scope.setAccess($scope.allRoleAccess);
		$modalInstance.close();
	};
	
	$scope.cancel = function () {
		$scope.setCancelAccess(!$scope.allRoleAccess);
        $modalInstance.dismiss('cancel');
    };
    
});
		