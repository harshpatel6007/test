app.controller("roleViewController", ['$scope', '$state', 'ajaxService', 'modalUtil', 'toaster', 
                        function ($scope, $state, ajaxService, modalUtil, toaster) {
			$scope.initRoleSearch = function(){
				$scope.viewRoleData =[];
				
				$scope.itemsPerPage = 10;
			    $scope.currentPage = 1;
			    $scope.maxSize = 5;
				
				$scope.searchCriteria_Role = '';
				roleMap = {};
				$scope.roleSearch();
				$scope.roleAccessObject = {};
			};
			
			$scope.roleSearch = function(){
				$scope.roleTable = false;
				var search = {
						key : "name",
						value : $scope.searchCriteria_Role,
						operation  : "or",
					};		

					ajaxService.firePostRequest('/role/list',
							search,
							$scope.searchSuccess,
							$scope.searchFailed
					);
			};
			
			$scope.searchSuccess = function( response ){
				$scope.viewRoleData = response.data;
				
				$scope.totalItems = $scope.viewRoleData.length;
			    $scope.pageCount = function () {
				     return Math.ceil($scope.viewRoleData.length / $scope.itemsPerPage);
				   };

			   $scope.$watch('currentPage + itemsPerPage', function() {
				     var begin = (($scope.currentPage - 1) * $scope.itemsPerPage),
				         end = begin + $scope.itemsPerPage;
				     	$scope.filteredViewRoleData = $scope.viewRoleData.slice(begin, end);
				   });
				
				$scope.roleTable = true;
				angular.forEach($scope.viewRoleData, function(value, key){
					roleMap[value.id] = value;
				});
			};
			
			$scope.searchFailed = function( response ){
			};
			
			$scope._changeStatus = function(roleId) {
				var roleObj = roleMap[roleId];
				
				var changeStatusObj = {};
				changeStatusObj.roleId = roleObj.id;
				if(roleObj.status == "ACTIVE"){
					changeStatusObj.status = "INACTIVE";
				}else{
					changeStatusObj.status = "ACTIVE";
				}
				
				
				var message = '';
				if(roleObj.status == "ACTIVE"){
					message = 'Are you sure you want to INACTIVE this record ?'; 
				}else{
					message = 'Are you sure you want to ACTIVE this record ?';
				}
				
				modalUtil.createModalWithControllerUrl(
					 	'Confirm', 
					 	message,
					 	'roleChangeStatusCtrl' ,'md', changeStatusObj, $scope);
				
		  };
		  
		  $scope._viewRole = function( roleId ){
			  var roleViewModalObj = roleMap[roleId];
			  modalUtil.createModalWithCustomTemplateCtrlAndData(
					  'myModalContent.html', 
					 	'roleViewModalController','lg', roleViewModalObj, $scope);
		  };
		  
}]);

app.controller("roleViewModalController", function($scope, $modalInstance, datas){
	$scope.roleAccessObject = {};
	$scope.roleViewModalObj = datas;
	$scope.roleAccessObject = $scope.roleViewModalObj.access;
	
	$scope.close = function (){
		$modalInstance.close();
    };
});

app.controller("roleChangeStatusCtrl", function($scope, $modalInstance, datas, ajaxService){
	$scope.ok = function(){
		ajaxService.firePostRequest('/role/changeStatus',
				datas,
				$scope.deleteSuccess,
				$scope.deleteFailed
		);
		
		$modalInstance.close();
	};
	
	$scope.cancel = function () {
        $modalInstance.dismiss('cancel');
    };
    
    $scope.deleteSuccess = function ( response ) {			
		$scope.roleSearch();
	};
	
	$scope.deleteFailed = function ( response ) {			
		
	};
	
	$scope.scrollGroupModalFn = function(){
		document.getElementById($scope.roleGroupModalOptions).scrollIntoView(true);
	};
	
});
		
		
		