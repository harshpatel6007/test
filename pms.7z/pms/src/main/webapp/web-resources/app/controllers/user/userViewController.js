app.controller("userViewController", function($scope, $http, ajaxService, $state , toaster, modalUtil){
	
	
	$scope.init = function(){
		$scope.user = [];
		$scope.itemsPerPage = 10;
	    $scope.currentPage = 1;
	    $scope.maxSize = 5;
		userMap = {};
		$scope.userTable = true;
		$scope.searchCriteria_UserName = '';
		$scope.getAllUserList();
	};
	
	$scope.getAllUserList = function (){
		$scope.userTable = true;
		var search = {
			key : "userId",
			value : $scope.searchCriteria_UserName,
			operation  : "or",
		};	
		ajaxService.firePostRequest('/user/autoSearch',
				search,
				$scope.searchSuccess,
				$scope.searchFailed
		);
	};
	
	$scope.searchSuccess = function ( response ) {
		if(response.data != null && response.data != ""){
		$scope.user = response.data;
		
		$scope.totalItems = $scope.user.length;
	    $scope.pageCount = function () {
		     return Math.ceil($scope.user.length / $scope.itemsPerPage);
		   };

	   $scope.$watch('currentPage + itemsPerPage', function() {
		     var begin = (($scope.currentPage - 1) * $scope.itemsPerPage),
		         end = begin + $scope.itemsPerPage;
		     	$scope.filteredUsers = $scope.user.slice(begin, end);
		   });
		
		angular.forEach($scope.user, function(value, key){
			userMap[value.id] = value;
			});
		}else{
			$scope.userTable = false;
			toaster.clear();
	    	toaster.pop('warning', "No Record Found", '');
		}
	};
	
	$scope.searchFailed = function ( response ) {			
		console.log("error");
	};
	
	
	$scope.changeStatus = function(userId){
		var message = '';
		var userObj = userMap[userId];
		 
		var changeStatusObj = {};
		changeStatusObj.userId = userObj.id;
		if(userObj.status){
				message = 'Are you sure you want to INACTIVE'+userObj.userId+' ?';
				changeStatusObj.status = false;
			}else{
				message = 'Are you sure you want to ACTIVE '+userObj.userId+' ?';
				changeStatusObj.status = true;
			}
			modalUtil.createModalWithControllerUrl(
				 	'Confirm', 
				 	message,
				 	'userViewCtrl' ,'md', changeStatusObj, $scope);
	  };
	  
	  
	  $scope.viewUserDetail =function(userId){
		  $state.go('app.userDetailView', { 'id':userId});
//		  var userObj = userMap[userId];
//		  alert("userObj"+JSON.stringify(userObj));
	  };
	  
	  
	  $scope.changePassword = function(userId){
//		  var userObj = userMap[userId];
		  modalUtil.createModalWithCustomTemplateCtrlAndData(
				  'changePassword.html', 
				 	'userPasswordChangeCtrl','md',userId, $scope);
		  
	  };
});


app.controller("userPasswordChangeCtrl", function($scope, $modalInstance, datas, ajaxService){
	$scope.changePasswordSubmit = function(){
		var data = {};
		data.userId = datas;
		data.password = $scope.pwpopup1;
		datas.password = $scope.pwpopup1;
		ajaxService.firePostRequest('/user/changePasswordByUser',
				data,
				$scope.changePSWSuccess,
				$scope.changePSWFalied
		);
		$modalInstance.close();
	};
	
	
	$scope.cancel = function () {
        $modalInstance.dismiss('cancel');
    };
    
    $scope.changePSWSuccess = function ( response ) {			
    	$scope.getAllUserList();
	};
	
	$scope.changePSWFalied = function ( response ) {			
		console.log("error");
	};
});

app.controller("userViewCtrl", function($scope, $modalInstance, datas, ajaxService){
	$scope.ok = function(){
		ajaxService.firePostRequest('/user/changeStatus',
				datas,
				$scope.changeStatusSuccess,
				$scope.changeStatusFailed
		);
		$modalInstance.close();
	};
	
	$scope.cancel = function () {
        $modalInstance.dismiss('cancel');
    };
    
    $scope.changeStatusSuccess = function ( response ) {			
    	$scope.getAllUserList();
	};
	
	$scope.changeStatusFailed = function ( response ) {			
		console.log("error");
	};
});


		