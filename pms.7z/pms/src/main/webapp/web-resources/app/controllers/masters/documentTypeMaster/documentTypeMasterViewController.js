app.controller("documentTypeMasterViewCtrl", function($scope, toaster, ajaxService, modalUtil){
	$scope.initDocumentType = function(){
		$scope.searchCriteria_DocumentType = '';
		
		$scope.documentTypeData =[];
		$scope.itemsPerPage = 10;
	    $scope.currentPage = 1;
	    $scope.maxSize = 5;
		
		$scope.search_DocumentType();
		documentTypeMap = {};
		
	};
	
	$scope.search_DocumentType = function(){
		$scope.documentTypeTable = false;
		var search = {
			key : "name",
			value : $scope.searchCriteria_DocumentType,
			operation  : "or",
		};		

		ajaxService.firePostRequest('/documentTypeMaster/search',
				search,
				$scope.searchSuccess,
				$scope.searchFailed
		);
		
	};
	
	$scope.searchSuccess = function ( response ) {
		if(response.data != null && response.data != ""){
			$scope.documentTypeData = response.data;
			
			$scope.totalItems = $scope.documentTypeData.length;
		    $scope.pageCount = function () {
			     return Math.ceil($scope.documentTypeData.length / $scope.itemsPerPage);
			   };

		   $scope.$watch('currentPage + itemsPerPage', function() {
			     var begin = (($scope.currentPage - 1) * $scope.itemsPerPage),
			         end = begin + $scope.itemsPerPage;
			     	$scope.filteredDocumentTypeData = $scope.documentTypeData.slice(begin, end);
			   });
			
			$scope.documentTypeTable = true;
			
			angular.forEach($scope.documentTypeData, function(value, key){
				documentTypeMap[value.id] = value;
			});
			
		}else{
			toaster.clear();
	    	toaster.pop('warning', "No Record Found", '');
		}
		
	};
	
	$scope.searchFailed = function ( response ) {			
	};
	
	$scope.delete_DocumentType = function(documentTypeId){
		var documentTypeObj = documentTypeMap[documentTypeId];
		 modalUtil.createModalWithControllerUrl(
				 	'Confirm', 
				 	'Are you sure you want to delete '+documentTypeObj.name+' record ?',
				 	'documentTypeMasterModalViewCtrl' ,'md', documentTypeId, $scope);
	};
	
});

app.controller("documentTypeMasterModalViewCtrl", function($scope, $modalInstance, datas, ajaxService){
	$scope.ok = function(){
		var deleteObj = {};
		deleteObj.id = datas;
		ajaxService.firePostRequest('/documentTypeMaster/delete',
				deleteObj,
				$scope.deleteSuccess,
				$scope.deleteFailed
		);
		
		$modalInstance.close();
	};
	
	$scope.cancel = function () {
        $modalInstance.dismiss('cancel');
    };
    
    $scope.deleteSuccess = function ( response ) {			
		$scope.search_DocumentType();
	};
	
	$scope.deleteFailed = function ( response ) {			
		
	};
	
});