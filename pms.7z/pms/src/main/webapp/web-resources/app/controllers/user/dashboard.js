/**
 * 
 */
app.controller('dashboardCtrl', [ '$scope', 'ajaxService','$state','$rootScope', function ($scope, ajaxService, $state, $rootScope) {
	
	$scope.dashboardDetail = JSON.parse(dashboard);

	$scope.visits = $scope.dashboardDetail.scheduledPatients;
	
	console.log("patient size : " + $scope.visits.length);
	
	$scope.getAgeFromDate = function (birthDate) {
//		console.log("birthDate : " + new Date(birthDate));
		return DateUtils.getAgeFromDate(new Date(birthDate));
	};
	
	$scope.defaultTimeFormat = function (date) {
		return DateUtils.defaultTimeFormat(new Date(date));
	};
	
	$scope.checkPatientisOnTime = function (date) {
		if(new Date().getTime() <= date) {
			return true;
		} else {
			return false;
		}
	};
	
	$scope.getBackgroundbyPatientStatus = function (date) {
		return this.checkPatientisOnTime(date) ? 'bg-palegreen' : 'bg-orange'; 
	};
	
	$scope.getPatientStatus = function (date) {
		if(this.checkPatientisOnTime(date)) {
			var hrs = new Date(date).getHours() - new Date().getHours(); 
			return 'Appoint. in ' + hrs + ' + hrs | Scheduled';
		} else {
			var hrs = new Date().getHours() - new Date(date).getHours(); 
			return 'Appoint. before ' + hrs + '+ hrs | Late';
		}
	};
	
	$scope.getAddressString = function (address) {
		var addressString = '';
		addressString += address.postalAddress;
		return addressString;
	};
	
	$scope.displayInClinicPatients = function () {
		$scope.visits = $scope.dashboardDetail.inClinicPatients;
	};
	
	$scope.displayCompletedPatients = function () {
		$scope.visits = $scope.dashboardDetail.completedPatients;
	};
	
	$scope.displayScheduledPatients = function () {
		$scope.visits = $scope.dashboardDetail.scheduledPatients;
	};
	
	$scope.getScheduledPatientCount = function () {
		return $scope.dashboardDetail.scheduledPatients.length;
	};
	
	$scope.getInclinicPatientCount = function () {
		return $scope.dashboardDetail.inClinicPatients.length;
	};
	
	$scope.getCompletedPatientCount = function () {
		return $scope.dashboardDetail.completedPatients.length;
	};
	
	$scope.movetoPatientCommonView = function (patientId) {		
		$state.go('app.patient', { patientId : patientId });
	};
	
	$scope.makePatientReady = function (visit) {
		visit.status = 'READY';
		ajaxService.firePostRequest(
				'/visit/changeStatus',
				{ 'userId' : $rootScope.logged_userId, 'status' : 'READY', 'visitId' : visit.id }
				
		);	
	};
	
	$scope.makePatientArrived = function (visit) {
		visit.status = 'ARRIVED';
		ajaxService.firePostRequest(
				'/visit/changeStatus',
				{ 'userId' : $rootScope.logged_userId, 'status' : 'ARRIVED', 'visitId' : visit.id }
		);		
	};
	
	$scope.makePatientInclinc = function (visit) {
		var index = $scope.dashboardDetail.scheduledPatients.indexOf(visit);
		visit.status = 'IN_CLINIC';
		ajaxService.firePostRequest(
				'/visit/changeStatus',
				{ 'userId' : $rootScope.logged_userId, 'status' : 'IN_CLINIC', 'visitId' : visit.id },
				$scope.refreshScheduledData()
		);
		$scope.dashboardDetail.scheduledPatients.splice(index, 1);
		$scope.dashboardDetail.inClinicPatients.push(visit);
	};
	
	$scope.refreshScheduledData = function () {
		$scope.visits = $scope.dashboardDetail.scheduledPatients;
	};
	
	$scope.isVisitStatus = function (actualStatus, requiredStatus) {
		if(actualStatus == requiredStatus) {
			return true;
		}
		return false;
	};
	
	//============================================		DATE PICKER		================================================//
	
	
	$scope.today = function () {
		$scope.dt = new Date();
	};
	$scope.today();
	
	$scope.clear = function () {
		$scope.dt = null;
	};
	    
	$scope.open = function ($event) {
        $event.preventDefault();
        $event.stopPropagation();
        $scope.opened = true;
    };
    
    $scope.dateOptions = {
        formatYear: 'yy',
        startingDay: 1
    };
    
	$scope.formats = ['dd-MMMM-yyyy', 'yyyy/MM/dd', 'dd.MM.yyyy', 'shortDate'];
    $scope.format = $scope.formats[0];
    $scope.altInputFormats = ['M!/d!/yyyy'];

}]);