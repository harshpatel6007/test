app.controller("refferMasterView", ['$scope', '$state', 'ajaxService', 'modalUtil' ,'$stateParams','toaster',
                                      function ($scope, $state, ajaxService, modalUtil, $stateParams,toaster) {
	
	$scope.init = function() {
		$scope.refferFromData = [];
		
		$scope.itemsPerPage = 1;
	    $scope.currentPage = 1;
	    $scope.maxSize = 5;
		
		$scope.searchCriteria_reffer = '';
		$scope.search_reffer();
		refferMap = {}; 
	};
	
	$scope.search_reffer = function(){
		$scope.refferTable = false;
		var search = {
			key : "name",
			value : $scope.searchCriteria_reffer,
			operation  : "or",
		};		
		ajaxService.firePostRequest('/reffer/search',
				search,
				$scope.searchSuccess,
				$scope.searchFailed
		);
	};
	
	$scope.searchSuccess = function ( response ) {
		if(response.data != null && response.data != ""){
		$scope.refferFromData = response.data;
		
		$scope.totalItems = $scope.refferFromData.length;
	    $scope.pageCount = function () {
		     return Math.ceil($scope.refferFromData.length / $scope.itemsPerPage);
		   };

	   $scope.$watch('currentPage + itemsPerPage', function() {
		     var begin = (($scope.currentPage - 1) * $scope.itemsPerPage),
		         end = begin + $scope.itemsPerPage;
		     	$scope.filteredRefferFromData = $scope.refferFromData.slice(begin, end);
		   });
		
		
		
		$scope.refferTable = true;
		angular.forEach($scope.refferFromData, function(value, key){
			refferMap[value.id] = value;
			});
		}else{
			toaster.clear();
	    	toaster.pop('warning', "No Record Found", '');
		}
	};
	
	$scope.searchFailed = function ( response ) {			
		console.log("error");
	};
	
	$scope.delete_Reffer = function(diagnosisId){
		var refferObj = refferMap[diagnosisId];
		modalUtil.createModalWithControllerUrl(
			 	'Confirm', 
			 	'Are you sure you want to delete '+refferObj.name+' record ?',
			 	'refferMasterModalViewCtrl' ,'md', diagnosisId, $scope);
	};
	
	
}]);

app.controller("refferMasterModalViewCtrl", function($scope, $modalInstance, datas, ajaxService){
	$scope.ok = function(){
		var deleteObj = {};
		deleteObj.id = datas;
		ajaxService.firePostRequest('/reffer/delete',
				deleteObj,
				$scope.deleteSuccess,
				$scope.deleteFailed
		);
		$modalInstance.close();
	};
	
	$scope.cancel = function () {
        $modalInstance.dismiss('cancel');
    };
    
    $scope.deleteSuccess = function ( response ) {			
		$scope.search_reffer();
	};
	
	$scope.deleteFailed = function ( response ) {			
		console.log("error");
	};
});


