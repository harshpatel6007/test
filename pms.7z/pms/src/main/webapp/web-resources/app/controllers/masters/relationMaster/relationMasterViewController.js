app.controller("relationMasterViewCtrl", ['$scope', '$state', 'ajaxService', 'modalUtil', 'toaster',
       function ($scope, $state, ajaxService, modalUtil, toaster) {
	$scope.initRelation = function(){
		$scope.relationData = [];
		
		$scope.itemsPerPage = 10;
	    $scope.currentPage = 1;
	    $scope.maxSize = 5;
		
		$scope.searchCriteria_Relation = '';
		$scope.search_Relation();
		relationMap = {};
	};
	
	$scope.search_Relation = function(){
		$scope.relationTable = false;
		var search = {
			key : "name",
			value : $scope.searchCriteria_Relation,
			operation  : "or",
		};		

		ajaxService.firePostRequest('/relationMaster/search',
				search,
				$scope.searchSuccess,
				$scope.searchFailed
		);
		
	};
	
	$scope.searchSuccess = function ( response ) {
		if(response.data != null && response.data != ""){
			$scope.relationData = response.data;
			
			$scope.totalItems = $scope.relationData.length;
		    $scope.pageCount = function () {
			     return Math.ceil($scope.relationData.length / $scope.itemsPerPage);
			   };

		   $scope.$watch('currentPage + itemsPerPage', function() {
			     var begin = (($scope.currentPage - 1) * $scope.itemsPerPage),
			         end = begin + $scope.itemsPerPage;
			     	$scope.filteredRelationData = $scope.relationData.slice(begin, end);
			   });
			
			$scope.relationTable = true;
			angular.forEach($scope.relationData, function(value, key){
				relationMap[value.id] = value;
				});
		}else{
			toaster.clear();
	    	toaster.pop('warning', "No Record Found", '');
		}
	};
	
	$scope.searchFailed = function ( response ) {			
		console.log("error");
	};
	
	$scope.delete_Relation = function(relationId){
		var relationObj = relationMap[relationId];
		modalUtil.createModalWithControllerUrl(
			 	'Confirm', 
			 	'Are you sure you want to delete '+relationObj.name+' record ?',
			 	'relationMasterModalViewCtrl' ,'md', relationId, $scope);
		
	};
}]);

app.controller("relationMasterModalViewCtrl", function($scope, $modalInstance, datas, ajaxService){
	$scope.ok = function(){
		var deleteObj = {};
		deleteObj.id = datas;
		ajaxService.firePostRequest('/relationMaster/delete',
				deleteObj,
				$scope.deleteSuccess,
				$scope.deleteFailed
		);
		$modalInstance.close();
	};
	
	$scope.cancel = function () {
        $modalInstance.dismiss('cancel');
    };
    
    $scope.deleteSuccess = function ( response ) {			
		console.log(response.message);
		$scope.search_Relation();
	};
	
	$scope.deleteFailed = function ( response ) {			
		console.log("error");
	};
	
});