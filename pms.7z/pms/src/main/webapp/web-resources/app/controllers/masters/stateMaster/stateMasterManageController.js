app.controller("stateMasterAddCtrl", ['$scope', '$state', 'ajaxService', '$stateParams',  
       function ($scope, $state, ajaxService, $stateParams) {
	
	$scope.stateManageInit = function(){
		$scope.id = $stateParams.id;
		$scope.state = {};
		$scope.state.status = true;
		$scope.editMode = false;
		if($scope.id != null){
			$scope.getstateById($scope.id);
			$scope.editMode = true;
		}
	};
	
	$scope.getstateById = function(id){
		var getObj = {};
			getObj.id = id;
		ajaxService.firePostRequest('/stateMaster/get',
				getObj,
				$scope.getEditObjSuccess,
				$scope.getEditObjFailed
		);
	};
	
	$scope.getEditObjSuccess = function ( response ) {
		$scope.state =  response.data;
		
		if($scope.state.status == "ACTIVE"){
			$scope.state.status = true;
		}else{
			$scope.state.status = false;
		}
	};
	
	$scope.getEditObjFailed = function ( response ) {
		console.log("error");
	};
	
	$scope.submit = function(isValid){
		if(isValid){
			var stateMasterObj = {};
			var url = '';
			if($scope.editMode){
				$scope.state.id = $scope.id;
				 url = '/stateMaster/update' ;
			}else{
				url = '/stateMaster/add' ;
			}
			
			stateMasterObj = $scope.state;
			if($scope.state.status == true){
				stateMasterObj.status = "ACTIVE";
			}else{
				stateMasterObj.status = "INACTIVE";
			}
			ajaxService.firePostRequest(url,
					stateMasterObj,
					$scope.requestSuccess,
					$scope.requestFailed
			);
		}
	};
	
	$scope.requestSuccess = function ( response ) {	
		$state.go('app.stateMaster');
	};
	
	$scope.requestFailed = function ( response ) {
		$state.go('app.stateMaster');
	};
	
	$scope.cancelState = function(){
		$state.go('app.stateMaster');
	};
}]);

