app.controller("userAddController", function($scope, $http, ajaxService,
		$state, $stateParams) {
	$scope.init = function() {
		$scope.id = $stateParams.id;
		$scope.editMode = false;
		$scope.getRoleModel();
		if ($scope.id != null) {
			$scope.getUserById($scope.id);
			$scope.editMode = true;
		}
	};

	$scope.getUserById = function(id) {
		var getObj = {};
		getObj.id = id;
		ajaxService.firePostRequest('/user/get', getObj,
				$scope.getEditObjSuccess, $scope.getEditObjFailed);
	};

	$scope.getEditObjFailed = function(response) {
		console.log("error");
	};

	$scope.getEditObjSuccess = function(response) {
		$scope.user = response.data;
	};

	$scope.getRoleModel = function() {
		var search = {};
		search.key = "name";
		search.value = "";
		search.operation = "or";
		ajaxService.firePostRequest('/role/list', search, $scope.getObjSuccess,
				$scope.getObjFailed);
	};

	$scope.getObjFailed = function(response) {
		console.log("error");
	};

	$scope.getObjSuccess = function(response) {
		$scope.roleList = response.data;
	};

	$scope.cancel = function() {
		$state.go('app.userView');
	};

	$scope.submit = function() {
		if($scope.fromUser.$valid){
			
		var data = {};
		var URL = "";
		$scope.user.createdDate = new Date();
		data = $scope.user;
		if ($scope.editMode) {
			$scope.user.id = $scope.id;
			URL = '/user/update';
			console.log("update");
		} else {
			console.log("add");
			URL = '/user/add';
		}
		ajaxService.firePostRequest(URL, data, $scope.requestSuccess,
				$scope.requestFailed);
		}else{
			$scope.fromUser.submitted = true;
		}
	};
	$scope.requestSuccess = function(response) {
		$state.go('app.userView');
	};

	$scope.requestFailed = function(response) {
		console.log("error");
	};

});
