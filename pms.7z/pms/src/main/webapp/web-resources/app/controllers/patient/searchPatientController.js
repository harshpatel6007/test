app.controller("searchPatientCtrl", function($scope, ajaxService,modalUtil, $state){
	$scope.initSearchPatient = function(){
		$scope.patientData = [];
		
		$scope.itemsPerPage = 10;
	    $scope.currentPage = 1;
	    $scope.maxSize = 5;
		
		patientMap = {};
		$scope.patientValue = '';
		$scope.patientInfo == '';
		$scope.searchPatientSubmitted();
	};
	
	$scope.searchPatientSubmitted = function(){
		$scope.patientSearchTable = false;
		var search = {
				key : $scope.patientInfo,
				value : $scope.patientValue,
				operation  : "or",
			};		

			ajaxService.firePostRequest('/patient/search',
					search,
					$scope.searchSuccess,
					$scope.searchFailed
			);
	};
	
	$scope.getPatientAgeYear = function (birthDate) {
		birthDate = new Date(birthDate); 
		var today = new Date();
		var age = today.getFullYear() - birthDate.getFullYear();
	    var m = today.getMonth() - birthDate.getMonth();
	    if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) 
	    {
	        age--;
	    }
	    return age;
	};
	
	$scope.getPatientAgeMonth = function (birthDate) {
		birthDate = new Date(birthDate);
		var today = new Date();			
	    var month = today.getMonth() - birthDate.getMonth();
	    var days = today.getDate() - birthDate.getDate();	
	    
	    if(month > 0) {
	    	if (days < 0 || (days === 0 && today.getTime() < birthDate.getTime())) 
		    {
		        month--;
		    }
	    } else {
	    	month = 12 + month;
	    }
	    
	    return month;
	};
	
	$scope.getPatientAgeDays = function (birthDate) {
		birthDate = new Date(birthDate);
		var today = new Date();
		var days = today.getDate() - birthDate.getDate();
	    return Math.abs(days); 
	};
	
	$scope.movetoPatientCommonView = function (patientId) {		
		$state.go('app.patient', { patientId : patientId });
	};
	
	$scope.searchSuccess = function( response ){
		$scope.patientSearchTable = true;
		$scope.patientData = response.data;
		
		$scope.totalItems = $scope.patientData.length;
	    $scope.pageCount = function () {
		     return Math.ceil($scope.patientData.length / $scope.itemsPerPage);
		   };

	   $scope.$watch('currentPage + itemsPerPage', function() {
		     var begin = (($scope.currentPage - 1) * $scope.itemsPerPage),
		         end = begin + $scope.itemsPerPage;
		     	$scope.filteredPatientData = $scope.patientData.slice(begin, end);
		   });
		
		angular.forEach($scope.patientData, function(value, key){
			patientMap[value.id] = value;
			});
	};
	
	$scope.create_PatientVisit = function(patientId){
		var patientObj = patientMap[patientId];
		modalUtil.createModalWithControllerUrl(
			 	'Confirm', 
			 	'Are you sure you want to create visit of " '+patientObj.firstName+""+patientObj.middleName+""+patientObj.lastName+' " ?',
			 	'visitAddCtrl' ,'md', patientId, $scope);
	};
	
});

app.controller("visitAddCtrl", function($scope, $modalInstance, datas, ajaxService){
	$scope.ok = function(){
		var data={};
		data.id=datas;
		ajaxService.firePostRequest('/visit/add',
				data,
				$scope.visitSuccess,
				$scope.visitFailed
		);
		$modalInstance.close();
	};
	
	$scope.cancel = function () {
        $modalInstance.dismiss('cancel');
    };
    
    $scope.visitSuccess = function( response ){
		$scope.searchPatientSubmitted();
	};
	
	$scope.visitFailed = function( response ){
		alert("fail");
	};

});


