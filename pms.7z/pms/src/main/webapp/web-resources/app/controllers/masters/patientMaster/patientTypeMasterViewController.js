app.controller("patientTypeView", ['$scope', '$state', 'ajaxService','modalUtil','toaster', '$stateParams',
       function ($scope, $state, ajaxService, modalUtil,toaster, $stateParams) {
	
	$scope.init = function() {
		$scope.patientFormData = [];
		
		$scope.itemsPerPage = 1;
	    $scope.currentPage = 1;
	    $scope.maxSize = 5;
		
		
		$scope.searchCriteria_PatientType = '';
		$scope.search_PatientType();
		patientTypeMap = {};
	};
	
	$scope.search_PatientType = function(){
		$scope.patientTypeTable = false;
		var search = {
			key : "name",
			value : $scope.searchCriteria_PatientType,
			operation  : "or",
		};		
		ajaxService.firePostRequest('/patientType/search',
				search,
				$scope.searchSuccess,
				$scope.searchFailed
		);
	};
	
	$scope.searchSuccess = function ( response ) {
		if(response.data != null && response.data != ""){
			$scope.patientFormData = response.data;
			
			$scope.totalItems = $scope.patientFormData.length;
		    $scope.pageCount = function () {
			     return Math.ceil($scope.patientFormData.length / $scope.itemsPerPage);
			   };

		   $scope.$watch('currentPage + itemsPerPage', function() {
			     var begin = (($scope.currentPage - 1) * $scope.itemsPerPage),
			         end = begin + $scope.itemsPerPage;
			     	$scope.filteredPatientFormData = $scope.patientFormData.slice(begin, end);
			   });
			
			
			
			$scope.patientTypeTable = true;
			angular.forEach($scope.patientFormData, function(value, key){
				patientTypeMap[value.id] = value;
				});
		}else{
			toaster.clear();
	    	toaster.pop('warning', "No Record Found", '');
		}
	};
	
	$scope.searchFailed = function ( response ) {			
		console.log("error");
	};
	
	$scope.delete_PatientType = function(patientTypeId){
		var patientTypeObj = patientTypeMap[patientTypeId];
		modalUtil.createModalWithControllerUrl(
			 	'Confirm', 
			 	'Are you sure you want to delete '+patientTypeObj.name+' record ?',
			 	'patientTypeMasterModalViewCtrl' ,'md', patientTypeId, $scope);
	};
}]);

app.controller("patientTypeMasterModalViewCtrl", function($scope, $modalInstance, datas, ajaxService){
	$scope.ok = function(){
		var deleteObj = {};
		deleteObj.id = datas;
		ajaxService.firePostRequest('/patientType/delete',
				deleteObj,
				$scope.deleteSuccess,
				$scope.deleteFailed
		);
		$modalInstance.close();
	};
	
	$scope.cancel = function () {
        $modalInstance.dismiss('cancel');
    };
    
    $scope.deleteSuccess = function ( response ) {			
		$scope.search_PatientType();
	};
	
	$scope.deleteFailed = function ( response ) {			
		console.log("error");
	};
});
