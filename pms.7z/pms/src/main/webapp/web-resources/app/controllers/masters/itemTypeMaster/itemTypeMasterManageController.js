app.controller("itemTypeMasterAdd", ['$scope', '$state', 'ajaxService', '$stateParams',
       function ($scope, $state, ajaxService, $stateParams) {
	
	$scope.init = function(){
		$scope.itemFormData = {};
		$scope.itemFormData.status = true;
		$scope.id = $stateParams.id;
		$scope.editMode = false;
		if($scope.id != null){
			$scope.getUserById($scope.id);
			$scope.editMode = true;
		}
		
	};
	
	$scope.cancel = function(){
		$state.go('app.itemMasterView');
	};
	
	$scope.getUserById = function(id){
		var getObj = {};
			getObj.id = id;
		ajaxService.firePostRequest('/itemMaster/get',
				getObj,
				$scope.getEditObjSuccess,
				$scope.getEditObjFailed
		);
	};
	
	$scope.getEditObjFailed = function ( response ) {			
		console.log("error");
	};
	
	$scope.getEditObjSuccess = function ( response ) {
		$scope.itemFormData =  response.data;
		
		if($scope.itemFormData.status == "ACTIVE"){
			$scope.itemFormData.status = true;
		}else{
			$scope.itemFormData.status = false;
		}
	};
	
	$scope.submit= function(){
		if($scope.itemForm.$valid){
		var data = {};
		var URL = "";
		$scope.itemFormData.date = new Date();
		$scope.itemFormData.createdBy=userId;
		data = $scope.itemFormData;
		if($scope.editMode){
			$scope.itemFormData.id = $scope.id;
			URL = '/itemMaster/update' ;
		} 
		else {
			URL = '/itemMaster/add';
		}
		if($scope.itemFormData.status == true){
			data.status = "ACTIVE";
		}else{
			data.status = "INACTIVE";
		}
		ajaxService.firePostRequest(URL,
				data,
				$scope.requestSuccess,
				$scope.requestFailed
		);
		}else{
			$scope.itemForm.submitted = true;
		}
	};
	$scope.requestSuccess = function ( response ) {			
		$state.go('app.itemMasterView');
	};
	
	$scope.requestFailed = function ( response ) {			
		console.log("error");
	};
}]);