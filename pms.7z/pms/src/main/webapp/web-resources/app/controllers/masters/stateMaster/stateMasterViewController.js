app.controller("stateMasterViewCtrl", ['$scope', '$state', 'ajaxService', 'toaster', 'modalUtil',
       function ($scope, $state, ajaxService, toaster, modalUtil) {
	$scope.initState = function(){
		$scope.stateData = [];
		
		$scope.itemsPerPage = 10;
	    $scope.currentPage = 1;
	    $scope.maxSize = 5;
		
		$scope.stateMaster = {};
		$scope.search_State();
		stateMap = {};
	};
	
	$scope.search_State = function(){
		$scope.stateTable = false;
		var search = {};
		search = $scope.stateMaster;
		ajaxService.firePostRequest('/stateMaster/search',
				search,
				$scope.searchSuccess,
				$scope.searchFailed
		);
		
	};
	
	$scope.searchSuccess = function ( response ) {
		if(response.data != null && response.data != ""){
			$scope.stateData = response.data;
			
			$scope.totalItems = $scope.stateData.length;
		    $scope.pageCount = function () {
			     return Math.ceil($scope.stateData.length / $scope.itemsPerPage);
			   };

		   $scope.$watch('currentPage + itemsPerPage', function() {
			     var begin = (($scope.currentPage - 1) * $scope.itemsPerPage),
			         end = begin + $scope.itemsPerPage;
			     	$scope.filteredStateData = $scope.stateData.slice(begin, end);
			   });
			
			$scope.stateTable = true;
			angular.forEach($scope.stateData, function(value, key){
				stateMap[value.id] = value;
				});
		}else{
			toaster.clear();
	    	toaster.pop('warning', "No Record Found", '');
		}
	};
	
	$scope.searchFailed = function ( response ) {			
		console.log("error");
	};
	
	$scope.delete_State = function(stateId){
		var stateObj = stateMap[stateId];
		modalUtil.createModalWithControllerUrl(
				'Confirm', 
			 	'Are you sure you want to delete '+stateObj.name+' record ?',
			 	'stateMasterModalViewCtrl' ,'md', stateId, $scope);
		};
	
}]);


app.controller("stateMasterModalViewCtrl", function($scope, $modalInstance, datas, ajaxService){
	$scope.ok = function(){
		var deleteObj = {};
		deleteObj.id = datas;
		ajaxService.firePostRequest('/stateMaster/delete',
				deleteObj,
				$scope.deleteSuccess,
				$scope.deleteFailed
		);
		$modalInstance.close();
	};
	
	$scope.cancel = function () {
        $modalInstance.dismiss('cancel');
    };
    
    $scope.deleteSuccess = function ( response ) {			
		$scope.search_State();
	};
	
	$scope.deleteFailed = function ( response ) {			
	};
	
});