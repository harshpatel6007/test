app.controller("diagnosisMasterAdd", ['$scope', '$state', 'ajaxService', '$stateParams',
       function ($scope, $state, ajaxService, $stateParams) {
	
	$scope.init = function(){
		$scope.diagnosisFromData = {};
		$scope.diagnosisFromData.status = true;
		$scope.id = $stateParams.id;
		$scope.editMode = false;
		if($scope.id != null){
			$scope.getDiagnosisById($scope.id);
			$scope.editMode = true;
		}
	};
	
	$scope.cancel = function(){
		$state.go('app.diagnosisMasterView', { reload : false });
	};
	
	$scope.getDiagnosisById = function(id){
		var getObj = {};
			getObj.id = id;
		ajaxService.firePostRequest('/diagnosis/get',
				getObj,
				$scope.getEditObjSuccess,
				$scope.getEditObjFailed
		);
	};
	
	$scope.getEditObjFailed = function ( response ) {			
		console.log("error");
	};
	
	$scope.getEditObjSuccess = function ( response ) {
		$scope.diagnosisFromData =  response.data;
		
		if($scope.diagnosisFromData.status == "ACTIVE"){
			$scope.diagnosisFromData.status = true;
		}else{
			$scope.diagnosisFromData.status = false;
		}
	};
	
	$scope.submit= function(){
		
		if($scope.diagnosisFrom.$valid){
		var data = {};
		var URL = "";
		data = $scope.diagnosisFromData;
		
		if($scope.editMode){
			$scope.diagnosisFromData.id = $scope.id;
			URL = '/diagnosis/update' ;
		} 
		else {
			URL = '/diagnosis/add';
		}
		if($scope.diagnosisFromData.status == true){
			data.status = "ACTIVE";
		}else{
			data.status = "INACTIVE";
		}
		ajaxService.firePostRequest(URL,
				data,
				$scope.requestSuccess,
				$scope.requestFailed
		);
		}else{
			$scope.diagnosisFrom.submitted =true;
		}
		
	};
	$scope.requestSuccess = function ( response ) {			
		$state.go('app.diagnosisMasterView', { reload : false });
	};
	
	$scope.requestFailed = function ( response ) {			
		console.log("error");
	};
}]);