'use strict';

app.controller('loginCtrl', ['$scope', '$state', '$window', 'ajaxService', '$stateParams', '$rootScope',
    function ($scope, $state, $window, ajaxService, $stateParams, $rootScope) {		
	
		$scope.pmsLogin = function (isValid) {
			if(isValid) {
				this.fireLoginRequest();
			}
		};
		
		$scope.fireLoginRequest = function () {			
			ajaxService.firePostRequest(
					'/user/webLogin',
					this.getUser(),
					$scope.loginSuccess,
					$scope.loginFailed
			);
		};
		
		$scope.getUser = function () {			
			var user = new Object();
			user.userId = $scope.userId;
			user.password = $scope.password;			
			user.clientDateTime = new Date();
			user.addCookie = $scope.remember;
			return user;
		};
		
		$scope.loginSuccess = function ( response ) {			
			$window.location.href = '/pms/user/welcome';
		};
		
		$scope.loginFailed = function ( response ) {
			$scope.isError = true;
			$scope.errorMessage = response["message"];
		};

		$scope.getUserDetailfromCookie = function () {
			console.log("in load function");
			if(!$stateParams.dontCheckCookie) {
				var cookieDetail = $rootScope.getCookieValue("userId");
				console.log("cookie detail : " + cookieDetail);
		    	if(cookieDetail) {
		    		ajaxService.firePostRequest(
							'/user/getUserIdAndName',
							cookieDetail,
							$scope.displayUserFromCookie
					);
		    	}
			}	    	
		};
		
		
		$scope.displayUserFromCookie = function (response) {
			$scope.cookieUser = response["data"];
			console.log("cooki user : " + $scope.cookieUser);
		};
		
		$scope.cookielogin = function () {
			ajaxService.firePostRequest(
					'/user/webLogin',
					{'userId' : $scope.cookieUser.userId, 'password' : $scope.cookieUser.password, 'clientDateTime' : new Date()},
					$scope.loginSuccess,
					$scope.loginFailed
			);
		};
		
		
		( function () {
			$scope.getUserDetailfromCookie();
//			$scope.$apply();
		})();
		
		$scope.checkUserExists = function () {
			if($scope.cookieUser) {
				return true;
			}
			return false;
		};
	}	
]);