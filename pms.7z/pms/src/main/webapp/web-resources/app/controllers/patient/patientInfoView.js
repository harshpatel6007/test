/**
 * 
 */
app.controller('patientInfoCtrl', ['$scope','$stateParams', function ($scope, $stateParams) {
	
	console.log("in controller " + $stateParams.patient);
	$scope.patient = $stateParams.patient;
	
}]);