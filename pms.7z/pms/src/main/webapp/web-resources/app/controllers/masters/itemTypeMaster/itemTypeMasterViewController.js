app.controller("itemTypeView", ['$scope', '$state', 'ajaxService', 'modalUtil','toaster','$stateParams',
       function ($scope, $state, ajaxService,  modalUtil,toaster, $stateParams) {
	
	$scope.init = function() {
		$scope.itemFormData = [];
		
		$scope.itemsPerPage = 1;
	    $scope.currentPage = 1;
	    $scope.maxSize = 5;
		
		$scope.searchCriteria_ItemType = '';
		$scope.search_ItemType();
		itemTypeMap = {};
	};
	
	$scope.search_ItemType = function(){
		$scope.itemTypeTable = false;
		var search = {
			key : "name",
			value : $scope.searchCriteria_ItemType,
			operation  : "or",
		};		
		ajaxService.firePostRequest('/itemMaster/search',
				search,
				$scope.searchSuccess,
				$scope.searchFailed
		);
	};
	
	$scope.searchSuccess = function ( response ) {
		if(response.data != null && response.data != ""){
		$scope.itemFormData = response.data;
		
		
		$scope.totalItems = $scope.itemFormData.length;
	    $scope.pageCount = function () {
		     return Math.ceil($scope.itemFormData.length / $scope.itemsPerPage);
		   };

	   $scope.$watch('currentPage + itemsPerPage', function() {
		     var begin = (($scope.currentPage - 1) * $scope.itemsPerPage),
		         end = begin + $scope.itemsPerPage;
		     	$scope.filteredItemFormData = $scope.itemFormData.slice(begin, end);
		   });
		
		
		
		$scope.itemTypeTable = true;
		angular.forEach($scope.itemFormData, function(value, key){
			itemTypeMap[value.id] = value;
			});
		
		}else{
			toaster.clear();
	    	toaster.pop('warning', "No Record Found", '');
		}
	};
	
	$scope.searchFailed = function ( response ) {			
		console.log("error");
	};
	
	$scope.delete_ItemType = function(itemTypeId){
		var itemTypeObj = itemTypeMap[itemTypeId];
		modalUtil.createModalWithControllerUrl(
			 	'Confirm', 
			 	'Are you sure you want to delete '+itemTypeObj.name +' record  ?',
			 	'itemTypeMasterModalViewCtrl' ,'md', itemTypeId, $scope);
	};
	
}]);
app.controller("itemTypeMasterModalViewCtrl", function($scope, $modalInstance, datas, ajaxService){
	$scope.ok = function(){
		var deleteObj = {};
		deleteObj.id = datas;
		ajaxService.firePostRequest('/itemMaster/delete',
				deleteObj,
				$scope.deleteSuccess,
				$scope.deleteFailed
		);
		$modalInstance.close();
	};
	
	$scope.cancel = function () {
        $modalInstance.dismiss('cancel');
    };
    
    $scope.deleteSuccess = function ( response ) {			
		$scope.search_ItemType();
	};
	
	$scope.deleteFailed = function ( response ) {			
		console.log("error");
	};
});


