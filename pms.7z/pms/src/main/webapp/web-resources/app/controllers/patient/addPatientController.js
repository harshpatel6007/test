app.controller("addPatientCtrl",  function ($scope, ajaxService, modalUtil, $http, $compile, $stateParams, $filter, $state) {
	$scope.addPatientInit = function(){
		$scope.minDate = new Date().getTime();
		$scope.patient = {};
		$scope.patient.relationships = [];
		$scope.addRelationButton = false;
		$scope.getRelationMasterList();
		$scope.deleteButton = false;
		$scope.relationNameMap = {};
		$scope.emergencyContactObj = {};
		$scope.id = $stateParams.id;
		$scope.editMode = false;
		if($scope.id != null){
			$scope.getPatientById($scope.id);
			$scope.editMode = true;
		}else{
			$scope.patient.gender = 'Male';
		}
	};
	
	$scope.getPatientById = function(id){
		var getObj = {};
			getObj.id = id;
		ajaxService.firePostRequest('/patient/get',
				getObj ,
				$scope.getPatientByIdSuccess,
				$scope.getPatientByIdFailed
		);
	};
	
	$scope.getPatientByIdSuccess = function( response ){
		$scope.patient = response.data;
		$scope.patient.dateOfBirth = new Date($scope.patient.dateOfBirth);
		angular.forEach($scope.patient.relationships , function(value, key){
			$scope.setRelationInPatient(value, value.relative.firstName);
			
		});
		$scope.setEmergencyContactEdit($scope.patient.emergencyContacts);
	};
	
	$scope.setEmergencyContactEdit = function(perContact){
		if (perContact != []) {
			$.each(perContact, function(key, value) {
				if (key > 0) {
					$scope._addContactInfo();
				}
				var currentRelation = document.getElementsByName("currentRelationName");
				var currentNumber = document.getElementsByName("currentPhoneNumber");
				/*console.log("key >>>" +JSON.stringify(key));
				console.log("value >>>" +JSON.stringify(value));*/
				currentRelation[key].value = value.relationId;
				currentNumber[key].value = value.conatctNumber;
			});
		}
		console.log("phoneNumberList >>>" +JSON.stringify($scope.patient.emergencyContacts));
	};
	
	$scope.getPatientByIdFailed = function(){
		
	};
	
	$scope.getRelationMasterList = function(){
		var getObj = {};
		ajaxService.firePostRequest('/relationMaster/getRelationMasterList',
				getObj ,
				$scope.getRelationMasterSuccess,
				$scope.getRelationMasterFailed
		);
	};
	
	$scope.getRelationMasterSuccess = function( response ){
		$scope.relationMasterList = response.data;
		
		angular.forEach($scope.relationMasterList, function(value, key){
			$scope.relationNameMap[value.id] = value.name;
		});
	};
	
	$scope.addPatientSubmit = function(isValid){
		if(isValid){
			$scope.getEmergencyContact();
			var patientObj = $scope.patient; 
			var URL = '';
			
			if($scope.editMode){
				patientObj.id = $scope.id;
				URL = '/patient/update';
			}else{
				URL = '/patient/add';
			}
			
			ajaxService.firePostRequest(URL,
					patientObj ,
					$scope.getSuccess,
					$scope.getFailed
			);
		}
	};
	
	$scope.getEmergencyContact = function(){
		 $scope.patient.emergencyContacts = [];
		var currentRelation = document.getElementsByName("currentRelationName");
		var currentNumber = document.getElementsByName("currentPhoneNumber");
		if (!currentNumber.length == 0) {
			for (var i = 0; i < currentRelation.length; i++) {
				var emeegncyObj = {}; 
				emeegncyObj.relationId = currentRelation[i].value;
				emeegncyObj.conatctNumber = currentNumber[i].value;
				if (emeegncyObj.conatctNumber != "" && emeegncyObj.relationId != "") {
					$scope.patient.emergencyContacts.push(emeegncyObj);
				}
			}
		}
	};
	
	
	
	$scope.getSuccess = function( response ){
		if(!$scope.editMode){
			modalUtil.createModalWithCustomTemplateCtrlAndData(
					'addPatientSuccessPopUp.html', 
					'addPatientSuccessPopUpCtrl','xs', '', $scope);
		}else{
			$state.go('app.searchPatient');
		}
	};
	
	$scope.getFailed = function(reponse ){
	};
	
    /*$scope.pageChanged = function () {
        $log.log('Page changed to: ' + $scope.currentPage);
    };*/
	
	$scope.getStateByCountry = function(){
		var getObj = {};
		 getObj.countryId = $scope.patient.address.country;
		ajaxService.firePostRequest('/stateMaster/getStatesByCountry',
				getObj ,
				$scope.getStateByCountrySuccess,
				$scope.getStateByCountryFailed
		);
	};
	
	$scope.getStateByCountrySuccess = function( response ){
		$scope.stateMasters = response.data;
	};
	
	$scope.myAgeFunction = function(date){
		$scope.patient.age = DateUtils.getAgeFromDate($scope.patient.dateOfBirth);
	};
	
	$scope.addRelationShip = function(){
		modalUtil.createModalWithCustomTemplateCtrlAndData(
				  'addRelationModalContent.html', 
				 	'addRelationModalController','xs', '', $scope);
	};
	
	$scope.open = function ($event) {
        $event.preventDefault();
        $event.stopPropagation();
        $scope.opened = true;
    };
    
    $scope.myBirthDayFunction = function(){
    	alert("hi");
		//$scope.patient.age = DateUtils.getAgeFromDate($scope.patient.dateOfBirth);
		var year = $filter('date')(new Date(),'yyyy');
		alert(year);
		var day = $filter('date')(new Date(),'dd');
		alert(day);
		var month = $filter('date')(new Date(),'MMM');
		alert(month);
		 year = year - 10;
		 
		 alert(new Date('day/month/year'));
		
	};
    
    $scope.setRelationInPatient = function(relationObj, fullName){
    	$scope.patient.relationships.push(relationObj);
    	/*if($scope.editMode){
    		fullName = relationObj.relative.firstName;
    	}*/
    	var html ='<div class="form-group">'
    			+'<div class="row">'
					+'<div class="col-lg-5" style="word-wrap: break-word;">'
						+'<label class="form-control input-sm">'+ fullName +'</label>'
					+'</div>'
					+'<div class="col-lg-5">'
						+'<label class="form-control input-sm"> '+ $scope.relationNameMap[relationObj.relationId] +'</label>'
					+'</div>'
					+'<div class="col-lg-2">'
						+'<button data-ng-disabled="deleteButton"' 
						+'data-ng-click="deleteRelationDiv($event, relationObj)" class="btn btn-default btn-sm" type="button">'
					+'<span class="fa fa-times"></span>'
					+'</button>' 
						+'</div>'
					+'</div>'
					+'</div>';
    			angular.element(document.getElementById('appendRelations')).append($compile(html)($scope));
    };
    
    $scope.deleteRelationDiv = function(event, relationObj){
    	$scope.patient.relationships.pop(relationObj);
    	angular.element(event.target).parent().parent().parent().remove();
    };
    
    $scope._addContactInfo = function() {
   	 $scope.addContactInfoButton = true;
		var contantDivSize = $('#contactInfoDiv #cantactSubDiv').length;
		console.log("contantDivSize >>" +contantDivSize);
		if(contantDivSize > 2){
			return false;
		}
		var html ='<div class="form-group" id="cantactSubDiv"><div class="row">'
				+ '<div class="col-lg-5">'
					+ '<input type="text" class="form-control input-sm" name="currentPhoneNumber" placeholder="Emergency Contact"/>'
				+'</div>'
				+'<div class="col-lg-5">'
					+'<select class="form-control input-sm" name="currentRelationName">'
						+'<option data-ng-selected="selected" value="" >Select Relation</option>'
						+'<option data-ng-repeat="relationMaster in relationMasterList" value="{{relationMaster.id}}">{{relationMaster.name}}</option>'
					+'</select>'
				+'</div>'
				+'<div class="col-lg-2">'
				+ '<button data-ng-disabled="deleteButton" data-ng-click="deleteContactDiv($event)" class="btn btn-default btn-sm" type="button"><span class="fa fa-times"></span>'
				+ '</button>' 
				+ '</div>'
				+ '</div> </div>';
		angular.element(document.getElementById('contactInfoDiv')).append($compile(html)($scope));
		$scope.addContactInfoButton = false;
	};
	
	$scope.deleteContactDiv = function(event, object){
		$scope.deleteButton = true;
		angular.element(event.target).parent().parent().parent().remove();
		$scope.deleteButton = false;
		$scope.addContactInfoButton = false;
	};
	
});


app.controller("addRelationModalController", function($scope, $modalInstance, ajaxService){
	$scope.initRelation = function(){
		$scope.relationObj = {};
	};
	
	$scope.getPatient = function(val) {
		var data =  $scope.getPatientFromServer(val);
		console.log("data :: "+JSON.stringify(data));
		return data;
	};
	
	$scope.getPatientFromServer = function (val) {
		console.log("In Relation");
		return ajaxService.getDataFromServer('/patient/customAutoSearch', val).then(
				function success(response) {			
					var patients = response.data.data.map(function (patient) {	
						var patientFullName = patient.firstName + ' ' +  patient.middleName + ' ' + patient.lastName;
						var patientDisplayString = '';
						patientDisplayString += (patient.firstName + ' ' +  patient.middleName + ' ' + patient.lastName); 
						patientDisplayString += (' | ' + patient.patientId + ' | ');
						patientDisplayString += (patient.phoneNumber ? patient.phoneNumber : ''); 
						
						var pd = new Object();
						pd.patientDisplayName = patientDisplayString;
						pd.mongoId = patient.id;					
						pd.patientFullName = patientFullName;
						return pd; 
					});
					return patients;
				}
			);
	};

	$scope.displayPatient = function (pd) {
		//$scope.relationObj.userId = $scope.selectedPatientSync.mongoId;
	};
	
	$scope.submitRelation = function(){
		if($scope.addRelationForm.$valid){
			$scope.addRelationButton = true;
			$scope.relationObj.userId = $scope.selectedPatientSync.mongoId;
			$scope.setRelationInPatient($scope.relationObj, $scope.selectedPatientSync.patientFullName);
			$modalInstance.close();
		}else{
			$scope.addRelationForm.submitted = true;
			$scope.addRelationButton = false;
		}
		
	};
	
	$scope.close = function (){
		$modalInstance.close();
    };
});

app.controller("addPatientSuccessPopUpCtrl", function($scope, $modalInstance, $state){
	$scope.closeModal = function(){
		$modalInstance.close();
	};
});