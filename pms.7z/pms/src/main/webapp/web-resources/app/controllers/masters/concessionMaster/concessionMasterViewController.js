app.controller("concessionView", ['$scope', '$state', 'ajaxService','toaster', 'modalUtil','$stateParams',
       function ($scope, $state, ajaxService, toaster, modalUtil, $stateParams) {
	
	$scope.init = function() {
		$scope.concessionFormData = [];
		
		$scope.itemsPerPage = 1;
	    $scope.currentPage = 1;
	    $scope.maxSize = 5;
		
		$scope.searchCriteria_Concession = '';
		$scope.search_Concession();
		concessionMap = {};
	};
	
	$scope.search_Concession = function(){
		$scope.concessionTable = false;
		var search = {
			key : "name",
			value : $scope.searchCriteria_Concession,
			operation  : "or",
		};		
		ajaxService.firePostRequest('/concession/search',
				search,
				$scope.searchSuccess,
				$scope.searchFailed
		);
	};
	
	$scope.searchSuccess = function ( response ) {
		if(response.data != null && response.data != ""){
			$scope.concessionFormData = response.data;
			
			$scope.totalItems = $scope.concessionFormData.length;
		    $scope.pageCount = function () {
			     return Math.ceil($scope.concessionFormData.length / $scope.itemsPerPage);
			   };

		   $scope.$watch('currentPage + itemsPerPage', function() {
			     var begin = (($scope.currentPage - 1) * $scope.itemsPerPage),
			         end = begin + $scope.itemsPerPage;
			     	$scope.filteredConcessionFormData = $scope.concessionFormData.slice(begin, end);
			   });
			
			$scope.concessionTable = true;
			angular.forEach($scope.concessionFormData, function(value, key){
				concessionMap[value.id] = value;
			});
		}else{
			toaster.clear();
	    	toaster.pop('warning', "No Record Found", '');
		}
	};
	
	$scope.searchFailed = function ( response ) {			
		console.log("error");
	};
	
	$scope.delete_Concession = function(concessionId){
		var concessionObj = concessionMap[concessionId];
		modalUtil.createModalWithControllerUrl(
			 	'Confirm', 
			 	'Are you sure you want to delete '+concessionObj.name +' record ?',
			 	'concessionMasterModalViewCtrl' ,'md', concessionId, $scope);
	};
	
}]);
app.controller("concessionMasterModalViewCtrl", function($scope, $modalInstance, datas, ajaxService){
	$scope.ok = function(){
		var deleteObj = {};
		deleteObj.id = datas;
		ajaxService.firePostRequest('/concession/delete',
				deleteObj,
				$scope.deleteSuccess,
				$scope.deleteFailed
		);
		$modalInstance.close();
	};
	
	$scope.cancel = function () {
        $modalInstance.dismiss('cancel');
    };
    
    $scope.deleteSuccess = function ( response ) {			
		$scope.search_Concession();
	};
	
	$scope.deleteFailed = function ( response ) {			
		console.log("error");
	};
});