app.controller("refferMasterAdd", ['$scope', '$state','ajaxService', '$stateParams',
       function ($scope, $state, ajaxService, $stateParams) {
	
	$scope.init = function(){
		$scope.refferFromData = {};
		$scope.refferFromData.status = true;
		$scope.id = $stateParams.id;
		$scope.editMode = false;
		if($scope.id != null){
			$scope.getrefferById($scope.id);
			$scope.editMode = true;
		}
	};
	
	$scope.cancel = function(){
		$state.go('app.refferMasterView', { reload : false });
	};
	
	$scope.getrefferById = function(id){
		var getObj = {};
			getObj.id = id;
		ajaxService.firePostRequest('/reffer/get',
				getObj,
				$scope.getEditObjSuccess,
				$scope.getEditObjFailed
		);
	};
	
	$scope.getEditObjFailed = function ( response ) {			
		console.log("error");
	};
	
	$scope.getEditObjSuccess = function ( response ) {
		$scope.refferFromData =  response.data;
		
		if($scope.refferFromData.status == "ACTIVE"){
			$scope.refferFromData.status = true;
		}else{
			$scope.refferFromData.status = false;
		}
	};
	
	$scope.submit= function(){
		if($scope.refferFrom.$valid){
			var data = {};
			var URL = "";
			data = $scope.refferFromData;
			
			if($scope.editMode){
				$scope.refferFromData.id = $scope.id;
				URL = '/reffer/update' ;
			} 
			else {
				URL = '/reffer/add';
			}
			if($scope.refferFromData.status == true){
				data.status = "ACTIVE";
			}else{
				data.status = "INACTIVE";
			}
			ajaxService.firePostRequest(URL,
					data,
					$scope.requestSuccess,
					$scope.requestFailed
			);
		}else{
			$scope.refferFrom.submitted = true;
		}
	};
	
	$scope.requestSuccess = function ( response ) {			
		$state.go('app.refferMasterView');
	};
	
	$scope.requestFailed = function ( response ) {			
		console.log("error");
	};
}]);