app.controller("concessionMasterAdd", ['$scope', '$state', 'ajaxService', '$stateParams',
       function ($scope, $state, ajaxService, $stateParams) {
	
	$scope.init = function(){
		$scope.concessionFormData ={};
		$scope.concessionFormData.status = true;
		$scope.id = $stateParams.id;
		$scope.editMode = false;
		if($scope.id != null){
			$scope.getConcessionById($scope.id);
			$scope.editMode = true;
		}
		
	};
	
	$scope.cancel = function(){
		$state.go('app.concessionMasterView');
	};
	
	$scope.getConcessionById = function(id){
		var getObj = {};
			getObj.id = id;
		ajaxService.firePostRequest('/concession/get',
				getObj,
				$scope.getEditObjSuccess,
				$scope.getEditObjFailed
		);
	};
	
	$scope.getEditObjFailed = function ( response ) {			
		console.log("error");
	};
	
	$scope.getEditObjSuccess = function ( response ) {
		$scope.concessionFormData = response.data;
		
		if($scope.concessionFormData.status == "ACTIVE"){
			$scope.concessionFormData.status = true;
		}else{
			$scope.concessionFormData.status = false;
		}
	};
	
	$scope.submit= function(){
		if($scope.concessionForm.$valid){
		var data = {};
		var URL = "";
		$scope.concessionFormData.date = new Date();
		$scope.concessionFormData.addedBy = userId;
		data = $scope.concessionFormData;
		if($scope.editMode){
			$scope.concessionFormData.id = $scope.id;
			URL = '/concession/update' ;
		} 
		else {
			URL = '/concession/add';
		}
		if($scope.concessionFormData.status == true){
			data.status = "ACTIVE";
		}else{
			data.status = "INACTIVE";
		}
		ajaxService.firePostRequest(URL,
				data,
				$scope.requestSuccess,
				$scope.requestFailed
		);
		}else{
			$scope.concessionForm.submitted = true;
		}
	};
	$scope.requestSuccess = function ( response ) {			
		$state.go('app.concessionMasterView');
	};
	
	$scope.requestFailed = function ( response ) {			
		console.log("error");
	};
}]);