/**
 * 
 */

app.service('modalUtil', ['$http', '$modal', '$window', function ($http, $modal) {
	
	var getDefaultHTML = function(title, content) {
		retString = '<div class="modal-header">' +
				        '<h3 class="modal-title">' + title + '</h3>' +
				    '</div>' +
				    '<div class="modal-body">' +
				        content + 
				    '</div>' +
				    '<div class="modal-footer">' +
				        '<button class="btn btn-default" ng-click="ok()">OK</button>' +
				        '<button class="btn btn-default" ng-click="cancel()">Cancel</button>' +
				    '</div>';
		return retString;
	};
	
	return {
		
		createDefaultErrorModal : function(title, content, width){
			$modal.open({            
		           template : getDefaultHTML(title, content),
		           controller: 'ModalUtilCtrl',
		           size: width           
		       });
		},
		
		createModalWithTemplateUrl : function(templateUrl, width){
			$modal.open({            
		           template : templateUrl,
		           controller: 'ModalUtilCtrl',
		           size: width           
		       });
		},
		
		createModalWithControllerUrl : function(title, content, controller, width, data, $scope){
			$modal.open({            
		           template : getDefaultHTML(title, content),
		           controller: controller,
		           scope : $scope,
		           backdrop: 'static',
		           keyboard : false,
		           resolve : {
		        	   datas : function(){
		        		   return data;
		        	   }
		           },
		           size: width           
		       });
		},
		
		createModalWithCustomTemplateAndCtrl : function(templateUrl, controller, width){
			$modal.open({            
				templateUrl : templateUrl,
		        controller: controller,
		        size: width           
		       });
		},
		
		createModalWithCustomTemplateCtrlAndData : function(templateUrl, controller, width, data, $scope){
			$modal.open({            
				templateUrl : templateUrl,
		        controller: controller,
		        scope : $scope,
		        backdrop: 'static',
		        keyboard : false,
		        resolve : {
		          datas : function(){
		        	   return data;
		           }
		        },
		        size: width           
		     });
		}
		
	};
	
}]);

app.controller('ModalUtilCtrl', function ($scope, $modalInstance, $window) {

    $scope.ok = function () {
    	$modalInstance.close();
    	$window.location.href = '/pms/user/welcome';
    };

    $scope.cancel = function () {
        $modalInstance.dismiss('cancel');
    };
});