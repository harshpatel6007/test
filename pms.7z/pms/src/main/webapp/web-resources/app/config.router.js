﻿'use strict';
angular.module('app')
	.filter('camleCase', function() {
			return function(input) {
      input = input || '';
      return input.replace(/\w\S*/g, function(txt){return txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase();});
    	};
	})
	
    .run(
        [
            '$rootScope', '$state', '$stateParams', '$window', '$http',
            function($rootScope, $state, $stateParams, $window, $http) {
                $rootScope.$state = $state;
                $rootScope.$stateParams = $stateParams;          
                
                $rootScope.$on('$stateChangeStart', function (event, toState, toParams) {
	            	console.log("to state : " + JSON.stringify(toState));
	            	console.log("isUserLoggedIn : " + $rootScope.logged_userId);            	                	
	            	
	            	if(toState.data.requireLogin && !$rootScope.logged_userId) {
	            		console.log("login required");
	            		event.preventDefault();
	            		$state.go("login");
	            	}             	 
           		}); 
            }
        ]
    )
    .config(
        [
            '$stateProvider', '$urlRouterProvider', 
            function($stateProvider, $urlRouterProvider) {
            	console.log("in router resourcePath : " + resourcePath);
            	
            	if(userId) {
            		$urlRouterProvider.otherwise('/app/dashboard');
            	} else {
            		$urlRouterProvider.otherwise('login');
            	}
                
                $stateProvider
                    .state('app', {
                        abstract: true,
                        url: '/app',
                        templateUrl: resourcePath + '/views/pms/layout.html',
                        data : {
                        	requireLogin : true
                        }
                    })
                    .state('app.dashboard', {
                        url: '/dashboard',
                        templateUrl: contextPath + '/user/dashboard/' + userId,
                        ncyBreadcrumb: {
                            label: 'Dashboard',
                            description: ''
                        },
                        data : {
                        	requireLogin : true
                        },
                        resolve: {
                            deps: [
                                '$ocLazyLoad',
                                function($ocLazyLoad) {                                	
                                	return $ocLazyLoad.load(['toaster', 'daterangepicker']).then(
                                        function() {
                                            return $ocLazyLoad.load(
                                            {
                                                serie: true,
                                                files: [
                                                        resourcePath + '/app/controllers/user/dashboard.js'
                                                ]
                                            });
                                        }
                                	);                                	
                                }
                            ]
                        }
                    })
                    .state('app.addPatient', {
                        url: '/addPatient',
                        templateUrl:  contextPath + '/patientWebController/addPatient',
                        ncyBreadcrumb: {
                            label: 'Add Patient',
                            description: ''
                        },
                        data : {
                        	requireLogin : true
                        },
                        resolve: {
                            deps: [
                                '$ocLazyLoad',
                                function($ocLazyLoad) {                                	
                                	return $ocLazyLoad.load(['toaster']).then(
                                        function() {
                                            return $ocLazyLoad.load(
                                            {
                                                serie: true,
                                                files: [
                                                        resourcePath + '/app/controllers/patient/addPatientController.js'
                                                ]
                                            });
                                        }
                                	);                                	
                                }
                            ]
                        }
                    })
                    .state('app.editPatient', {
                        url: '/editPatient?id',
                        templateUrl:  contextPath + '/patientWebController/addPatient',
                        ncyBreadcrumb: {
                            label: 'Add Patient',
                            description: ''
                        },
                        data : {
                        	requireLogin : true
                        },
                        resolve: {
                            deps: [
                                '$ocLazyLoad',
                                function($ocLazyLoad) {                                	
                                	return $ocLazyLoad.load(['toaster']).then(
                                        function() {
                                            return $ocLazyLoad.load(
                                            {
                                                serie: true,
                                                files: [
                                                        resourcePath + '/app/controllers/patient/addPatientController.js'
                                                ]
                                            });
                                        }
                                	);                                	
                                }
                            ]
                        }
                    })
                    .state('app.searchPatient', {
                        url: '/searchPatient',
                        templateUrl:  contextPath + '/patientWebController/searchPatient',
                        ncyBreadcrumb: {
                            label: 'Search Patient',
                            description: ''
                        },
                        data : {
                        	requireLogin : true
                        },
                        resolve: {
                            deps: [
                                '$ocLazyLoad',
                                function($ocLazyLoad) {                                	
                                	return $ocLazyLoad.load(['toaster']).then(
                                        function() {
                                            return $ocLazyLoad.load(
                                            {
                                                serie: true,
                                                files: [
                                                        resourcePath + '/app/controllers/patient/searchPatientController.js'
                                                ]
                                            });
                                        }
                                	);                                	
                                }
                            ]
                        }
                    })
                    .state('app.addAppointment', {
                        url: '/addAppointment',
                        templateUrl:  resourcePath + '/views/pms/addAppointment.jsp',
                        ncyBreadcrumb: {
                            label: 'Add Appointment',
                            description: ''
                        },
                        data : {
                        	requireLogin : true
                        }
                    })
                    .state('app.arrivedPatient', {
                        url: '/arrivedPatient',
                        templateUrl:  resourcePath + '/views/pms/arrivedPatient.jsp',
                        ncyBreadcrumb: {
                            label: 'Arrived Patient',
                            description: ''
                        },
                        data : {
                        	requireLogin : true
                        }
                    })
                    .state('app.readyPatient', {
                        url: '/readyPatient',
                        templateUrl:  resourcePath + '/views/pms/readyPatient.jsp',
                        ncyBreadcrumb: {
                            label: 'Ready Patients',
                            description: ''
                        },
                        data : {
                        	requireLogin : true
                        }
                    })
                    .state('app.curedPatient', {
                        url: '/curedPatient',
                        templateUrl:  resourcePath + '/views/pms/curedPatient.jsp',
                        ncyBreadcrumb: {
                            label: 'Cured Patient',
                            description: ''
                        },
                        data : {
                        	requireLogin : true
                        }
                    })
                    .state('app.settings', {
                        url: '/settings',
                        templateUrl:  resourcePath + '/views/pms/settings.jsp',
                        ncyBreadcrumb: {
                            label: 'Settings',
                            description: '',
                            
                        },
                        data : {
                        	requireLogin : true
                        }
                    })
                               
                    .state('app.reports', {
                        url: '/reports',
                        templateUrl:  resourcePath + '/views/pms/reports.jsp',
                        ncyBreadcrumb: {
                            label: 'Reports',
                            description: ''                            
                        },
                        data : {
                        	requireLogin : true
                        }
                    })
                    .state('login', {
                        url: '/login',
                        templateUrl: resourcePath + '/views/pms/user/login.html',
                        ncyBreadcrumb: {
                            label: 'Login',
                            description: 'Login Here'
                        },
                        params : {
                        	dontCheckCookie : false 
                        },
                        data : {
                        	requireLogin : false
                        },
                        resolve: {
                            deps: [
                                '$ocLazyLoad',
                                function($ocLazyLoad) {                                	
                                	return $ocLazyLoad.load(['toaster']).then(
                                        function() {
                                            return $ocLazyLoad.load(
                                            {
                                                serie: true,
                                                files: [
                                                        resourcePath + '/app/controllers/user/login.js'
                                                ]
                                            });
                                        }
                                	);                                	
                                }
                            ]
                        }
                     })
                      /** ----View Role -----**/ 
                    .state('app.roleView', {
                        url: '/viewRole',
                        templateUrl:  contextPath + '/roleWebController/view',
                        ncyBreadcrumb: {
                            label: 'Role View',
                            description: '',
                            
                        },
                        data : {
                        	requireLogin : true
                        },
                        resolve: {
                            deps: [
                                '$ocLazyLoad',
                                function($ocLazyLoad) {                                	
                                	return $ocLazyLoad.load(['toaster']).then(
                                        function() {
                                            return $ocLazyLoad.load(
                                            {
                                                serie: true,
                                                files: [
                                                        resourcePath + '/app/controllers/role/roleViewController.js'
                                                ]
                                            });
                                        }
                                	);                                	
                                }
                            ]
                        }
                    })
                     /** ------------ Add Role ----------------**/ 
                    .state('app.roleAdd', {
                        url: '/addRole',
                        templateUrl:  contextPath + '/roleWebController/manage',
                        ncyBreadcrumb: {
                            label: 'Role Add',
                            description: '',
                            parent : "app.roleView"
                        },
                        data : {
                        	requireLogin : true
                        },
                        resolve: {
                            deps: [
                                '$ocLazyLoad',
                                function($ocLazyLoad) {                                	
                                	return $ocLazyLoad.load(['toaster']).then(
                                        function() {
                                            return $ocLazyLoad.load(
                                            {
                                                serie: true,
                                                files: [
                                                        resourcePath + '/app/controllers/role/roleManageController.js'
                                                ]
                                            });
                                        }
                                	);                                	
                                }
                            ]
                        }
                        
                    })          
                     /*---------------------------------------*/
                     /*----------------- User Add ------------*/
                    .state('app.userAdd', {
                        url: '/userAdd',
                        templateUrl:  contextPath + '/user/manage',
                        ncyBreadcrumb: {
                            label: "User Add",
                            description: '',
                        },
                        resolve: {
                            deps: [
                                '$ocLazyLoad',
                                function($ocLazyLoad) {                                	
                                	return $ocLazyLoad.load(['toaster']).then(
                                        function() {
                                            return $ocLazyLoad.load(
                                            {
                                                serie: true,
                                                files: [
                                                        	resourcePath + '/app/controllers/user/userAddController.js' 
                                                ]
                                            });
                                        }
                                	);                                	
                                }
                            ]
                        }
                        
                    })
                    
                    .state('app.userEdit', {
                        url: '/:id?edit',
                        templateUrl:  contextPath + '/user/manage',
                        ncyBreadcrumb: {
                            label: "User Edit",
                            description: '',
                        },
                        resolve: {
                            deps: [
                                '$ocLazyLoad',
                                function($ocLazyLoad) {                                	
                                	return $ocLazyLoad.load(['toaster']).then(
                                        function() {
                                            return $ocLazyLoad.load(
                                            {
                                                serie: true,
                                                files: [
                                                        	resourcePath + '/app/controllers/user/userAddController.js' 
                                                ]
                                            });
                                        }
                                	);                                	
                                }
                            ]
                        }
                        
                    })
                    .state('app.userView', {
                        url: '/userView',
                        templateUrl:  resourcePath + '/views/pms/user/userView.jsp',
                        ncyBreadcrumb: {
                            label: "User View",
                            description: '',
                        },
                        resolve: {
                            deps: [
                                '$ocLazyLoad',
                                function($ocLazyLoad) {                                	
                                	return $ocLazyLoad.load(['toaster']).then(
                                        function() {
                                            return $ocLazyLoad.load(
                                            {
                                                serie: true,
                                                files: [	
                                                        	resourcePath + '/app/controllers/user/userViewController.js' 
                                                ]
                                            });
                                        }
                                	);                                	
                                }
                            ]
                        }
                    })

                    .state('app.userDetailView', {
                        url: '/:id?',
                        templateUrl:  resourcePath + '/views/pms/user/userDetailView.jsp',
                        ncyBreadcrumb: {
                            label: "User View",
                            description: '',
                        },
                        resolve: {
                            deps: [
                                '$ocLazyLoad',
                                function($ocLazyLoad) {                                	
                                	return $ocLazyLoad.load(['toaster']).then(
                                        function() {
                                            return $ocLazyLoad.load(
                                            {
                                                serie: true,
                                                files: [
                                                        	resourcePath + '/app/controllers/user/userDetailViewController.js' 
                                                ]
                                            });
                                        }
                                	);                                	
                                }
                            ]
                        }
                    })
                    
                    .state('app.userProfile', {
                        url: '/userProfile',
                        templateUrl:  resourcePath + '/views/pms/user/userProfile.jsp',
                        ncyBreadcrumb: {
                            label: "User Profile",
                            description: '',
                        },
                        resolve: {
                            deps: [
                                '$ocLazyLoad',
                                function($ocLazyLoad) {                                	
                                	return $ocLazyLoad.load(['toaster']).then(
                                        function() {
                                            return $ocLazyLoad.load(
                                            {
                                                serie: true,
                                                files: [
                                                        	resourcePath + '/app/controllers/user/userProfileController.js' 
                                                ]
                                            });
                                        }
                                	);                                	
                                }
                            ]
                        }
                    })
                    
                     /*--------------------------------------*/
                    
                    /* Role Edit */
                    .state('app.roleEdit', {
	                    url: '/:id?edit',
	                    templateUrl:  contextPath + '/roleWebController/manage',
	                    ncyBreadcrumb: {
	                        label: "Role Edit",
	                        description: '',
	                        parent : "app.roleView"
	                    },
	                    resolve: {
	                        deps: [
	                            '$ocLazyLoad',
	                            function($ocLazyLoad) {                                	
	                            	return $ocLazyLoad.load(['toaster']).then(
	                                    function() {
	                                        return $ocLazyLoad.load(
	                                        {
	                                            serie: true,
	                                            files: [
	                                                    	resourcePath + '/app/controllers/role/roleManageController.js'
	                                            ]
	                                        });
	                                    }
	                            	);                                	
	                            }
	                        ]
	                    }
	                })
                     /*----------------- Religion Master ------------*/
                    .state('app.religionMaster', {
                        url: '/religionMaster',
                        templateUrl:  resourcePath + '/views/pms/masters/religionMasterView.jsp',
                        ncyBreadcrumb: {
                            label: "Religion Master View",
                            description: '',
                            parent :'app.settings'
                        },
                        resolve: {
                            deps: [
                                '$ocLazyLoad',
                                function($ocLazyLoad) {                                	
                                	return $ocLazyLoad.load(['toaster']).then(
                                        function() {
                                            return $ocLazyLoad.load(
                                            {
                                                serie: true,
                                                files: [
                                                        resourcePath + '/app/controllers/masters/religionMaster/religionMasterViewController.js'
                                                ]
                                            });
                                        }
                                	);                                	
                                }
                            ]
                        }
                        
                    })
                    .state('app.religionMasterAdd', {
                        url: '/addReligion?id',
                        templateUrl:  resourcePath + '/views/pms/masters/religionMasterMange.jsp',
                        ncyBreadcrumb: {
                            label: "Religion Master Add",
                            description: '',
                            parent :'app.religionMaster'
                        },
                        resolve: {
                            deps: [
                                '$ocLazyLoad',
                                function($ocLazyLoad) {                                	
                                	return $ocLazyLoad.load(['toaster']).then(
                                        function() {
                                            return $ocLazyLoad.load(
                                            {
                                                serie: true,
                                                files: [
                                                        resourcePath + '/app/controllers/masters/religionMaster/religionMasterManageController.js'
                                                ]
                                            });
                                        }
                                	);                                	
                                }
                            ]
                        },
                        data : {
                        	requireLogin : true
                        }
                    })
                    .state('app.religionMasterEdit', {
	                    url: '/?id',
	                    templateUrl:  resourcePath + '/views/pms/masters/religionMasterMange.jsp',
	                    ncyBreadcrumb: {
	                        label: "Religion Master Edit",
	                        description: '',
	                        parent :'app.religionMaster'
	                    },
	                    resolve: {
	                        deps: [
	                            '$ocLazyLoad',
	                            function($ocLazyLoad) {                                	
	                            	return $ocLazyLoad.load(['toaster']).then(
	                                    function() {
	                                        return $ocLazyLoad.load(
	                                        {
	                                            serie: true,
	                                            files: [
	                                                    resourcePath + '/app/controllers/masters/religionMaster/religionMasterManageController.js'
	                                            ]
	                                        });
	                                    }
	                            	);                                	
	                            }
	                        ]
	                    }
	                })
	                /*----------------- Relation Master ------------*/
	                .state('app.relationMaster', {
                        url: '/relationMaster',
                        templateUrl:  resourcePath + '/views/pms/masters/relationMasterView.jsp',
                        ncyBreadcrumb: {
                            label: "Relation Master View",
                            description: '',
                            parent :'app.settings'
                        },
                        resolve: {
                            deps: [
                                '$ocLazyLoad',
                                function($ocLazyLoad) {                                	
                                	return $ocLazyLoad.load(['toaster']).then(
                                        function() {
                                            return $ocLazyLoad.load(
                                            {
                                                serie: true,
                                                files: [
                                                        resourcePath + '/app/controllers/masters/relationMaster/relationMasterViewController.js'
                                                ]
                                            });
                                        }
                                	);                                	
                                }
                            ]
                        }
                        
                    })
                    .state('app.relationMasterAdd', {
                        url: '/addRelation',
                        templateUrl:  resourcePath + '/views/pms/masters/relationMasterMange.jsp',
                        ncyBreadcrumb: {
                            label: "Relation Master Add",
                            description: '',
                            parent :'app.relationMaster'
                        },
                        resolve: {
                            deps: [
                                '$ocLazyLoad',
                                function($ocLazyLoad) {                                	
                                	return $ocLazyLoad.load(['toaster']).then(
                                        function() {
                                            return $ocLazyLoad.load(
                                            {
                                                serie: true,
                                                files: [
                                                        resourcePath + '/app/controllers/masters/relationMaster/relationMasterManageController.js'
                                                ]
                                            });
                                        }
                                	);                                	
                                }
                            ]
                        },
                        data : {
                        	requireLogin : true
                        }
                    })
                    .state('app.relationMasterEdit', {
	                    url: '/:id?edit',
	                    templateUrl:  resourcePath + '/views/pms/masters/relationMasterMange.jsp',
	                    ncyBreadcrumb: {
	                        label: "Relation Master Edit",
	                        description: '',
	                        parent :'app.relationMaster'
	                    },
	                    resolve: {
	                        deps: [
	                            '$ocLazyLoad',
	                            function($ocLazyLoad) {                                	
	                            	return $ocLazyLoad.load(['toaster']).then(
	                                    function() {
	                                        return $ocLazyLoad.load(
	                                        {
	                                            serie: true,
	                                            files: [
	                                                    resourcePath + '/app/controllers/masters/relationMaster/relationMasterManageController.js'
	                                            ]
	                                        });
	                                    }
	                            	);                                	
	                            }
	                        ]
	                    }
	                })
	                 /*----------------- User Type Master ------------*/
	                 
	                .state('app.userTypeMaster', {
	                	 url: '/userTypeMasterManage',
                        templateUrl:  resourcePath + '/views/pms/masters/userTypeMasterManage.jsp',
                        ncyBreadcrumb: {
                        	 label: 'User Type Master Add',
                            description: '',
                            parent :'app.userTypeMasterView'
                        },
                        resolve: {
                            deps: [
                                '$ocLazyLoad',
                                function($ocLazyLoad) {                                	
                                	return $ocLazyLoad.load(['toaster']).then(
                                        function() {
                                            return $ocLazyLoad.load(
                                            {
                                                serie: true,
                                                files: [
                                                        resourcePath + '/app/controllers/masters/userTypeMaster/userTypeMasterManageController.js'
                                                ]
                                            });
                                        }
                                	);                                	
                                }
                            ]
                        }
                    })
                    
                    .state('app.userTypeMasterEdit', {
	                	 url: '/:id?edit',
                        templateUrl:  resourcePath + '/views/pms/masters/userTypeMasterManage.jsp',
                        ncyBreadcrumb: {
                        	 label: 'User Type Master Edit',
                            description: '',
                            parent :'app.settings'
                        },
                        resolve: {
                            deps: [
                                '$ocLazyLoad',
                                function($ocLazyLoad) {                                	
                                	return $ocLazyLoad.load(['toaster']).then(
                                        function() {
                                            return $ocLazyLoad.load(
                                            {
                                                serie: true,
                                                files: [
                                                        resourcePath + '/app/controllers/masters/userTypeMaster/userTypeMasterManageController.js'
                                                ]
                                            });
                                        }
                                	);                                	
                                }
                            ]
                        }
                    })
                    
                    .state('app.userTypeMasterView', {
                    	url: '/userTypeMasterView',
                    	templateUrl:  resourcePath + '/views/pms/masters/userTypeMasterView.jsp',
                        ncyBreadcrumb: {
                        	 label: 'User Type Master View',
                            description: '',
                            parent :'app.settings'
                        },
                        resolve: {
                            deps: [
                                '$ocLazyLoad',
                                function($ocLazyLoad) {                                	
                                	return $ocLazyLoad.load(['toaster']).then(
                                        function() {
                                            return $ocLazyLoad.load(
                                            {
                                                serie: true,
                                                files: [
                                                        resourcePath + '/app/controllers/masters/userTypeMaster/userTypeMasterViewController.js'
                                                ]
                                            });
                                        }
                                	);                                	
                                }
                            ]
                        }
                        
                    })
	                
                    /*------------------------------------------------*/	
                    
                    
                    /*----------------- Patient Type Master ------------*/
	                 
	                .state('app.patientTypeMaster', {
	                	 url: '/patientTypeMasterManage',
                        templateUrl:  resourcePath + '/views/pms/masters/patientTypeMasterManage.jsp',
                        ncyBreadcrumb: {
                        	 label: 'Patient Type Master Add',
                            description: '',
                            parent :'app.patientTypeMasterView'
                        },
                        resolve: {
                            deps: [
                                '$ocLazyLoad',
                                function($ocLazyLoad) {                                	
                                	return $ocLazyLoad.load(['toaster']).then(
                                        function() {
                                            return $ocLazyLoad.load(
                                            {
                                                serie: true,
                                                files: [
                                                        resourcePath + '/app/controllers/masters/patientMaster/patientTypeMasterManageController.js'
                                                ]
                                            });
                                        }
                                	);                                	
                                }
                            ]
                        }
                    })
                    
                    .state('app.patientTypeMasterEdit', {
	                	 url: '/:id?edit',
                        templateUrl:  resourcePath + '/views/pms/masters/patientTypeMasterManage.jsp',
                        ncyBreadcrumb: {
                        	 label: 'Patient Type Master Edit',
                            description: '',
                            parent :'app.settings'
                        },
                        resolve: {
                            deps: [
                                '$ocLazyLoad',
                                function($ocLazyLoad) {                                	
                                	return $ocLazyLoad.load(['toaster']).then(
                                        function() {
                                            return $ocLazyLoad.load(
                                            {
                                                serie: true,
                                                files: [
                                                        resourcePath + '/app/controllers/masters/patientMaster/patientTypeMasterManageController.js'
                                                ]
                                            });
                                        }
                                	);                                	
                                }
                            ]
                        }
                    })
                    
                    
                    .state('app.patientTypeMasterView', {
                    	url: '/patientTypeMasterView',
                    	templateUrl:  resourcePath + '/views/pms/masters/patientTypeMasterView.jsp',
                        ncyBreadcrumb: {
                        	 label: 'Patient Type Master View',
                            description: '',
                            parent :'app.settings'
                        },
                        resolve: {
                            deps: [
                                '$ocLazyLoad',
                                function($ocLazyLoad) {                                	
                                	return $ocLazyLoad.load(['toaster']).then(
                                        function() {
                                            return $ocLazyLoad.load(
                                            {
                                                serie: true,
                                                files: [
                                                        resourcePath + '/app/controllers/masters/patientMaster/patientTypeMasterViewController.js'
                                                ]
                                            });
                                        }
                                	);                                	
                                }
                            ]
                        }
                        
                    })
	                
                    /*------------------------------------------------*/
                    /*----------------- Drug Allergy Master ------------*/
	                 
	                .state('app.drugAllergyMaster', {
	                	 url: '/drugAllergyMasterManage',
                        templateUrl:  resourcePath + '/views/pms/masters/drugAllergyMasterManage.jsp',
                        ncyBreadcrumb: {
                        	 label: 'Drug Allergy Master Add',
                            description: '',
                            parent :'app.drugAllergyMasterView'
                        },
                        resolve: {
                            deps: [
                                '$ocLazyLoad',
                                function($ocLazyLoad) {                                	
                                	return $ocLazyLoad.load(['toaster']).then(
                                        function() {
                                            return $ocLazyLoad.load(
                                            {
                                                serie: true,
                                                files: [
                                                        resourcePath + '/app/controllers/masters/drugAlergyMaster/drugAllergyMasterManageController.js'
                                                ]
                                            });
                                        }
                                	);                                	
                                }
                            ]
                        }
                    })
                    
                    .state('app.drugAllergyMasterEdit', {
	                	 url: '/:id?edit',
                        templateUrl:  resourcePath + '/views/pms/masters/drugAllergyMasterManage.jsp',
                        ncyBreadcrumb: {
                        	 label: 'Drug Allergy Master Edit',
                            description: '',
                            parent :'app.settings'
                        },
                        resolve: {
                            deps: [
                                '$ocLazyLoad',
                                function($ocLazyLoad) {                                	
                                	return $ocLazyLoad.load(['toaster']).then(
                                        function() {
                                            return $ocLazyLoad.load(
                                            {
                                                serie: true,
                                                files: [
                                                        resourcePath + '/app/controllers/masters/drugAlergyMaster/drugAllergyMasterManageController.js'
                                                ]
                                            });
                                        }
                                	);                                	
                                }
                            ]
                        }
                    })
                    
                    .state('app.drugAllergyMasterView', {
                    	url: '/drugAllergyMasterView',
                    	templateUrl:  resourcePath + '/views/pms/masters/drugAllergyMasterView.jsp',
                        ncyBreadcrumb: {
                        	 label: 'Drug Allergy Master View',
                            description: '',
                            parent :'app.settings'
                        },
                        resolve: {
                            deps: [
                                '$ocLazyLoad',
                                function($ocLazyLoad) {                                	
                                	return $ocLazyLoad.load(['toaster']).then(
                                        function() {
                                            return $ocLazyLoad.load(
                                            {
                                                serie: true,
                                                files: [
                                                        resourcePath + '/app/controllers/masters/drugAlergyMaster/drugAllergyMasterViewController.js'
                                                ]
                                            });
                                        }
                                	);                                	
                                }
                            ]
                        }
                        
                    })
	                
                    /*------------------------------------------------*/
                    /*----------------- Diagnosis Master ------------*/
	                 
	                .state('app.diagnosisMaster', {
	                	 url: '/diagnosisMasterManage',
                        templateUrl:  resourcePath + '/views/pms/masters/diagnosisMasterManage.jsp',
                        ncyBreadcrumb: {
                        	 label: 'Diagnosis Master Add',
                            description: '',
                            parent :'app.diagnosisMasterView'
                        },
                        resolve: {
                            deps: [
                                '$ocLazyLoad',
                                function($ocLazyLoad) {                                	
                                	return $ocLazyLoad.load(['toaster']).then(
                                        function() {
                                            return $ocLazyLoad.load(
                                            {
                                                serie: true,
                                                files: [
                                                        resourcePath + '/app/controllers/masters/diagnosisMaster/diagnosisMasterManageController.js'
                                                ]
                                            });
                                        }
                                	);                                	
                                }
                            ]
                        }
                    })
                    
                    .state('app.diagnosisMasterEdit', {
	                	 url: '/:id?edit',
                        templateUrl:  resourcePath + '/views/pms/masters/diagnosisMasterManage.jsp',
                        ncyBreadcrumb: {
                        	 label: 'Diagnosis Master Edit',
                            description: '',
                            parent :'app.settings'
                        },
                        resolve: {
                            deps: [
                                '$ocLazyLoad',
                                function($ocLazyLoad) {                                	
                                	return $ocLazyLoad.load(['toaster']).then(
                                        function() {
                                            return $ocLazyLoad.load(
                                            {
                                                serie: true,
                                                files: [
                                                        resourcePath + '/app/controllers/masters/diagnosisMaster/diagnosisMasterManageController.js'
                                                ]
                                            });
                                        }
                                	);                                	
                                }
                            ]
                        }
                    })
                    
                    .state('app.diagnosisMasterView', {
                    	url: '/diagnosisMasterView',
                    	templateUrl:  resourcePath + '/views/pms/masters/diagnosisMasterView.jsp',
                        ncyBreadcrumb: {
                        	 label: 'Diagnosis Master View',
                            description: '',
                            parent :'app.settings'
                        },
                        resolve: {
                            deps: [
                                '$ocLazyLoad',
                                function($ocLazyLoad) {                                	
                                	return $ocLazyLoad.load(['toaster']).then(
                                        function() {
                                            return $ocLazyLoad.load(
                                            {
                                                serie: true,
                                                files: [
                                                        resourcePath + '/app/controllers/masters/diagnosisMaster/diagnosisMasterViewController.js'
                                                ]
                                            });
                                        }
                                	);                                	
                                }
                            ]
                        }
                        
                    })
	                
                    /*------------------------------------------------*/
                    
                    
                    /*----------------- Reffer Master ------------*/
	                 
	                .state('app.refferMaster', {
	                	 url: '/refferMasterManage',
                        templateUrl:  resourcePath + '/views/pms/masters/refferMasterManage.jsp',
                        ncyBreadcrumb: {
                        	 label: 'Reffer Master Add',
                            description: '',
                            parent :'app.refferMasterView'
                        },
                        resolve: {
                            deps: [
                                '$ocLazyLoad',
                                function($ocLazyLoad) {                                	
                                	return $ocLazyLoad.load(['toaster']).then(
                                        function() {
                                            return $ocLazyLoad.load(
                                            {
                                                serie: true,
                                                files: [
                                                        resourcePath + '/app/controllers/masters/refferMaster/refferMasterManageController.js'
                                                ]
                                            });
                                        }
                                	);                                	
                                }
                            ]
                        }
                    })
                    
                    .state('app.refferMasterEdit', {
	                	 url: '/:id?edit',
                        templateUrl:  resourcePath + '/views/pms/masters/refferMasterManage.jsp',
                        ncyBreadcrumb: {
                        	 label: 'Reffer Master Edit',
                            description: '',
                            parent :'app.settings'
                        },
                        resolve: {
                            deps: [
                                '$ocLazyLoad',
                                function($ocLazyLoad) {                                	
                                	return $ocLazyLoad.load(['toaster']).then(
                                        function() {
                                            return $ocLazyLoad.load(
                                            {
                                                serie: true,
                                                files: [
                                                        resourcePath + '/app/controllers/masters/refferMaster/refferMasterManageController.js'
                                                ]
                                            });
                                        }
                                	);                                	
                                }
                            ]
                        }
                    })
                    
                    .state('app.refferMasterView', {
                    	url: '/refferMasterView',
                    	templateUrl:  resourcePath + '/views/pms/masters/refferMasterView.jsp',
                        ncyBreadcrumb: {
                        	 label: 'Reffer Master View',
                            description: '',
                            parent :'app.settings'
                        },
                        resolve: {
                            deps: [
                                '$ocLazyLoad',
                                function($ocLazyLoad) {                                	
                                	return $ocLazyLoad.load(['toaster']).then(
                                        function() {
                                            return $ocLazyLoad.load(
                                            {
                                                serie: true,
                                                files: [
                                                        resourcePath + '/app/controllers/masters/refferMaster/refferMasterViewController.js'
                                                ]
                                            });
                                        }
                                	);                                	
                                }
                            ]
                        }
                        
                    })
	                
                    /*------------------------------------------------*/

                    /*----------------- Item Master ------------*/
	                 
	                .state('app.itemMaster', {
	                	 url: '/itemMasterManage',
                        templateUrl:  resourcePath + '/views/pms/masters/itemTypeMasterManage.jsp',
                        ncyBreadcrumb: {
                        	 label: 'Item Master Add',
                            description: '',
                            parent :'app.itemMasterView'
                        },
                        resolve: {
                            deps: [
                                '$ocLazyLoad',
                                function($ocLazyLoad) {                                	
                                	return $ocLazyLoad.load(['toaster']).then(
                                        function() {
                                            return $ocLazyLoad.load(
                                            {
                                                serie: true,
                                                files: [
                                                        resourcePath + '/app/controllers/masters/itemTypeMaster/itemTypeMasterManageController.js'
                                                ]
                                            });
                                        }
                                	);                                	
                                }
                            ]
                        }
                    })
                    
                    .state('app.itemMasterEdit', {
	                	 url: '/:id?edit',
                        templateUrl:  resourcePath + '/views/pms/masters/itemTypeMasterManage.jsp',
                        ncyBreadcrumb: {
                        	 label: 'Item Master Edit',
                            description: '',
                            parent :'app.settings'
                        },
                        resolve: {
                            deps: [
                                '$ocLazyLoad',
                                function($ocLazyLoad) {                                	
                                	return $ocLazyLoad.load(['toaster']).then(
                                        function() {
                                            return $ocLazyLoad.load(
                                            {
                                                serie: true,
                                                files: [
                                                        resourcePath + '/app/controllers/masters/itemTypeMaster/itemTypeMasterManageController.js'
                                                ]
                                            });
                                        }
                                	);                                	
                                }
                            ]
                        }
                    })
                    
                    .state('app.itemMasterView', {
                    	url: '/itemMasterView',
                    	templateUrl:  resourcePath + '/views/pms/masters/itemTypeMasterView.jsp',
                        ncyBreadcrumb: {
                        	 label: 'Item Master View',
                            description: '',
                            parent :'app.settings'
                        },
                        resolve: {
                            deps: [
                                '$ocLazyLoad',
                                function($ocLazyLoad) {                                	
                                	return $ocLazyLoad.load(['toaster']).then(
                                        function() {
                                            return $ocLazyLoad.load(
                                            {
                                                serie: true,
                                                files: [
                                                        resourcePath + '/app/controllers/masters/itemTypeMaster/itemTypeMasterViewController.js'
                                                ]
                                            });
                                        }
                                	);                                	
                                }
                            ]
                        }
                        
                    })
	                
                    /*------------------------------------------------*/
                    
                    /*----------------- Concession Master ------------*/
	                 
	                .state('app.concessionMaster', {
	                	 url: '/concessionMasterManage',
                        templateUrl:  resourcePath + '/views/pms/masters/concessionMasterManage.jsp',
                        ncyBreadcrumb: {
                        	 label: 'Concession Master Add',
                            description: '',
                            parent :'app.concessionMasterView'
                        },
                        resolve: {
                            deps: [
                                '$ocLazyLoad',
                                function($ocLazyLoad) {                                	
                                	return $ocLazyLoad.load(['toaster']).then(
                                        function() {
                                            return $ocLazyLoad.load(
                                            {
                                                serie: true,
                                                files: [
                                                        resourcePath + '/app/controllers/masters/concessionMaster/concessionMasterManageController.js'
                                                ]
                                            });
                                        }
                                	);                                	
                                }
                            ]
                        }
                    })
                    
                    .state('app.concessionMasterEdit', {
	                	 url: '/:id?edit',
                        templateUrl:  resourcePath + '/views/pms/masters/concessionMasterManage.jsp',
                        ncyBreadcrumb: {
                        	 label: 'Concession Master Edit',
                            description: '',
                            parent :'app.settings'
                        },
                        resolve: {
                            deps: [
                                '$ocLazyLoad',
                                function($ocLazyLoad) {                                	
                                	return $ocLazyLoad.load(['toaster']).then(
                                        function() {
                                            return $ocLazyLoad.load(
                                            {
                                                serie: true,
                                                files: [
                                                        resourcePath + '/app/controllers/masters/concessionMaster/concessionMasterManageController.js'
                                                ]
                                            });
                                        }
                                	);                                	
                                }
                            ]
                        }
                    })
                    
                    .state('app.concessionMasterView', {
                    	url: '/concessionMasterView',
                    	templateUrl:  resourcePath + '/views/pms/masters/concessionMasterView.jsp',
                        ncyBreadcrumb: {
                        	 label: 'Concession Master View',
                            description: '',
                            parent :'app.settings'
                        },
                        resolve: {
                            deps: [
                                '$ocLazyLoad',
                                function($ocLazyLoad) {                                	
                                	return $ocLazyLoad.load(['toaster']).then(
                                        function() {
                                            return $ocLazyLoad.load(
                                            {
                                                serie: true,
                                                files: [
                                                        resourcePath + '/app/controllers/masters/concessionMaster/concessionMasterViewController.js'
                                                ]
                                            });
                                        }
                                	);                                	
                                }
                            ]
                        }
                        
                    })
	                
                    /*------------------------------------------------*/
                    
                    /*----------------- Occupation Master ------------*/
	                 
	                .state('app.occupationMaster', {
	                	 url: '/occupationMasterManage',
                        templateUrl:  resourcePath + '/views/pms/masters/occupationMasterManage.jsp',
                        ncyBreadcrumb: {
                        	 label: 'Occupation Master Add',
                            description: '',
                            parent :'app.occupationMasterView'
                        },
                        resolve: {
                            deps: [
                                '$ocLazyLoad',
                                function($ocLazyLoad) {                                	
                                	return $ocLazyLoad.load(['toaster']).then(
                                        function() {
                                            return $ocLazyLoad.load(
                                            {
                                                serie: true,
                                                files: [
                                                        resourcePath + '/app/controllers/masters/occupationMaster/occupationMasterManageController.js'
                                                ]
                                            });
                                        }
                                	);                                	
                                }
                            ]
                        }
                    })
                    
                    .state('app.occupationMasterEdit', {
	                	 url: '/:id?edit',
                        templateUrl:  resourcePath + '/views/pms/masters/occupationMasterManage.jsp',
                        ncyBreadcrumb: {
                        	 label: 'Occupation Master Edit',
                            description: '',
                            parent :'app.settings'
                        },
                        resolve: {
                            deps: [
                                '$ocLazyLoad',
                                function($ocLazyLoad) {                                	
                                	return $ocLazyLoad.load(['toaster']).then(
                                        function() {
                                            return $ocLazyLoad.load(
                                            {
                                                serie: true,
                                                files: [
                                                        resourcePath + '/app/controllers/masters/occupationMaster/occupationMasterManageController.js'
                                                ]
                                            });
                                        }
                                	);                                	
                                }
                            ]
                        }
                    })
                    
                    
                    .state('app.occupationMasterView', {
                    	url: '/occupationMasterView',
                    	templateUrl:  resourcePath + '/views/pms/masters/occupationMasterView.jsp',
                        ncyBreadcrumb: {
                        	 label: 'Occupation Master View',
                            description: '',
                            parent :'app.settings'
                        },
                        resolve: {
                            deps: [
                                '$ocLazyLoad',
                                function($ocLazyLoad) {                                	
                                	return $ocLazyLoad.load(['toaster']).then(
                                        function() {
                                            return $ocLazyLoad.load(
                                            {
                                                serie: true,
                                                files: [
                                                        resourcePath + '/app/controllers/masters/occupationMaster/occupationMasterViewController.js'
                                                ]
                                            });
                                        }
                                	);                                	
                                }
                            ]
                        }
                        
                    })
	                
                    /*------------------------------------------------*/	
                    
	                
	                 /*----------------- Country Master ------------*/
	                .state('app.countryMaster', {
                        url: '/country',
                        templateUrl:  resourcePath + '/views/pms/masters/countryMasterView.jsp',
                        ncyBreadcrumb: {
                            label: "Country Master View",
                            description: '',
                            parent :'app.settings'
                        },
                        resolve: {
                            deps: [
                                '$ocLazyLoad',
                                function($ocLazyLoad) {                                	
                                	return $ocLazyLoad.load(['toaster']).then(
                                        function() {
                                            return $ocLazyLoad.load(
                                            {
                                                serie: true,
                                                files: [
                                                        resourcePath + '/app/controllers/masters/countryMaster/countryMasterViewController.js'
                                                ]
                                            });
                                        }
                                	);                                	
                                }
                            ]
                        }
                        
                    })
                    .state('app.countryMasterAdd', {
                        url: '/addCountry',
                        templateUrl:  resourcePath + '/views/pms/masters/countryMasterMange.jsp',
                        ncyBreadcrumb: {
                            label: "Country Master Add",
                            description: '',
                            parent :'app.countryMaster'
                        },
                        resolve: {
                            deps: [
                                '$ocLazyLoad',
                                function($ocLazyLoad) {                                	
                                	return $ocLazyLoad.load(['toaster']).then(
                                        function() {
                                            return $ocLazyLoad.load(
                                            {
                                                serie: true,
                                                files: [
                                                        resourcePath + '/app/controllers/masters/countryMaster/countryMasterManageController.js'
                                                ]
                                            });
                                        }
                                	);                                	
                                }
                            ]
                        },
                        data : {
                        	requireLogin : true
                        }
                    })
                    .state('app.countryMasterEdit', {
	                    url: '/:id?edit',
	                    templateUrl:  resourcePath + '/views/pms/masters/countryMasterMange.jsp',
	                    ncyBreadcrumb: {
	                        label: "Country Master Edit",
	                        description: '',
	                        parent :'app.countryMaster'
	                    },
	                    resolve: {
	                        deps: [
	                            '$ocLazyLoad',
	                            function($ocLazyLoad) {                                	
	                            	return $ocLazyLoad.load(['toaster']).then(
	                                    function() {
	                                        return $ocLazyLoad.load(
	                                        {
	                                            serie: true,
	                                            files: [
	                                                    resourcePath + '/app/controllers/masters/countryMaster/countryMasterManageController.js'
	                                            ]
	                                        });
	                                    }
	                            	);                                	
	                            }
	                        ]
	                    }
	                })
	                /** ------------- State Master -------------**/
	                .state('app.stateMaster', {
                        url: '/state',
                        templateUrl:  contextPath + '/stateMasterWeb/view',
                        ncyBreadcrumb: {
                            label: "State Master View",
                            description: '',
                            parent :'app.settings'
                        },
                        resolve: {
                            deps: [
                                '$ocLazyLoad',
                                function($ocLazyLoad) {                                	
                                	return $ocLazyLoad.load(['toaster']).then(
                                        function() {
                                            return $ocLazyLoad.load(
                                            {
                                                serie: true,
                                                files: [
                                                        resourcePath + '/app/controllers/masters/stateMaster/stateMasterViewController.js'
                                                ]
                                            });
                                        }
                                	);                                	
                                }
                            ]
                        }
                        
                    })
                    .state('app.stateMasterAdd', {
                        url: '/addState',
                        templateUrl:  contextPath + '/stateMasterWeb/manage',
                        ncyBreadcrumb: {
                            label: "State Master Add",
                            description: '',
                            parent :'app.stateMaster'
                        },
                        resolve: {
                            deps: [
                                '$ocLazyLoad',
                                function($ocLazyLoad) {                                	
                                	return $ocLazyLoad.load(['toaster']).then(
                                        function() {
                                            return $ocLazyLoad.load(
                                            {
                                                serie: true,
                                                files: [
                                                        resourcePath + '/app/controllers/masters/stateMaster/stateMasterManageController.js'
                                                ]
                                            });
                                        }
                                	);                                	
                                }
                            ]
                        },
                        data : {
                        	requireLogin : true
                        }
                    })
                    .state('app.stateMasterEdit', {
	                    url: '/:id?edit',
	                    templateUrl:  contextPath + '/stateMasterWeb/manage',
	                    ncyBreadcrumb: {
	                        label: "State Master Edit",
	                        description: '',
	                        parent :'app.stateMaster'
	                    },
	                    resolve: {
	                        deps: [
	                            '$ocLazyLoad',
	                            function($ocLazyLoad) {                                	
	                            	return $ocLazyLoad.load(['toaster']).then(
	                                    function() {
	                                        return $ocLazyLoad.load(
	                                        {
	                                            serie: true,
	                                            files: [
	                                                    resourcePath + '/app/controllers/masters/stateMaster/stateMasterManageController.js'
	                                            ]
	                                        });
	                                    }
	                            	);                                	
	                            }
	                        ]
	                    }
	                })
	                /** ------------- Document Type Master -------------**/
	                .state('app.documentTypeMasterView', {
                        url: '/viewDocumentType',
                        templateUrl:  contextPath + '/documentTypeMasterWeb/view',
                        ncyBreadcrumb: {
                            label: "Document Type View",
                            description: '',
                            parent :'app.settings'
                        },
                        resolve: {
                            deps: [
                                '$ocLazyLoad',
                                function($ocLazyLoad) {                                	
                                	return $ocLazyLoad.load(['toaster']).then(
                                        function() {
                                            return $ocLazyLoad.load(
                                            {
                                                serie: true,
                                                files: [
                                                        resourcePath + '/app/controllers/masters/documentTypeMaster/documentTypeMasterViewController.js'
                                                ]
                                            });
                                        }
                                	);                                	
                                }
                            ]
                        },
                        data : {
                        	requireLogin : true
                        }
                    })
                    .state('app.documentTypeMasterAdd', {
                        url: '/addDocumentType',
                        templateUrl:  contextPath + '/documentTypeMasterWeb/manage',
                        ncyBreadcrumb: {
                            label: "Document Type Add",
                            description: '',
                            parent :'app.documentTypeMasterView'
                        },
                        resolve: {
                            deps: [
                                '$ocLazyLoad',
                                function($ocLazyLoad) {                                	
                                	return $ocLazyLoad.load(['toaster']).then(
                                        function() {
                                            return $ocLazyLoad.load(
                                            {
                                                serie: true,
                                                files: [
                                                        resourcePath + '/app/controllers/masters/documentTypeMaster/documentTypeMasterManageController.js'
                                                ]
                                            });
                                        }
                                	);                                	
                                }
                            ]
                        },
                        data : {
                        	requireLogin : true
                        }
                    })
                    .state('app.documentTypeMasterEdit', {
                        url: '/:id?edit',
                        templateUrl:  contextPath + '/documentTypeMasterWeb/manage',
                        ncyBreadcrumb: {
                            label: "Document Type Edit",
                            description: '',
                            parent :'app.documentTypeMasterView'
                        },
                        resolve: {
                            deps: [
                                '$ocLazyLoad',
                                function($ocLazyLoad) {                                	
                                	return $ocLazyLoad.load(['toaster']).then(
                                        function() {
                                            return $ocLazyLoad.load(
                                            {
                                                serie: true,
                                                files: [
                                                        resourcePath + '/app/controllers/masters/documentTypeMaster/documentTypeMasterManageController.js'
                                                ]
                                            });
                                        }
                                	);                                	
                                }
                            ]
                        },
                        data : {
                        	requireLogin : true
                        }
                    })
                    .state('app.documentSubTypeMasterView', {
                        url: '/viewSubDocumentType',
                        templateUrl:  contextPath + '/documentSubTypeMasterWeb/view',
                        ncyBreadcrumb: {
                            label: "Document Sub Type View",
                            description: '',
                            parent :'app.settings'
                        },
                        resolve: {
                            deps: [
                                '$ocLazyLoad',
                                function($ocLazyLoad) {                                	
                                	return $ocLazyLoad.load(['toaster']).then(
                                        function() {
                                            return $ocLazyLoad.load(
                                            {
                                                serie: true,
                                                files: [
                                                        resourcePath + '/app/controllers/masters/documentSubTypeMaster/documentSubTypeMasterViewController.js'
                                                ]
                                            });
                                        }
                                	);                                	
                                }
                            ]
                        },
                        data : {
                        	requireLogin : true
                        }
                    })
                    .state('app.documentSubTypeMasterAdd', {
                        url: '/addSubDocumentType',
                        templateUrl:  contextPath + '/documentSubTypeMasterWeb/manage',
                        ncyBreadcrumb: {
                            label: "Document Sub Type Add",
                            description: '',
                            parent :'app.documentSubTypeMasterView'
                        },
                        resolve: {
                            deps: [
                                '$ocLazyLoad',
                                function($ocLazyLoad) {                                	
                                	return $ocLazyLoad.load(['toaster']).then(
                                        function() {
                                            return $ocLazyLoad.load(
                                            {
                                                serie: true,
                                                files: [
                                                        resourcePath + '/app/controllers/masters/documentSubTypeMaster/documentSubTypeMasterManageController.js'
                                                ]
                                            });
                                        }
                                	);                                	
                                }
                            ]
                        },
                        data : {
                        	requireLogin : true
                        }
                    })
                    .state('app.documentSubTypeMasterEdit', {
                    	url: '/:id?edit',
                        templateUrl:  contextPath + '/documentSubTypeMasterWeb/manage',
                        ncyBreadcrumb: {
                            label: "Document Sub Type Edit",
                            description: '',
                            parent :'app.documentSubTypeMasterView'
                        },
                        resolve: {
                            deps: [
                                '$ocLazyLoad',
                                function($ocLazyLoad) {                                	
                                	return $ocLazyLoad.load(['toaster']).then(
                                        function() {
                                            return $ocLazyLoad.load(
                                            {
                                                serie: true,
                                                files: [
                                                        resourcePath + '/app/controllers/masters/documentSubTypeMaster/documentSubTypeMasterManageController.js'
                                                ]
                                            });
                                        }
                                	);                                	
                                }
                            ]
                        },
                        data : {
                        	requireLogin : true
                        }
                    })
                    .state('lock', {
                        url: '/lock',
                        templateUrl:  resourcePath + '/views/pms/lock.jsp',                       
                        ncyBreadcrumb: {
                            label: 'Lock',
                            description: ''                            
                        },
                        data : {
                        	requireLogin : true
                        },
                        resolve: {
                            deps: [
                                '$ocLazyLoad',
                                function($ocLazyLoad) {                                	
                                	return $ocLazyLoad.load(['toaster']).then(
                                        function() {
                                            return $ocLazyLoad.load(
                                            {
                                                serie: true,
                                                files: [
                                                        resourcePath + '/app/controllers/user/lock.js'
                                                ]
                                            });
                                        }
                                	);                                	
                                }
                            ]
                        }
                    })
                    .state('app.patient', {
                        url: '/patient',
                        templateUrl:  resourcePath + '/views/pms/patient/patientCommonView.jsp',                        
                        ncyBreadcrumb: {
                            label: 'Patient View',
                            description: ''                            
                        },
                        data : {
                        	requireLogin : true
                        },
                        params : {
                        	patientId : null
                        },
                        resolve: {
                            deps: [
                                '$ocLazyLoad',
                                function($ocLazyLoad) {                                	
                                	return $ocLazyLoad.load(['toaster']).then(
                                        function() {
                                            return $ocLazyLoad.load(
                                            {
                                                serie: true,
                                                files: [
                                                        resourcePath + '/app/controllers/patient/commonView.js'
                                                ]
                                            });
                                        }
                                	);                                	
                                }
                            ]
                        }
                    })
                    .state('app.patient.detailView', {
                    	url: '/detailView',
                        templateUrl:  resourcePath + '/views/pms/patient/patientDetailView.jsp',
                        ncyBreadcrumb: {
                            label: "Detail View",
                            description: '',
                        },
                        params : {
                        	patient : null,
                        	visit : null
                        },
                        data : {
                        	requireLogin : true
                        },
                        resolve: {
                            deps: [
                                '$ocLazyLoad',
                                function($ocLazyLoad) {                                	
                                	return $ocLazyLoad.load(['toaster','ui.select']).then(		
                                        function() {
                                            return $ocLazyLoad.load(
                                            {
                                                serie: true,
                                                files: [
//                                                        resourcePath + '/app/controllers/patient/detailView.js', 
                                                        resourcePath + '/app/controllers/clinicNote/clinicNoteAddController.js',
                                                        resourcePath + '/app/controllers/patient/patientInfoView.js',
                                                        resourcePath + '/app/controllers/patient/uploadDocumentController.js'
                                                ]
                                            });
                                        }
                                	);                                	
                                }
                            ]
                        }                 	
                    });
            }
        ]
    );
