angular.module('app')
    .config([
        '$ocLazyLoadProvider', function ($ocLazyLoadProvider) {
        	console.log("find module");
            $ocLazyLoadProvider.config({
                debug: true,
                events: true,
                modules: [
                    {
                        name: 'toaster',
                        files: [
                            resourcePath + '/lib/modules/angularjs-toaster/toaster.css',
                            resourcePath + '/lib/modules/angularjs-toaster/toaster.js'
                        ]
                    },
                    {
                        name: 'ui.select',
                        files: [
                            resourcePath + '/lib/modules/angular-ui-select/select.css',
                            resourcePath + '/lib/modules/angular-ui-select/select.js'
                        ]
                    },
                    {
                        name: 'ngTagsInput',
                        files: [
                            resourcePath + '/lib/modules/ng-tags-input/ng-tags-input.js'
                        ]
                    },
                    {
                        name: 'daterangepicker',
                        serie: true,
                        files: [
                            resourcePath + '/lib/modules/angular-daterangepicker/moment.js',
                            resourcePath + '/lib/modules/angular-daterangepicker/daterangepicker.js',
                            resourcePath + '/lib/modules/angular-daterangepicker/angular-daterangepicker.js'
                        ]
                    },
                    {
                        name: 'vr.directives.slider',
                        files: [
                            resourcePath + '/lib/modules/angular-slider/angular-slider.min.js'
                        ]
                    },
                    {
                        name: 'minicolors',
                        files: [
                            resourcePath + '/lib/modules/angular-minicolors/jquery.minicolors.js',
                            resourcePath + '/lib/modules/angular-minicolors/angular-minicolors.js'
                        ]
                    },
                    {
                        name: 'textAngular',
                        files: [
                            resourcePath + '/lib/modules/text-angular/textAngular-sanitize.min.js',
                            resourcePath + '/lib/modules/text-angular/textAngular-rangy.min.js',
                            resourcePath + '/lib/modules/text-angular/textAngular.min.js'
                        ]
                    },
                    {
                        name: 'ng-nestable',
                        files: [
                            resourcePath + '/lib/modules/angular-nestable/jquery.nestable.js',
                            resourcePath + '/lib/modules/angular-nestable/angular-nestable.js'
                        ]
                    },
                    {
                        name: 'angularBootstrapNavTree',
                        files: [
                            resourcePath + '/lib/modules/angular-bootstrap-nav-tree/abn_tree_directive.js'
                        ]
                    },
                    {
                        name: 'ui.calendar',
                        files: [
                            resourcePath + '/lib/jquery/fullcalendar/jquery-ui.custom.min.js',
                            resourcePath + '/lib/jquery/fullcalendar/moment.min.js',
                            resourcePath + '/lib/jquery/fullcalendar/fullcalendar.js',
                            resourcePath + '/lib/modules/angular-ui-calendar/calendar.js'
                        ]
                    },
                    {
                        name: 'ngGrid',
                        files: [
                            resourcePath + '/lib/modules/ng-grid/ng-grid.min.js',
                            resourcePath + '/lib/modules/ng-grid/ng-grid.css'
                        ]
                    },
                    {
                        name: 'dropzone',
                        files: [
                            resourcePath + '/lib/modules/angular-dropzone/dropzone.min.js',
                            resourcePath + '/lib/modules/angular-dropzone/angular-dropzone.js'
                        ]
                    }
                ]
            });
        }
    ]);