package com.slktechlabs.pms.system.model.visit;

public enum VisitStatus {

	SCHEDULED("SCHEDULED"),
	ARRIVED("ARRIVED"),
	READY("READY"),	
	IN_CLINIC("IN_CLINIC"),		
	COMPLETE("COMPLETE"),
	CANCELLED("CANCELLED");
	
	private String status;
	
	private VisitStatus(String status) {
		this.status = status;
	}

	public String getStatus() {
		return status;
	}
	
	
}
