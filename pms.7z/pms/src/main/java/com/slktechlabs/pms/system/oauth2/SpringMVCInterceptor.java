package com.slktechlabs.pms.system.oauth2;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import com.slktechlabs.pms.system.exception.AuthException;
import com.slktechlabs.pms.system.util.RequestUtils;

public class SpringMVCInterceptor extends HandlerInterceptorAdapter {

	private final Logger logger = Logger.getLogger(SpringMVCInterceptor.class);

	public boolean checkAuth(HttpServletRequest request){
		
		String token_id = RequestUtils.getTokenID(request);

		if (token_id == null) {
			return false;
		}

		return true;
	}

	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
		
		boolean approved = checkAuth(request);
		if(!approved){
			throw new AuthException("Your AccessToken is not valid. So login again");
		}
		
		return approved;
	}

}
