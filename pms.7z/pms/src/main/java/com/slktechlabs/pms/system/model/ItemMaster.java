package com.slktechlabs.pms.system.model;

import java.util.Date;

import org.springframework.data.mongodb.core.mapping.Document;

import com.slktechlabs.pms.system.annotation.CustomJoin;
import com.slktechlabs.pms.system.constants.MasterStatus;

@Document(collection = "itemMaster")
public class ItemMaster extends AbstractDocument {

	private String name;
//	private ItemType type;
	private String code;
	private Double price;
	private Date date;
	private MasterStatus status;
	private String createdBy;
	@CustomJoin(joinId = "createdBy", value = { "displayName" }, isInclude = true)
	private User user;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

//	public ItemType getType() {
//		return type;
//	}
//
//	public void setType(ItemType type) {
//		this.type = type;
//	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public Double getPrice() {
		return price;
	}

	public void setPrice(Double price) {
		this.price = price;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public MasterStatus getStatus() {
		return status;
	}

	public void setStatus(MasterStatus status) {
		this.status = status;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	@Override
	public String toString() {
		return "ItemMaster [name=" + name + ", code=" + code + ", price="
				+ price + ", date=" + date + ", status=" + status
				+ ", createdBy=" + createdBy + ", user=" + user + "]";
	}

}
