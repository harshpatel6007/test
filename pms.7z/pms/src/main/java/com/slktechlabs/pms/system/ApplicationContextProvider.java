package com.slktechlabs.pms.system;

import java.io.File;
import java.nio.file.AccessDeniedException;
import java.util.Set;

import org.apache.log4j.Logger;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.servlet.mvc.method.RequestMappingInfo;
import org.springframework.web.servlet.mvc.method.annotation.RequestMappingHandlerMapping;

import com.slktechlabs.pms.system.constants.SettingsConstants;
import com.slktechlabs.pms.system.oauth2.SessionListener;

//@Component
public class ApplicationContextProvider implements ApplicationContextAware {

	Logger logger = Logger.getLogger(this.getClass());

	@Value("${saveFolderLocation}")
	private String saveFolderLocation;

	@Autowired
	SessionListener sessionListener;

	private static ApplicationContext applicationContext;

	@Override
	public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {

		logger.info("---------------ApplicationContext------------------->> ");
		
//		ConfigurableWebApplicationContext context =  (ConfigurableWebApplicationContext) applicationContext;
//		
//		try {
//			Properties props = PropertiesLoaderUtils.loadAllProperties(applicationMode+"_lang.properties");
//			PropertiesPropertySource ps = new PropertiesPropertySource("lang", props);
//			context.getEnvironment().getPropertySources().addFirst(ps);
//		} catch (IOException e1) {
//			logger.error(e1.getMessage(), e1);
//		}
		
		ApplicationContextProvider.applicationContext = applicationContext;

		WebApplicationContext webApplicationContext = (WebApplicationContext) applicationContext;

		logger.info("getRealPath -------------->> " + webApplicationContext.getServletContext().getRealPath(""));

		SettingsConstants.DOCUMENT_ROOT_PATH = webApplicationContext.getServletContext().getRealPath("");
		/*
		 * List down all requestMapping
		 */
		getRequestMappingUrlFromWAC(webApplicationContext);

		/*
		 * List down all Bean ....
		 */
		getBeanListFromWAC(webApplicationContext);

		try {
			setHmisDataPath();
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
		}

		webApplicationContext.getServletContext().addListener(sessionListener);
	}

	private void setHmisDataPath() throws Exception {

		logger.info("saveFolderLocation:-- " + saveFolderLocation);

		File file;

		if (saveFolderLocation.isEmpty()) {
			file = new File(SettingsConstants.DOCUMENT_ROOT_PATH + File.separator + "HMIS-App-Documents");
		} else {
			file = new File(saveFolderLocation);
		}
		file.mkdirs();
		if (!file.canExecute()) {
			throw new AccessDeniedException(file.getPath() + " :: File can not read and Write...");
		}

		logger.info("Data will be Stored Here:-- " + file.getPath());
		SettingsConstants.setDataPath(file.getPath());
	}

	private void getBeanListFromWAC(WebApplicationContext webApplicationContext) {
		String[] all = webApplicationContext.getBeanDefinitionNames();

		logger.info("-------------->>> Start List Bean size :---- >>>>-------------" + all.length);
		/*
		 * for (String string : all) { logger.info(string); }
		 */
		logger.info("-------------->>> End List Bean :---- >>>>-------------");
	}

	private void getRequestMappingUrlFromWAC(WebApplicationContext webApplicationContext) {
		RequestMappingHandlerMapping requestMappingHandlerMapping = webApplicationContext.getBean(RequestMappingHandlerMapping.class);

		Set<RequestMappingInfo> rmSet = requestMappingHandlerMapping.getHandlerMethods().keySet();

		logger.info("-------------->>> Start List URL size :---- >>>>-------------" + rmSet.size());
		/*
		 * for (RequestMappingInfo rm : rmSet) {
		 * logger.info(rm.getPatternsCondition().toString()); }
		 */
		logger.info("-------------->>> End List URL >>>>-------------");
	}

	public static Object getBean(String name) {
		return applicationContext.getBean(name);
	}

}
