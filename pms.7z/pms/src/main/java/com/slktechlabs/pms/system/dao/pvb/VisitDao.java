package com.slktechlabs.pms.system.dao.pvb;

import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Repository;

import com.slktechlabs.pms.system.dao.HMISDao;
import com.slktechlabs.pms.system.model.visit.ScanDocumentDetails;
import com.slktechlabs.pms.system.model.visit.Visit;
import com.slktechlabs.pms.system.model.visit.VisitStatus;


/**
 * @author harsh.patel
 *
 */
@Repository
public class VisitDao extends HMISDao<Visit, String> {

	private Logger logger = Logger.getLogger(VisitDao.class);

	public List<Visit> getAppointedVisitsforUser(String userId, Date from,
			Date to) {
		
		Query query = new Query();
		
		if(userId != null) {
			query.addCriteria(Criteria.where("createdBy")
					.is(userId));
		}
		
		query.addCriteria(Criteria.where("appointmentDetail.appointmentDate")
				.gte(from).lte(to));
		
		return find(query);
		
	}

	public List<Visit> getVisitsForUser(String userId, Date from, Date to) {
		Query query = new Query();
		
		if(userId != null) {
			query.addCriteria(Criteria.where("createdBy").is(userId));
		}
		
		query.addCriteria(Criteria.where("createdDate").gte(from).lte(to));
		
		return find(query);
	}

	public List<Visit> getVisitsOfPatient(String patientId) {
		Query query = new Query();
		query.addCriteria(Criteria.where("patientId").is(patientId));
		query.with(new Sort(Direction.DESC, "createdDate"));
		return find(query);
	}

	public Visit updateScanDocument(ScanDocumentDetails scanDocumentDetails,
			String visitId) {
		Query query = new Query();
		query.addCriteria(Criteria.where("_id").is(visitId));
		
		Update update = new Update();
		update.push("scanDocumentDetails", scanDocumentDetails);
		update(query, update, "Update Scan Document");
		return findOne(query);
	}

	public Visit getScanDocumentByUuid(String documentUuid) {
		Query query = new Query();
		query.addCriteria(Criteria.where("scanDocumentDetails.uuid").is(documentUuid));
		query.fields().include("scanDocumentDetails");
		return findOne(query);
	}

	public void changeStatus(String visitId, String userId, VisitStatus status) {
		
		Query query = new Query();
		query.addCriteria(Criteria.where("_id").is(visitId));
		
		Update update = new Update();
		update.set("status", status);
		
		switch (status) {
			case ARRIVED:
				update.set("arrivedDate", new Date());
				update.set("markArrivedBy", userId);
				break;
			case READY:
				update.set("markReadyDate", new Date());
				update.set("markReadyBy", userId);
				break;
			case IN_CLINIC:
				update.set("inclinicDate", new Date());
				update.set("markInclinicBy", userId);
				break;
			default:
				break;
		}
		
		update(query, update, "Change Status to " + status.name());
	}
	
}
