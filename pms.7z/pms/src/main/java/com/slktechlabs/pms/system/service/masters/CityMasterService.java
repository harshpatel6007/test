package com.slktechlabs.pms.system.service.masters;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.slktechlabs.pms.system.dao.masters.CityMasterDao;
import com.slktechlabs.pms.system.model.master.CityMaster;
import com.slktechlabs.pms.system.service.HMISService;

@Service
public class CityMasterService extends HMISService<CityMaster, String>{
	CityMasterDao cityMasterDao;
	
	@Autowired
	public CityMasterService(CityMasterDao cityMasterDao) {
		super(cityMasterDao);
		this.cityMasterDao = cityMasterDao;
	}

}
