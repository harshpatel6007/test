package com.slktechlabs.pms.system.dao;


import java.util.List;

import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Repository;

import com.slktechlabs.pms.system.constants.MasterStatus;
import com.slktechlabs.pms.system.model.SearchCriteria;
import com.slktechlabs.pms.system.model.role.Role;
import com.slktechlabs.pms.system.util.SearchUtils;

@Repository
public class RoleDao extends HMISDao<Role, String> {
	public List<Role> autoSearchRole(SearchCriteria searchCriteria){
		Query query = new Query();
    	if (searchCriteria != null) {
    		query.addCriteria(Criteria.where(searchCriteria.getKey())
        		.regex(SearchUtils.getRegexPatternForSearchAtStart(searchCriteria.getValue()), "i"));
    	}
    	query.with(new Sort(Direction.DESC, "modified"));        
    	return findAll(query);
	}
	
	public List<Role> searchRole(SearchCriteria searchCriteria){
		Query query = new Query();
		if(searchCriteria!=null){
			String value = SearchUtils.getRegexPatternForSearchWithinText(searchCriteria.getValue());
			query.addCriteria(Criteria.where(searchCriteria.getKey()).regex(value, "i"));
		}
		query.with(new Sort(Sort.Direction.ASC, "name"));
		return findAll(query);
	}

	public void changeStatus(String roleId, MasterStatus status) {
		Query query = new Query();
		query.addCriteria(Criteria.where("_id").is(roleId));
		Update update = new Update();
		update.set("status", status);
		update(query, update, "changeStatus to " + status);
	}
}
