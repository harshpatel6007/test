package com.slktechlabs.pms.system.controller.masters;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.slktechlabs.pms.system.annotation.RequestBodyParam;
import com.slktechlabs.pms.system.constants.StatusConstants;
import com.slktechlabs.pms.system.constants.MessageConstants.UserMessagesEnum;
import com.slktechlabs.pms.system.model.SearchCriteria;
import com.slktechlabs.pms.system.model.Response.ResponseBean;
import com.slktechlabs.pms.system.model.master.RelationMaster;
import com.slktechlabs.pms.system.service.masters.RelationMasterService;
import com.slktechlabs.pms.system.util.ResponseGenerator;

@Controller
@RequestMapping("relationMaster")
public class RelationMasterController {
	@Autowired
	RelationMasterService relationMasterService;

	@RequestMapping(value ="add", method= RequestMethod.POST)
	@ResponseBody
	public ResponseBean add(@RequestBody RelationMaster relationMaster) {

		Boolean exist = relationMasterService.uniqueCheck("name", relationMaster.getName(), relationMaster.getId());
		if(exist){
			return ResponseGenerator.generateResponse(StatusConstants.error, UserMessagesEnum.UNIQUE.message("name"));
		}
		relationMasterService.save(relationMaster, "Relation Master Add");
		return ResponseGenerator.generateResponse(StatusConstants.success,
				UserMessagesEnum.ADD_SUCCESS.message("Relation Master"), relationMaster);
	}
	
	@RequestMapping(value ="update", method= RequestMethod.POST)
	@ResponseBody
	public ResponseBean update(@RequestBody RelationMaster relationMaster) {
		Boolean exist = relationMasterService.uniqueCheck("name", relationMaster.getName(), relationMaster.getId());
		if(exist){
			return ResponseGenerator.generateResponse(StatusConstants.error, UserMessagesEnum.UNIQUE.message("name"));
		}
		relationMasterService.update(relationMaster, "Relation Master Update");
		return ResponseGenerator.generateResponse(StatusConstants.success,
				UserMessagesEnum.UPDATE_SUCCESS.message("Relation Master"), relationMaster);
	}
	
	@RequestMapping(value ="search", method= RequestMethod.POST)
	@ResponseBody
	public ResponseBean search(@RequestBody SearchCriteria searchCriteria) {
		return ResponseGenerator.generateResponse(StatusConstants.success,
				relationMasterService.search(searchCriteria));
	}
	
	@RequestMapping(value ="delete", method= RequestMethod.POST)
	@ResponseBody
	public ResponseBean delete(@RequestBodyParam String id) {
		relationMasterService.delete(id);
		return ResponseGenerator.generateResponse(StatusConstants.success,
				UserMessagesEnum.DELETE_SUCCESS.message("Relation Master"));
	}
	
	@RequestMapping(value ="get", method= RequestMethod.POST)
	@ResponseBody
	public ResponseBean get(@RequestBodyParam String id) {
		return ResponseGenerator.generateResponse(StatusConstants.success,
				relationMasterService.findOne(id));
	}
	
	@RequestMapping(value ="getRelationMasterList", method= RequestMethod.POST)
	@ResponseBody
	public ResponseBean getRelationMasterList() {
		return ResponseGenerator.generateResponse(StatusConstants.success,
				relationMasterService.getRelationMasterList());
	}

}
