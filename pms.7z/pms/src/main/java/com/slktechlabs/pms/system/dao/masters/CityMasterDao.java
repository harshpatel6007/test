package com.slktechlabs.pms.system.dao.masters;

import org.springframework.stereotype.Repository;

import com.slktechlabs.pms.system.dao.HMISDao;
import com.slktechlabs.pms.system.model.master.CityMaster;

@Repository
public class CityMasterDao extends HMISDao<CityMaster, String>{

}
