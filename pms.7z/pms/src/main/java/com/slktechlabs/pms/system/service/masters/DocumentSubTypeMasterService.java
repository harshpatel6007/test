package com.slktechlabs.pms.system.service.masters;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.slktechlabs.pms.system.dao.masters.DocumentSubTypeMasterDao;
import com.slktechlabs.pms.system.model.master.DocumentSubTypeMaster;
import com.slktechlabs.pms.system.service.HMISService;

@Service
public class DocumentSubTypeMasterService extends HMISService<DocumentSubTypeMaster, String>{
	DocumentSubTypeMasterDao documentSubTypeMasterDao;	
	
	@Autowired
	public DocumentSubTypeMasterService(DocumentSubTypeMasterDao documentSubTypeMasterDao) {
		super(documentSubTypeMasterDao);
		this.documentSubTypeMasterDao = documentSubTypeMasterDao;
	}

	public List<DocumentSubTypeMaster> search(String documentSubTypeName, String documentTypeId) {
		return documentSubTypeMasterDao.search(documentSubTypeName, documentTypeId);
	}

	public boolean checkDocumentTypeMasterExist(String documentTypeId) {
		return documentSubTypeMasterDao.checkDocumentTypeMasterExist(documentTypeId);
	}

	public List<DocumentSubTypeMaster> getByDocTypeId(String docTypeId) {
		return documentSubTypeMasterDao.getByDocTypeId(docTypeId);
	}

}
