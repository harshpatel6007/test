package com.slktechlabs.pms.system.controller.web;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

import com.slktechlabs.pms.system.service.masters.DocumentTypeMasterService;

@Controller
@RequestMapping("documentSubTypeMasterWeb")
public class DocumentSubTypeMasterWebController {
	@Autowired
	DocumentTypeMasterService documentTypeMasterService;
	
	private final String PAGE_PREFIX = "pms/masters/documentSubTypeMaster/";
	
	@RequestMapping("view")
	public String view(ModelMap modelMap){
		modelMap.addAttribute("documentTypeMasterList", documentTypeMasterService.findAll_E());
		return PAGE_PREFIX + "documentSubTypeMasterView";
	}
	
	@RequestMapping("manage")
	public String manage(ModelMap modelMap){
		modelMap.addAttribute("documentTypeMasterList", documentTypeMasterService.findAll_E());
		return PAGE_PREFIX + "documentSubTypeMasterManage";
	}
}
