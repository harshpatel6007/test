package com.slktechlabs.pms.system.model.master;

import org.springframework.data.mongodb.core.mapping.Document;

import com.slktechlabs.pms.system.constants.MasterStatus;
import com.slktechlabs.pms.system.model.AbstractDocument;

@Document(collection = "documentTypeMaster")
public class DocumentTypeMaster extends AbstractDocument {

	private String name;
	private MasterStatus status;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public MasterStatus getStatus() {
		return status;
	}

	public void setStatus(MasterStatus status) {
		this.status = status;
	}

	@Override
	public String toString() {
		return "DocumentTypeMaster [name=" + name + ", status=" + status + "]";
	}

}
