package com.slktechlabs.pms.system.model.visit;

import java.util.Date;
import java.util.List;

import org.springframework.data.mongodb.core.mapping.Document;

import com.slktechlabs.pms.system.annotation.ApplyCustomJoin;
import com.slktechlabs.pms.system.annotation.CustomJoin;
import com.slktechlabs.pms.system.annotation.CustomJoinListToList;
import com.slktechlabs.pms.system.model.AbstractDocument;
import com.slktechlabs.pms.system.model.DiagnosisMaster;
import com.slktechlabs.pms.system.model.DrugAllergyMaster;
import com.slktechlabs.pms.system.model.User;
import com.slktechlabs.pms.system.model.patient.Patient;

@Document(collection = "visitCollection")
public class Visit extends AbstractDocument {

	private String patientId;
	@CustomJoin(joinId = "patientId", value = { "firstName", "fatherName",
			"lastName", "dateOfBirth", "age", "gender", "phoneNumber",
			"referalDoctor", "patientId", "emailId", "address" }, isInclude = true)
	private Patient patient;

	private Date createdDate;
	private String createdBy;
	@CustomJoin(joinId = "createdBy", value = { "displayName" }, isInclude = true)
	private User createdbyUser;
	@ApplyCustomJoin
	private AppointmentDetail appointmentDetail;

	private String visitNumber;
	private VisitStatus status;
	
	private Date arrivedDate;
	private String markArrivedBy;
	
	private Date markReadyDate;
	private String markReadyBy;
	
	private Date inclinicDate;
	private String markInclinicBy;
	
	@ApplyCustomJoin
	private List<ScanDocumentDetails> scanDocumentDetails;

	// Clinic Note Feilds
	private List<String> dignosisMasterId;
	@CustomJoinListToList(joinId = "dignosisMasterId", value = { "name" }, isInclude = true) 
	private List<DiagnosisMaster> diagnosisMaster;
	private int pulse;
	private int bloodPresure;
	private int bloodPresure1;
	private int height;
	private int weight;
	private int temparature;
	private List<String> drugAllergyMasterId;
	@CustomJoinListToList(joinId = "drugAllergyMasterId", value = { "name" }, isInclude = true)
	private List<DrugAllergyMaster> drugAllergyMaster;
	private boolean diabetic;
	private boolean hypertension;
	private String otherAllergy;
	
	private Boolean isWalkIn;
	

	public List<DiagnosisMaster> getDiagnosisMaster() {
		return diagnosisMaster;
	}

	public void setDiagnosisMaster(List<DiagnosisMaster> diagnosisMaster) {
		this.diagnosisMaster = diagnosisMaster;
	}

	public List<DrugAllergyMaster> getDrugAllergyMaster() {
		return drugAllergyMaster;
	}

	public void setDrugAllergyMaster(List<DrugAllergyMaster> drugAllergyMaster) {
		this.drugAllergyMaster = drugAllergyMaster;
	}

	public String getPatientId() {
		return patientId;
	}

	public void setPatientId(String patientId) {
		this.patientId = patientId;
	}

	public Patient getPatient() {
		return patient;
	}

	public void setPatient(Patient patient) {
		this.patient = patient;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public User getCreatedbyUser() {
		return createdbyUser;
	}

	public void setCreatedbyUser(User createdbyUser) {
		this.createdbyUser = createdbyUser;
	}

	public AppointmentDetail getAppointmentDetail() {
		return appointmentDetail;
	}

	public void setAppointmentDetail(AppointmentDetail appointmentDetail) {
		this.appointmentDetail = appointmentDetail;
	}

	public String getVisitNumber() {
		return visitNumber;
	}

	public void setVisitNumber(String visitNumber) {
		this.visitNumber = visitNumber;
	}

	public VisitStatus getStatus() {
		return status;
	}

	public void setStatus(VisitStatus status) {
		this.status = status;
	}

	public List<String> getDignosisMasterId() {
		return dignosisMasterId;
	}

	public void setDignosisMasterId(List<String> dignosisMasterId) {
		this.dignosisMasterId = dignosisMasterId;
	}

	public int getPulse() {
		return pulse;
	}

	public void setPulse(int pulse) {
		this.pulse = pulse;
	}

	public int getBloodPresure() {
		return bloodPresure;
	}

	public void setBloodPresure(int bloodPresure) {
		this.bloodPresure = bloodPresure;
	}

	public int getBloodPresure1() {
		return bloodPresure1;
	}

	public void setBloodPresure1(int bloodPresure1) {
		this.bloodPresure1 = bloodPresure1;
	}

	public int getHeight() {
		return height;
	}

	public void setHeight(int height) {
		this.height = height;
	}

	public int getWeight() {
		return weight;
	}

	public void setWeight(int weight) {
		this.weight = weight;
	}

	public int getTemparature() {
		return temparature;
	}

	public void setTemparature(int temparature) {
		this.temparature = temparature;
	}

	public List<String> getDrugAllergyMasterId() {
		return drugAllergyMasterId;
	}

	public void setDrugAllergyMasterId(List<String> drugAllergyMasterId) {
		this.drugAllergyMasterId = drugAllergyMasterId;
	}

	public boolean isDiabetic() {
		return diabetic;
	}

	public void setDiabetic(boolean diabetic) {
		this.diabetic = diabetic;
	}

	public boolean isHypertension() {
		return hypertension;
	}

	public void setHypertension(boolean hypertension) {
		this.hypertension = hypertension;
	}

	public String getOtherAllergy() {
		return otherAllergy;
	}

	public void setOtherAllergy(String otherAllergy) {
		this.otherAllergy = otherAllergy;
	}

	public List<ScanDocumentDetails> getScanDocumentDetails() {
		return scanDocumentDetails;
	}

	public void setScanDocumentDetails(
			List<ScanDocumentDetails> scanDocumentDetails) {
		this.scanDocumentDetails = scanDocumentDetails;
	}

	public Boolean getIsWalkIn() {
		return isWalkIn;
	}

	public void setIsWalkIn(Boolean isWalkIn) {
		this.isWalkIn = isWalkIn;
	}

	public Date getArrivedDate() {
		return arrivedDate;
	}

	public void setArrivedDate(Date arrivedDate) {
		this.arrivedDate = arrivedDate;
	}

	public String getMarkArrivedBy() {
		return markArrivedBy;
	}

	public void setMarkArrivedBy(String markArrivedBy) {
		this.markArrivedBy = markArrivedBy;
	}

	public Date getMarkReadyDate() {
		return markReadyDate;
	}

	public void setMarkReadyDate(Date markReadyDate) {
		this.markReadyDate = markReadyDate;
	}

	public String getMarkReadyBy() {
		return markReadyBy;
	}

	public void setMarkReadyBy(String markReadyBy) {
		this.markReadyBy = markReadyBy;
	}

	public Date getInclinicDate() {
		return inclinicDate;
	}

	public void setInclinicDate(Date inclinicDate) {
		this.inclinicDate = inclinicDate;
	}

	public String getMarkInclinicBy() {
		return markInclinicBy;
	}

	public void setMarkInclinicBy(String markInclinicBy) {
		this.markInclinicBy = markInclinicBy;
	}

	@Override
	public String toString() {
		return "Visit [patientId=" + patientId + ", patient=" + patient
				+ ", createdDate=" + createdDate + ", createdBy=" + createdBy
				+ ", createdbyUser=" + createdbyUser + ", appointmentDetail="
				+ appointmentDetail + ", visitNumber=" + visitNumber
				+ ", status=" + status + ", arrivedDate=" + arrivedDate
				+ ", markArrivedBy=" + markArrivedBy + ", markReadyDate="
				+ markReadyDate + ", markReadyBy=" + markReadyBy
				+ ", inclinicDate=" + inclinicDate + ", markInclinicBy="
				+ markInclinicBy + ", scanDocumentDetails="
				+ scanDocumentDetails + ", dignosisMasterId="
				+ dignosisMasterId + ", diagnosisMaster=" + diagnosisMaster
				+ ", pulse=" + pulse + ", bloodPresure=" + bloodPresure
				+ ", bloodPresure1=" + bloodPresure1 + ", height=" + height
				+ ", weight=" + weight + ", temparature=" + temparature
				+ ", drugAllergyMasterId=" + drugAllergyMasterId
				+ ", drugAllergyMaster=" + drugAllergyMaster + ", diabetic="
				+ diabetic + ", hypertension=" + hypertension
				+ ", otherAllergy=" + otherAllergy + ", isWalkIn=" + isWalkIn
				+ "]";
	}

}
