package com.slktechlabs.pms.system.controller;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.slktechlabs.pms.system.annotation.RequestBodyParam;
import com.slktechlabs.pms.system.constants.MasterStatus;
import com.slktechlabs.pms.system.constants.MessageConstants.UserMessagesEnum;
import com.slktechlabs.pms.system.constants.StatusConstants;
import com.slktechlabs.pms.system.model.Response.ResponseBean;
import com.slktechlabs.pms.system.model.role.RoleTemplate;
import com.slktechlabs.pms.system.service.RoleTemplateService;
import com.slktechlabs.pms.system.util.ResponseGenerator;

@Controller
@RequestMapping("roleTemplate")
public class RoleTemplateController {

	Logger logger=Logger.getLogger(getClass());
	
	@Autowired
	RoleTemplateService roleTemplateService;
	
	/**
	 * Add The Group
	 * @param group
	 * @return
	 */
	@RequestMapping(value="add",method=RequestMethod.POST)
	@ResponseBody
	public Object add(@RequestBody RoleTemplate group){
		roleTemplateService.save(group, "Add Role Template");
		return ResponseGenerator.generateResponse(StatusConstants.success,
				UserMessagesEnum.ADD_SUCCESS.message("Group"));
	}
	
	@RequestMapping(value="list",method=RequestMethod.POST)
	@ResponseBody
	public Object list(){
		
		List<RoleTemplate> result = roleTemplateService.findAll();
		return ResponseGenerator.generateResponse(StatusConstants.success, result);
	}
	
	/**
	 * Change The Existing Access
	 * @param group
	 * @return
	 */
	@RequestMapping(value="changeAccess",method=RequestMethod.POST)
	@ResponseBody
	public Object changeAccess(@RequestBody RoleTemplate group){		
		
		roleTemplateService.changeAccess(group);
		RoleTemplate resultGroup = (RoleTemplate) roleTemplateService.findOne(group.getId());	
		logger.info("resultGroup---------"+resultGroup);
		return ResponseGenerator.generateResponse(StatusConstants.success,
				UserMessagesEnum.UPDATE_SUCCESS.message("Group"));
	}
	
	
	/**
	 * Add Accesses To Group
	 * @param group
	 * @return
	 */
	@RequestMapping(value="addAccess",method=RequestMethod.POST)
	@ResponseBody
	public Object addAccess(@RequestBody RoleTemplate group){
		logger.info(group);
		roleTemplateService.addAccess(group);
		return ResponseGenerator.generateResponse(StatusConstants.success,
				UserMessagesEnum.UPDATE_SUCCESS.message("Group"));
	}
	
}
