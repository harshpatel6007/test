package com.slktechlabs.pms.system.dao.pvb;

import org.springframework.stereotype.Repository;

import com.slktechlabs.pms.system.dao.HMISDao;
import com.slktechlabs.pms.system.model.bill.ExpenseCollection;

@Repository
public class ExpenseDao extends HMISDao<ExpenseCollection, String>{

	
}
