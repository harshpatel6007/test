package com.slktechlabs.pms.system;

import javax.annotation.PostConstruct;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.slktechlabs.pms.system.constants.HospitalType;

@Component
public class SystemUtils {
	
	private static final Logger logger = Logger.getLogger(SystemUtils.class);
	
	@Value("${applicationMode}")
	private String hospitalTypeString;

	public static HospitalType hospitalType;

	@PostConstruct
	private void setHospitalType() {
		logger.info("hospitalTypeString :-- " + hospitalTypeString);
		hospitalType = HospitalType.valueOf(hospitalTypeString);
	}
}
