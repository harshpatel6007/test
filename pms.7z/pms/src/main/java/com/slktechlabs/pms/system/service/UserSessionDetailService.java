package com.slktechlabs.pms.system.service;

import java.util.Date;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.slktechlabs.pms.system.constants.AppType;
import com.slktechlabs.pms.system.constants.SessionType;
import com.slktechlabs.pms.system.dao.UserSessionDetailDao;
import com.slktechlabs.pms.system.model.User;
import com.slktechlabs.pms.system.model.UserSessionDetail;
import com.slktechlabs.pms.system.model.Response.Login;
import com.slktechlabs.pms.system.oauth2.ClientDetailsService;
import com.slktechlabs.pms.system.oauth2.UserDetail;

@Service
public class UserSessionDetailService extends HMISService<UserSessionDetail, String>{

	UserSessionDetailDao userSessionDetailDao;
	
	@Autowired
	private ClientDetailsService clientDetailsService;
	
	@Autowired
	public UserSessionDetailService(UserSessionDetailDao userSessionDetailDao) {
		super(userSessionDetailDao);
		this.userSessionDetailDao = userSessionDetailDao;
	}

	public void addUserSession(Login login, HttpServletRequest request, User user,
			String token_id, SessionType sessionType) {
		
		UserSessionDetail userSessionDetail = new UserSessionDetail();
		userSessionDetail.setIpAddress(request.getRemoteAddr());
		userSessionDetail.setSessionType(sessionType);
		userSessionDetail.setTime(new Date());
		userSessionDetail.setToken_id(token_id);
		userSessionDetail.setUserId(user.getUserId());
		userSessionDetail.setUserMongoId(user.getId());
		if(login != null){
			userSessionDetail.setAppType(login.getAppType());
			userSessionDetail.setMacAddress(login.getMacAddress());
			userSessionDetail.setHostPcName(login.getHostPcName());
		}
		
		save(userSessionDetail, "Add User Login Session");
	}

	public void addLogoutSession(HttpServletRequest request, String token_id) {
		
		UserDetail userDetail = clientDetailsService.getUserDetail();
		
		UserSessionDetail userSessionDetail = new UserSessionDetail();
		userSessionDetail.setIpAddress(request.getRemoteAddr());
		userSessionDetail.setSessionType(SessionType.LOGOUT);
		userSessionDetail.setTime(new Date());
		userSessionDetail.setToken_id(token_id);
		userSessionDetail.setUserId(userDetail.getUserId());
		userSessionDetail.setUserMongoId(userDetail.getUserMongoId());
		userSessionDetail.setAppType(userDetail.getAppType());
		userSessionDetail.setMacAddress(userDetail.getMacAddress());
		userSessionDetail.setHostPcName(userDetail.getHostPcName());
		
		save(userSessionDetail, "Add User Logout Session");
	}
	
	public AppType getAppTypeFromLoginSession(String token_id, String userMongoId){
		return userSessionDetailDao.getLoginSessionByUserAndTokenId(token_id,
				userMongoId).getAppType();
	}

}
