package com.slktechlabs.pms.system.model;

import java.util.Date;

import org.springframework.data.mongodb.core.mapping.Document;

import com.slktechlabs.pms.system.annotation.CustomJoin;
import com.slktechlabs.pms.system.constants.MasterStatus;

@Document(collection = "concessionMaster")
public class ConcessionTypeMaster extends AbstractDocument {

	private String name;
	private long percentage;
	private MasterStatus status;
	private Date date;
	private String addedBy;
	@CustomJoin(joinId = "addedBy", value = { "displayName" }, isInclude = true)
	private User user;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public long getPercentage() {
		return percentage;
	}

	public void setPercentage(int percentage) {
		this.percentage = percentage;
	}

	public MasterStatus getStatus() {
		return status;
	}

	public void setStatus(MasterStatus status) {
		this.status = status;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public String getAddedBy() {
		return addedBy;
	}

	public void setAddedBy(String addedBy) {
		this.addedBy = addedBy;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	@Override
	public String toString() {
		return "ConcessionTypeMaster [name=" + name + ", percentage="
				+ percentage + ", status=" + status + ", date=" + date
				+ ", addedBy=" + addedBy + ", user=" + user + "]";
	}

}
