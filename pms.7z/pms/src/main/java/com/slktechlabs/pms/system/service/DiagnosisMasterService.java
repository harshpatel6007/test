package com.slktechlabs.pms.system.service;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.slktechlabs.pms.system.dao.DiagnosisMasterDao;
import com.slktechlabs.pms.system.model.DiagnosisMaster;
import com.slktechlabs.pms.system.model.SearchCriteria;
@Service
public class DiagnosisMasterService extends HMISService<DiagnosisMaster, String> {

	Logger logger = Logger.getLogger(this.getClass());

	DiagnosisMasterDao diagnosisMasterDao;
	

	@Autowired
	public DiagnosisMasterService(DiagnosisMasterDao diagnosisMasterDao) {
		super(diagnosisMasterDao);
		this.diagnosisMasterDao = diagnosisMasterDao;
	}

	public List<DiagnosisMaster> search(SearchCriteria searchCriteria) {
		return diagnosisMasterDao.search(searchCriteria);
	}

	public List<DiagnosisMaster> getAllName() {
		return diagnosisMasterDao.getAllName();
	}


}
