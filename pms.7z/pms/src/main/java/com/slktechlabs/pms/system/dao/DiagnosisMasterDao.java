package com.slktechlabs.pms.system.dao;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Repository;

import com.slktechlabs.pms.system.constants.MasterStatus;
import com.slktechlabs.pms.system.model.DiagnosisMaster;
import com.slktechlabs.pms.system.model.SearchCriteria;
import com.slktechlabs.pms.system.util.SearchUtils;

@Repository
public class DiagnosisMasterDao extends HMISDao<DiagnosisMaster, String> {
	Logger logger = Logger.getLogger(this.getClass());

	public List<DiagnosisMaster> search(SearchCriteria searchCriteria) {
		Query query = new Query();
    	if (searchCriteria != null) {
    		query.addCriteria(Criteria.where(searchCriteria.getKey())
        		.regex(SearchUtils.getRegexPatternForSearchAtStart(searchCriteria.getValue()), "i"));
    	}
    	query.with(new Sort(Direction.DESC, "modified"));        
    return findAll(query);
	}

	public List<DiagnosisMaster> getAllName() {
		Query query = new Query();
		query.addCriteria(Criteria.where("status").is(MasterStatus.ACTIVE));
		query.fields().include("name");
//		query.fields().exclude("_id");
		return findAll(query);
	}

}
