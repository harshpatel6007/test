package com.slktechlabs.pms.system.service;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.slktechlabs.pms.system.constants.MasterStatus;
import com.slktechlabs.pms.system.dao.RefferMasterDao;
import com.slktechlabs.pms.system.model.RefferMaster;
import com.slktechlabs.pms.system.model.SearchCriteria;
@Service
public class RefferMasterService extends HMISService<RefferMaster, String> {

	Logger logger = Logger.getLogger(this.getClass());

	RefferMasterDao refferMasterDao;
	

	@Autowired
	public RefferMasterService(RefferMasterDao refferMasterDao) {
		super(refferMasterDao);
		this.refferMasterDao = refferMasterDao;
	}

	public List<RefferMaster> search(SearchCriteria searchCriteria) {
		return refferMasterDao.search(searchCriteria);
	}

	public RefferMaster addOtherReffer(String refferalOther) {
		RefferMaster refferMaster = new RefferMaster();
			refferMaster.setName(refferalOther);
			refferMaster.setStatus(MasterStatus.ACTIVE);
		return refferMasterDao.save(refferMaster, "Save Reffer Master");
	}


}
