package com.slktechlabs.pms.system.controller.pvb;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.slktechlabs.pms.system.constants.StatusConstants;
import com.slktechlabs.pms.system.model.Response.ResponseBean;
import com.slktechlabs.pms.system.service.pvb.BillService;
import com.slktechlabs.pms.system.util.ResponseGenerator;

@Controller
@RequestMapping("bill")
public class BillController {
	
	@Autowired
	private BillService billService;

	@RequestMapping(value = "getBillForVisit", method = RequestMethod.POST)
	@ResponseBody
	private ResponseBean getBillForVisit(@RequestBody String visitId) {
		return ResponseGenerator.generateResponse(StatusConstants.success, 
				billService.getBillForVisit(visitId));
	} 
}
