package com.slktechlabs.pms.system.constants;

public enum HospitalType {
	
		DEFAULT("Default");

		private String displayString;

		private HospitalType(String display) {
			this.displayString = display;
		}

		public String getDisplayString() {
			return displayString;
		}
		
		@Override
		public String toString() {
			return name();
		}
	}
