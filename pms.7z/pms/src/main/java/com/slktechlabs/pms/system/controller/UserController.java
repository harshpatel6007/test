package com.slktechlabs.pms.system.controller;

import java.io.File;
import java.io.IOException;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import com.slktechlabs.pms.system.annotation.RequestBodyParam;
import com.slktechlabs.pms.system.constants.AppType;
import com.slktechlabs.pms.system.constants.MessageConstants;
import com.slktechlabs.pms.system.constants.MessageConstants.UserMessagesEnum;
import com.slktechlabs.pms.system.constants.SessionType;
import com.slktechlabs.pms.system.constants.SettingsConstants;
import com.slktechlabs.pms.system.constants.StatusConstants;
import com.slktechlabs.pms.system.encryption.MD5Encryption;
import com.slktechlabs.pms.system.model.SearchCriteria;
import com.slktechlabs.pms.system.model.User;
import com.slktechlabs.pms.system.model.Response.Login;
import com.slktechlabs.pms.system.model.Response.LoginInfo;
import com.slktechlabs.pms.system.model.Response.LoginUserDetail;
import com.slktechlabs.pms.system.model.Response.ResponseBean;
import com.slktechlabs.pms.system.oauth2.UserDetail;
import com.slktechlabs.pms.system.service.ClientAppVersionService;
import com.slktechlabs.pms.system.service.RoleService;
import com.slktechlabs.pms.system.service.UserService;
import com.slktechlabs.pms.system.service.UserSessionDetailService;
import com.slktechlabs.pms.system.util.MyUtils;
import com.slktechlabs.pms.system.util.RequestUtils;
import com.slktechlabs.pms.system.util.ResponseGenerator;


@Controller
@RequestMapping("user")
public class UserController {

	private static final Logger logger = Logger.getLogger(UserController.class);

	@Autowired
	private UserService userService;

	@Autowired
	private RoleService roleService;

	@Autowired
	private ClientAppVersionService clientAppVersionService; 
	
	@Autowired
	private UserSessionDetailService userSessionDetailService;
	
	/**
	 * webLogin
	 * 
	 * @param login
	 * @param request
	 * @param response
	 * @return 
	 */
	@RequestMapping(value="webLogin", method=RequestMethod.POST)
	@ResponseBody
	public ResponseBean webLogin(@RequestBody Login login, HttpServletRequest request, HttpServletResponse response) {
		User user = userService.checkUser(login.getUserId() , login.getPassword());
		
		if (user == null) {
			return ResponseGenerator.generateResponse(StatusConstants.error, 
					MessageConstants.LOGIN_FAIL);
		} else if(!user.getStatus()) {
			return ResponseGenerator.generateResponse(StatusConstants.error,
					MessageConstants.INACTIVE_USER);
		} 
		
		login.setAppType(AppType.Webbrowser);
		
		return userLogin(login, request, user, response);
	}
	
	private void displayCookies(HttpServletRequest request) {
		for(Cookie cookie : request.getCookies()) {
			System.out.println(cookie.getName() + " " + cookie.getValue());
		}
		
	}

	/**
	 * It checks user exist or not by matching userId and password &
	 * It generate token_id user
	 * 
	 * @param login
	 * @param request
	 * @param response 
	 * @param response
	 * @return loginInfo
	 */
	private ResponseBean userLogin(Login login,  HttpServletRequest request, User user,
			HttpServletResponse response) {
		
		String token_id = UUID.randomUUID().toString();

		userSessionDetailService.addUserSession(login, request, user, token_id, 
				SessionType.LOGIN);
		
		if(login.getAppType() != AppType.Webbrowser){
			return ResponseGenerator.generateResponse(StatusConstants.error,
					MessageConstants.APP_TYPE_NOT_SUPPORTED);
		}
			
		createSessionAndStoreUserDetail(token_id, login, user, request);
		
		LoginUserDetail detail = new LoginUserDetail(user.getId(), user.getDisplayName(), 
				user.getUserId(), user.getRole(), token_id, user.getUserType());
		
		if(MyUtils.getBooleanFromValue(login.getAddCookie())) {
			logger.info("add cookie");
			Cookie cookie2 = new Cookie("userId", detail.getId());
			cookie2.setMaxAge(2147483647);
			response.addCookie(cookie2);
		}
		
		LoginInfo loginInfo = new LoginInfo(detail);

		return ResponseGenerator.generateResponse(StatusConstants.success, 
				MessageConstants.LOGIN_SUC, loginInfo);
	}

	private void createSessionAndStoreUserDetail(String token_id, Login login, 
			User user, HttpServletRequest request) {
		
		UserDetail userDetail = new UserDetail();
		userDetail.setUserMongoId(user.getId());
		userDetail.setToken_id(token_id);
		userDetail.setDisplayUserName(user.getDisplayName());
		userDetail.setUserId(user.getUserId());
		userDetail.setRole(user.getRole());
		userDetail.setUserType(user.getUserType());
		userDetail.setAppType(login.getAppType());
		userDetail.setMacAddress(login.getMacAddress());
		userDetail.setHostPcName(login.getHostPcName());
		
		HttpSession httpSession = request.getSession(true);
		httpSession.setAttribute("token_id", token_id);
		//server time  - client time 
		httpSession.setAttribute("timeDifference", (new Date().getTime() - login.getClientDateTime().getTime()));
		httpSession.setAttribute("id", user.getId());
		httpSession.setAttribute("ipAddress", request.getRemoteAddr());
		httpSession.setAttribute("userDetail", userDetail);
	}

	/**
	 * Logout User, it removes the token_id.
	 * 
	 * @param request
	 * @return message
	 */
	@RequestMapping(value = "logout", method = RequestMethod.POST)
	@ResponseBody
	public ResponseBean logout(HttpServletRequest request) {

		String token_id = RequestUtils.getTokenID(request);
		
		userSessionDetailService.addLogoutSession(request, token_id);
		
		HttpSession httpSession = request.getSession();
		if(httpSession != null){
			httpSession.invalidate();
		}
		
		return ResponseGenerator.generateResponse(StatusConstants.success,
				MessageConstants.LOGOUT_SUC);
	}

//	@RequestMapping(value = "login1", method = RequestMethod.POST)
//	@ResponseBody
//	@Deprecated
//	public Object login1(@RequestBody User user, HttpServletResponse response) {
//
//		throw new UnknownResourceException("dsfdsfsdfsdf dsaf sfds f");
//	}

	/**
	 * add User
	 * 
	 * @param user
	 * @return message
	 */
	@RequestMapping(value = "add", method = RequestMethod.POST)
	public @ResponseBody ResponseBean createUser(@RequestBody User user) {
		logger.info("User:  " + user);
		if (userService.checkDuplicateUserId(user.getUserId())) {
				userService.setRole(user);
//			}
			String encryptedPassword = MD5Encryption.encrypt(user.getPassword());
			user.setPassword(encryptedPassword);
			userService.save(user, "Add User");
			return ResponseGenerator.generateResponse(StatusConstants.success,
					UserMessagesEnum.ADD_SUCCESS.message("User"));
		} else {
			return ResponseGenerator.generateResponse(StatusConstants.error,
					UserMessagesEnum.UNIQUE.message("UserId"));
		}
	}

	/**
	 * get user by id
	 * 
	 * @param id
	 * @return user
	 */
	@RequestMapping(value = "get", method = RequestMethod.POST)
	@ResponseBody
	public ResponseBean getUserById(@RequestBodyParam String id) {
		return ResponseGenerator.generateResponse(StatusConstants.success, userService.findOne(id));
	}
	
	
	
	/**
	 * get Limited detail of user by id 
	 * 
	 * @param id
	 * @return
	 */
	@RequestMapping(value = "userLimitedDetail", method = RequestMethod.POST)
	@ResponseBody
	public ResponseBean userLimitedDetail(@RequestBodyParam String id) {
		return ResponseGenerator.generateResponse(StatusConstants.success, userService.userLimitedDetail(id));
	}

	
	/**
	 * Change status of user
	 * @param user
	 * @return message
	 */
	
	@ResponseBody
	@RequestMapping(value = "changeStatus", method = RequestMethod.POST)
	public ResponseBean changeStatus(@RequestBodyParam String userId, @RequestBodyParam Boolean status) {
		logger.info("userId :: "+userId + "status  :: >>" +status);
		return userService.changeStatus(userId, status);
	}
	
	
	/**
	 * update user
	 * 
	 * @param user
	 * @return message
	 */
	@RequestMapping(value = "update", method = RequestMethod.POST)
	@ResponseBody
	public ResponseBean update(@RequestBody User user) {
		logger.info("update user   " + user.toString());
		//if(user.getCustomRole() != null){
			logger.info("Custom Roles Are Applied...!!!");
			userService.setRole(user);
		//}
		userService.updateWithNull(user,"Set Role");

		return ResponseGenerator.generateResponse(StatusConstants.success,
				UserMessagesEnum.UPDATE_SUCCESS.message("User"));
	}
	
	@RequestMapping(value = "autoSearch", method = RequestMethod.POST)
	@ResponseBody
	public ResponseBean autoSearch(@RequestBody SearchCriteria searchCriteria){

		return ResponseGenerator.generateResponse(StatusConstants.success, 
				userService.autoSearchUser(searchCriteria));
	}
	
//	@RequestMapping(value ="autoSearch", method= RequestMethod.POST)
//	@ResponseBody
//	public ResponseBean autoSearch(@RequestBody SearchCriteria searchCriteria) {
//		logger.info("In the Search Method");
//		logger.info("searchCriteria :: "+searchCriteria);
//		return ResponseGenerator.generateResponse(StatusConstants.success,
//				userService.autoSearchUser(searchCriteria));
//	}
	
	
	
	
	/**
	 * Find user's displayNames by given list of user's id
	 * 
	 * @return List<User> (users with their id and displayNames)
	 */
	@RequestMapping(value="getSingleUserNameById", method=RequestMethod.POST)
	@ResponseBody
	public ResponseBean getSingleUserNameById(@RequestBodyParam String userId) {
		User user = userService.findOneSmallUserById(userId);
		return ResponseGenerator.generateResponse(StatusConstants.success, user);
	}
	
	@RequestMapping(value = "updateByUser", method = RequestMethod.POST)
	@ResponseBody
	public ResponseBean updateByUser(@RequestBody User user) {
		userService.update(user,"User update in Profile");
		return ResponseGenerator.generateResponse(StatusConstants.success,UserMessagesEnum.UPDATE_SUCCESS.message("User"));
	}
	
	
	/**
	 * change password of user using id match id & password of user
	 * 
	 * @param user
	 * @return
	 */
	@RequestMapping("changePassword")
	@ResponseBody
	public ResponseBean changePassword(@RequestBody User user) {
		logger.info(user);		
		
		if(userService.changePassword(user)){
			return ResponseGenerator.generateResponse(StatusConstants.success,
					MessageConstants.PASSWORD_CHANGE_SUC);
		}else{
			return ResponseGenerator.generateResponse(StatusConstants.error,
					MessageConstants.USER_NOT_FOUND);
		}
		
	}
	
	/**
	 * Change password of User if user has access Role of Change Password
	 * @param user
	 * @return
	 */
	@RequestMapping(value = "changePasswordByUser", method = RequestMethod.POST)
	@ResponseBody
	public ResponseBean changePasswordByUser(@RequestBodyParam String userId,@RequestBodyParam String password ){
//		logger.info(user);
		userService.changePasswordByUser(userId , password);
		return ResponseGenerator.generateResponse(StatusConstants.success,
				MessageConstants.PASSWORD_CHANGE_SUC);
	}

	/**
	 * upload Photo of user save it with id of user under userPhoto folder
	 * 
	 * @param userPhoto
	 * @param id
	 * @param request
	 * @return
	 * @throws IllegalStateException
	 * @throws IOException
	 */
	@RequestMapping(value = "uploadPhoto", method = RequestMethod.POST)
	@ResponseBody
	public ResponseBean uploadPhoto(@ModelAttribute("userPhoto") MultipartFile userPhoto, 
			@ModelAttribute("id") String id,
			HttpServletRequest request) throws IllegalStateException, IOException {
		
		logger.info("Call the Upload Controller");
		
		
		logger.info("---------------------------------------");
		logger.info("-------------id------>" + id);
		logger.info(userPhoto.getOriginalFilename());

		userPhoto.transferTo(new File(SettingsConstants.USER_PHOTO_PATH + File.separator + id+ ".jpg"));
		logger.info("After transfer");
		return ResponseGenerator.generateResponse(StatusConstants.success, 
				MessageConstants.USER_PHOTO_UPLOAD_SUC);
	}

	/**
	 * get photo of user using id if no photo available for id then return
	 * default photo
	 * 
	 * @param id
	 * @param request
	 * @param response
	 * @return byte array of image
	 * @throws IOException
	 */
	@RequestMapping(value = "getPhoto/{id}")
	@ResponseBody
	public Object getPhoto(@PathVariable("id") String id, HttpServletRequest request, HttpServletResponse response)
			throws IOException {

		File imageFile = new File(SettingsConstants.USER_PHOTO_PATH + File.separator + id + ".jpg");
	
		if (!imageFile.exists()) {
			imageFile = new File(SettingsConstants.defaultUserPhotoPath);
		}
		logger.info("imageFile.getAbsolutePath():-- " + imageFile.getAbsolutePath());
		logger.info("imageFile.getCanonicalPath():-- " + imageFile.getCanonicalPath());
		logger.info("imageFile.getPath():-- " + imageFile.getPath());
	
		byte[] bytes = FileCopyUtils.copyToByteArray(imageFile);

		HttpHeaders responseHeaders = new HttpHeaders();
		responseHeaders.add("Content-Disposition", "inline; filename=\""
					+ id + ".jpg\"");
		responseHeaders.setContentType(MediaType.IMAGE_JPEG);
		responseHeaders.setContentLength(bytes.length);
		         
		return new ResponseEntity<byte[]>(bytes,responseHeaders, HttpStatus.OK);
	}
	
	/**
	 * custom autoSearch 
	 * 
	 * @param searchCriteria
	 * @param userType
	 * @param userId
	 * @return List<User> (User whose status is true)
	 */
	@RequestMapping(value = "customAutoSearch", method = RequestMethod.POST)
	@ResponseBody
	public ResponseBean customAutoSearch(@RequestBodyParam SearchCriteria searchCriteria, 
			@RequestBodyParam String userType, @RequestBodyParam String userId,
			@RequestBodyParam String accessName,@RequestBodyParam List<String> subTypes,
			@RequestBodyParam String displayName){
		List<User> users = userService.customAutoSearch(searchCriteria, userType, userId,accessName,subTypes,displayName);
		return ResponseGenerator.generateResponse(StatusConstants.success, users);
	}
	
	@RequestMapping(value = "getActiveUsersByRole", method = RequestMethod.POST)
	@ResponseBody
	public ResponseBean getActiveUsersByRole(@RequestBodyParam List<String> roleAccessList) {
		List<User> result = userService.getActiveUserByRole(roleAccessList);
		return ResponseGenerator.generateResponse(StatusConstants.success, result);
	}
	
	@RequestMapping(value = "getActiveUsersByAnyRole", method = RequestMethod.POST)
	@ResponseBody
	public ResponseBean getActiveUsersByAnyRole(@RequestBodyParam List<String> 
		roleAccessList) {
		List<User> result = userService.getActiveUsersByAnyRole(roleAccessList);
		return ResponseGenerator.generateResponse(StatusConstants.success, result);
	}
	
	/**
	 * Find user's displayNames by given list of user's id
	 * 
	 * @return List<User> (users with their id and displayNames)
	 */
	@RequestMapping(value="getUserNameById", method=RequestMethod.POST)
	@ResponseBody
	public ResponseBean getUserNameById(@RequestBody List<String> listofHistoryById) {
		List<User> result = userService.getUserNameById(listofHistoryById);
		return ResponseGenerator.generateResponse(StatusConstants.success, result);
	}
	
	@RequestMapping(value="getUserByDrId", method=RequestMethod.POST)
	@ResponseBody
	public ResponseBean getUserByDrId(@RequestBodyParam List<String> listOfDrIds) {
		List<User> result = userService.getUserByDrId(listOfDrIds);
		return ResponseGenerator.generateResponse(StatusConstants.success, result);
	}
	
	@RequestMapping(value="getUserIdAndName", method=RequestMethod.POST)
	@ResponseBody
	public ResponseBean getUserIdAndName(@RequestBody String userMongoId) {
		return ResponseGenerator.generateResponse(StatusConstants.success, 
				userService.getUserIdAndName(userMongoId));
	}
}
