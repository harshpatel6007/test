package com.slktechlabs.pms.system.service.masters;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.slktechlabs.pms.system.dao.masters.StateMasterDao;
import com.slktechlabs.pms.system.model.master.StateMaster;
import com.slktechlabs.pms.system.service.HMISService;

@Service
public class StateMasterService extends HMISService<StateMaster, String>{
	
	StateMasterDao stateMasterDao;
	
	@Autowired
	public StateMasterService(StateMasterDao stateMasterDao) {
		super(stateMasterDao);
		this.stateMasterDao = stateMasterDao;
	}

	public List<StateMaster> search(String stateName, String countryId) {
		return stateMasterDao.search(stateName, countryId);
	}

	public boolean checkCountryMasterExist(String countryId) {
		return stateMasterDao.checkCountryMasterExist(countryId);
	}

	public List<StateMaster> getStatesByCountry(String countryId) {
		return stateMasterDao.getStatesByCountry(countryId);
	}

}
