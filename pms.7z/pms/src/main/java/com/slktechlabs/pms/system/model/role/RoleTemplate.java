package com.slktechlabs.pms.system.model.role;

import java.util.List;

import org.springframework.data.mongodb.core.mapping.Document;

import com.slktechlabs.pms.system.model.AbstractDocument;

@Document(collection = "roleTemplate")
public class RoleTemplate extends AbstractDocument {

	private String name;
	private List<RoleAccess> access;

	public List<RoleAccess> getAccess() {
		return access;
	}

	public void setAccess(List<RoleAccess> access) {
		this.access = access;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	@Override
	public String toString() {
		return "Group [name=" + name + ", access=" + access + "]";
	}
	
}



 
