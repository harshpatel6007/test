package com.slktechlabs.pms.system.model.bill;

import java.util.Date;

import org.springframework.data.mongodb.core.mapping.Document;

import com.slktechlabs.pms.system.annotation.CustomJoin;
import com.slktechlabs.pms.system.constants.PaymentStatus;
import com.slktechlabs.pms.system.constants.PaymentType;
import com.slktechlabs.pms.system.model.AbstractDocument;
import com.slktechlabs.pms.system.model.User;

@Document(collection = "paymentCollection")
public class PaymentCollection extends AbstractDocument {

	private String receiptNumber;
	private Date createdDate;
	private PaymentType paymentType; // paymentByPatient,refundToPatient,FundToPatient
	private PaymentStatus status;
	
	private Double paymentAmount;
	private Double remainingAmount; 
	private Double refundedAmount; 
	private Double usedAmount;
	
	private String patientId;
	private String billId;
	
	private String referencePaymentId; // payemntId of paymentByFundAgency
	
	private Date clearDate;
	private String acceptedBy;
	@CustomJoin(joinId = "acceptedBy", value = { "displayName" }, isInclude = true)
	private User accepteduser;

	private Date cancelDate;
	private String cancelledBy;
	@CustomJoin(joinId = "cancelledBy", value = { "displayName" }, isInclude = true)
	private User cancelledByuser;
	
	
	public String getReceiptNumber() {
		return receiptNumber;
	}
	public void setReceiptNumber(String receiptNumber) {
		this.receiptNumber = receiptNumber;
	}
	public Date getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	public PaymentType getPaymentType() {
		return paymentType;
	}
	public void setPaymentType(PaymentType paymentType) {
		this.paymentType = paymentType;
	}
	public PaymentStatus getStatus() {
		return status;
	}
	public void setStatus(PaymentStatus status) {
		this.status = status;
	}
	public Double getPaymentAmount() {
		return paymentAmount;
	}
	public void setPaymentAmount(Double paymentAmount) {
		this.paymentAmount = paymentAmount;
	}
	public Double getRemainingAmount() {
		return remainingAmount;
	}
	public void setRemainingAmount(Double remainingAmount) {
		this.remainingAmount = remainingAmount;
	}
	public Double getRefundedAmount() {
		return refundedAmount;
	}
	public void setRefundedAmount(Double refundedAmount) {
		this.refundedAmount = refundedAmount;
	}
	public Double getUsedAmount() {
		return usedAmount;
	}
	public void setUsedAmount(Double usedAmount) {
		this.usedAmount = usedAmount;
	}
	public String getPatientId() {
		return patientId;
	}
	public void setPatientId(String patientId) {
		this.patientId = patientId;
	}
	public String getBillId() {
		return billId;
	}
	public void setBillId(String billId) {
		this.billId = billId;
	}
	public String getReferencePaymentId() {
		return referencePaymentId;
	}
	public void setReferencePaymentId(String referencePaymentId) {
		this.referencePaymentId = referencePaymentId;
	}
	public Date getClearDate() {
		return clearDate;
	}
	public void setClearDate(Date clearDate) {
		this.clearDate = clearDate;
	}
	public String getAcceptedBy() {
		return acceptedBy;
	}
	public void setAcceptedBy(String acceptedBy) {
		this.acceptedBy = acceptedBy;
	}
	public User getAccepteduser() {
		return accepteduser;
	}
	public void setAccepteduser(User accepteduser) {
		this.accepteduser = accepteduser;
	}
	public Date getCancelDate() {
		return cancelDate;
	}
	public void setCancelDate(Date cancelDate) {
		this.cancelDate = cancelDate;
	}
	public String getCancelledBy() {
		return cancelledBy;
	}
	public void setCancelledBy(String cancelledBy) {
		this.cancelledBy = cancelledBy;
	}
	public User getCancelledByuser() {
		return cancelledByuser;
	}
	public void setCancelledByuser(User cancelledByuser) {
		this.cancelledByuser = cancelledByuser;
	}

	@Override
	public String toString() {
		return "PaymentCollection [receiptNumber=" + receiptNumber
				+ ", createdDate=" + createdDate + ", paymentType="
				+ paymentType + ", status=" + status + ", paymentAmount="
				+ paymentAmount + ", remainingAmount=" + remainingAmount
				+ ", refundedAmount=" + refundedAmount + ", usedAmount="
				+ usedAmount + ", patientId=" + patientId + ", billId="
				+ billId + ", referencePaymentId=" + referencePaymentId
				+ ", clearDate=" + clearDate + ", acceptedBy=" + acceptedBy
				+ ", accepteduser=" + accepteduser + ", cancelDate="
				+ cancelDate + ", cancelledBy=" + cancelledBy
				+ ", cancelledByuser=" + cancelledByuser + "]";
	}

}
