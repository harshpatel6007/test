package com.slktechlabs.pms.system.service;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.slktechlabs.pms.system.dao.UserTypeMasterDao;
import com.slktechlabs.pms.system.model.SearchCriteria;
import com.slktechlabs.pms.system.model.UserTypeMaster;
@Service
public class UserTypeMasterService extends HMISService<UserTypeMaster, String> {

	Logger logger = Logger.getLogger(this.getClass());

	UserTypeMasterDao userTypeMasterDao;

	@Autowired
	public UserTypeMasterService(UserTypeMasterDao userTypeMasterDao) {
		super(userTypeMasterDao);
		this.userTypeMasterDao = userTypeMasterDao;
	}

	public List<UserTypeMaster> search(SearchCriteria searchCriteria) {
		return userTypeMasterDao.search(searchCriteria);
	}


}
