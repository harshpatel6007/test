package com.slktechlabs.pms.system.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import org.springframework.data.annotation.Transient;

@Retention(RetentionPolicy.RUNTIME)
@Target({ ElementType.FIELD })
@Transient
public @interface CustomJoinListToMap {

	public String[] value() default {};
	public String joinId();
	public boolean isInclude() default false;
	public String refId() default "_id";
}
