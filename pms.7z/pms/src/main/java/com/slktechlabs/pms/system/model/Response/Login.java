package com.slktechlabs.pms.system.model.Response;

import java.util.Date;

import com.slktechlabs.pms.system.constants.AppType;

public class Login {

	private String userId;
	private String password;
	private String appVersion;
	private String macAddress;
	private String hostPcName;
	private AppType appType;
	private Date clientDateTime;
	private Boolean addCookie;


	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getAppVersion() {
		return appVersion;
	}

	public void setAppVersion(String appVersion) {
		this.appVersion = appVersion;
	}

	public AppType getAppType() {
		return appType;
	}

	public void setAppType(AppType appType) {
		this.appType = appType;
	}

	public String getMacAddress() {
		return macAddress;
	}

	public String getHostPcName() {
		return hostPcName;
	}

	public void setMacAddress(String macAddress) {
		this.macAddress = macAddress;
	}

	public void setHostPcName(String hostPcName) {
		this.hostPcName = hostPcName;
	}
	
	public Date getClientDateTime() {
		return clientDateTime;
	}

	public void setClientDateTime(Date clientDateTime) {
		this.clientDateTime = clientDateTime;
	}

	public Boolean getAddCookie() {
		return addCookie;
	}

	public void setAddCookie(Boolean addCookie) {
		this.addCookie = addCookie;
	}

	@Override
	public String toString() {
		return "Login [userId=" + userId + ", password=" + password
				+ ", appVersion=" + appVersion + ", macAddress=" + macAddress
				+ ", hostPcName=" + hostPcName + ", appType=" + appType
				+ ", clientDateTime=" + clientDateTime + ", addCookie="
				+ addCookie + "]";
	}

}
