package com.slktechlabs.pms.system.model.master;

import org.springframework.data.mongodb.core.mapping.Document;

import com.slktechlabs.pms.system.constants.MasterStatus;
import com.slktechlabs.pms.system.model.AbstractDocument;

@Document(collection = "cityMaster")
public class CityMaster extends AbstractDocument {
	private String city;
	private MasterStatus status;

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public MasterStatus getStatus() {
		return status;
	}

	public void setStatus(MasterStatus status) {
		this.status = status;
	}

	@Override
	public String toString() {
		return "CityMaster [city=" + city + ", status=" + status + "]";
	}

}
