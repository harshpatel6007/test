package com.slktechlabs.pms.system.dao.masters;

import java.util.List;

import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Repository;
import org.springframework.util.StringUtils;

import com.slktechlabs.pms.system.constants.MasterStatus;
import com.slktechlabs.pms.system.dao.HMISDao;
import com.slktechlabs.pms.system.model.master.StateMaster;

@Repository
public class StateMasterDao extends HMISDao<StateMaster, String>{

	public List<StateMaster> search(String stateName, String countryId) {
		Query query = new Query();
		if(StringUtils.hasText(stateName)){
			query.addCriteria(Criteria.where("name").is(stateName));
		}
		if(StringUtils.hasText(countryId)){
			query.addCriteria(Criteria.where("countryId").is(countryId));
		}
		query.with(new Sort(Direction.DESC, "modified"));        
		return findAll(query);
	}

	public boolean checkCountryMasterExist(String countryId) {
		Query query=new Query();
		query.addCriteria(Criteria.where("countryId").is(countryId));
		return count(query)>0;
	}

	public List<StateMaster> getStatesByCountry(String countryId) {
		Query query = new Query();
		query.addCriteria(Criteria.where("countryId").is(countryId));
		query.addCriteria(Criteria.where("status").is(MasterStatus.ACTIVE.name()));
		return findAll(query);
	}

}
