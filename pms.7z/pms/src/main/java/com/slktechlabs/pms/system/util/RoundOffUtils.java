package com.slktechlabs.pms.system.util;

import com.slktechlabs.pms.system.constants.RoundOffType;


public class RoundOffUtils {

	/**
	 * This method is used for get roundoff any double value. Just pass the
	 * double value which u want to roundoff and roundoff value
	 * <p>
	 * (eg.value=10.55 and roundoff value=0.5)
	 * </p>
	 * 
	 * @param value
	 * @param roundOff
	 * @return
	 */
	public static double getRoundOff(double value, RoundOffType roundOffType) {
		Double roundOff = Double.valueOf(roundOffType.getDisplayName());
		return roundOff * Math.round(value / roundOff);
	}
	
	public static double getDecimalRoundOff(double value) {
		return Math.round(value * 100.0) / 100.0;
	}
	
	public static Double getDecimalRoundOff(Double value) {
		if(value == null){
			return null;
		}
		return Math.round(value * 100.0) / 100.0;
	}
	
	public static Double getDecimalRoundOffUptoDigit(Double value, int digit) {
		if(value == null){
			return null;
		}
		return Math.round(value * Math.pow(10.0 , digit)) / Math.pow(10.0 , digit);
	}
	
	public static Double getDecimalRoundOffWithoutRound(Double value) {
		if(value == null){
			return null;
		}
		return Math.floor(value * 100.0) / 100.0;
	}
	
	public static double roundToDecimals(double d, int c) {
		int temp = (int)(d * Math.pow(10 , c));
		return ((double)temp)/Math.pow(10 , c);
	}
}
