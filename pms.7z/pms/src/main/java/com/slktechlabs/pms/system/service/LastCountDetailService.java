package com.slktechlabs.pms.system.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.slktechlabs.pms.system.constants.LastCountDetailEnum;
import com.slktechlabs.pms.system.dao.LastCountDetailDao;
import com.slktechlabs.pms.system.model.LastCountDetail;


@Service
public class LastCountDetailService extends HMISService<LastCountDetail, String>{

	private LastCountDetailDao lastCountDetailDao;
	
	@Autowired
	public LastCountDetailService(LastCountDetailDao lastCountDetailDao) {
		super(lastCountDetailDao);
		this.lastCountDetailDao = lastCountDetailDao;
	}

	public long getLastCountForEnum(LastCountDetailEnum	lastCountDetailEnum) {
		return lastCountDetailDao.getLastCountForEnum(lastCountDetailEnum);
	}
	
}
