package com.slktechlabs.pms.system.service;

import java.util.Calendar;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.slktechlabs.pms.system.constants.MRNType;
import com.slktechlabs.pms.system.dao.SystemMRNConfigurationDao;
import com.slktechlabs.pms.system.model.MRNConfiguration;
import com.slktechlabs.pms.system.model.SystemMRNConfiguration;
import com.slktechlabs.pms.system.service.pvb.VisitService;

@Service
public class SystemMRNConfigurationService extends HMISService<SystemMRNConfiguration, String>{
	SystemMRNConfigurationDao systemMRNConfigurationDao;
	
	@Autowired
	public SystemMRNConfigurationService(SystemMRNConfigurationDao systemMRNConfigurationDao) {
		super(systemMRNConfigurationDao);
		this.systemMRNConfigurationDao = systemMRNConfigurationDao;
	}
	
	@Autowired
	VisitService visitService;
	
	/**
	 * generate from MRN Configuration Pattern
	 * @param withoutToken 
	 * For generating an sequence Number just call this method from any where by type
	 * @return
	 */
	public synchronized String generateSequenceNumberByMRNType(MRNType mrnType){
		
		SystemMRNConfiguration systemMRNConfiguration = getByType(mrnType);
		
		MRNConfiguration mrnConfiguration = null;
        if(systemMRNConfiguration != null) {
            mrnConfiguration = systemMRNConfiguration.getMrnConfiguration();
        }
		
		if(mrnConfiguration == null || mrnConfiguration.getCurrentSequenceNumber() == null){
			Long count = getCountByType(mrnType);
			return getDefaultSequenceNumberByMRNType(mrnType, count);
		}
		Long count = mrnConfiguration.getCurrentSequenceNumber() + 1;
		String MRNPattern = mrnConfiguration.getPattern();
		
		Calendar day = Calendar.getInstance();
		String year = String.valueOf(day.get(Calendar.YEAR));		
		String month = String.format("%0" + 2 + "d", day.get(Calendar.MONTH)+1);
		String days = String.format("%0" + 2 + "d", day.get(Calendar.DAY_OF_MONTH));
		
		String subnumber = String.format("%0" + mrnConfiguration.getNumberSize() + "d", count);
		String sequenceNumber = subnumber
				.substring(subnumber.length() - mrnConfiguration.getNumberSize(), subnumber.length());
		
		String randomNumber = ((Long)new Date().getTime()).toString();
		String randomString = randomNumber
				.substring((randomNumber.length() - mrnConfiguration.getNumberSize()), randomNumber.length());
		
		String patternNumber = MRNPattern.replace("[Y]", year);
		patternNumber = patternNumber.replace("[YY]", String.valueOf(day.get(Calendar.YEAR) % 100));
		patternNumber = patternNumber.replace("[M]", month);
		patternNumber = patternNumber.replace("[SQN]", sequenceNumber);
		patternNumber = patternNumber.replace("[RDN]", randomString);
		patternNumber = patternNumber.replace("[D]", days);
		
		incrementLastNumberInMrnConfiguration(mrnType);
		
		return patternNumber;
	}
	
	private void incrementLastNumberInMrnConfiguration(MRNType mrnType) {
		systemMRNConfigurationDao.incrementLastNumberInMrnConfiguration(mrnType);
	}
	
	private Long getCountByType(MRNType mrnType) {
		long count = 0l;
		switch (mrnType) {
			case VisitNumberPattern: 
				count = visitService.count(); 
			default:
				break;
		}
		return count;
	}

	public SystemMRNConfiguration getByType(MRNType mrnType) {
		return systemMRNConfigurationDao.getByType(mrnType);
	}

	/**
	 * @param mrnType
	 * @param count
	 * @return
	 * Generate DefaultSequenceNumber 
	 */
	private String getDefaultSequenceNumberByMRNType(MRNType mrnType, long count) {
		String sequenceNumber = null;
		
		count = count + 1;
		String subNumber = String.format("%0" + 7 + "d", count);
		switch (mrnType) {
				default:
					sequenceNumber = subNumber;
				break;
		}
		return sequenceNumber;
	}
	

}
