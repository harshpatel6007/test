package com.slktechlabs.pms.system.service.masters;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.slktechlabs.pms.system.dao.masters.DocumentTypeMasterDao;
import com.slktechlabs.pms.system.model.SearchCriteria;
import com.slktechlabs.pms.system.model.master.DocumentTypeMaster;
import com.slktechlabs.pms.system.service.HMISService;

@Service
public class DocumentTypeMasterService extends HMISService<DocumentTypeMaster, String>{
	
	DocumentTypeMasterDao documentTypeMasterDao;
	
	@Autowired
	public DocumentTypeMasterService(DocumentTypeMasterDao documentTypeMasterDao) {
		super(documentTypeMasterDao);
		this.documentTypeMasterDao = documentTypeMasterDao;
	}
	
	@Autowired
	DocumentSubTypeMasterService documentSubTypeMasterService;

	public List<DocumentTypeMaster> search(SearchCriteria searchCriteria) {
		return documentTypeMasterDao.search(searchCriteria);
	}

	public String checkReferenceExist(String documentTypeId) {
		if(documentSubTypeMasterService.checkDocumentTypeMasterExist(documentTypeId)){
			return "Document Sub Type Master";
		}
		return null;
	}
	

}
