package com.slktechlabs.pms.system.dao;

import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Repository;

import com.slktechlabs.pms.system.constants.LastCountDetailEnum;
import com.slktechlabs.pms.system.model.LastCountDetail;


@Repository
public class LastCountDetailDao extends HMISDao<LastCountDetail, String>{
	
	public synchronized long getLastCountForEnum(LastCountDetailEnum lastCountDetailEnum) {
		Query query = new Query();
		query.addCriteria(Criteria.where("lastCountDetailEnum")
				.is(lastCountDetailEnum));
		
		Update update = new Update();
		update.inc("lastCount", 1);
		
		return findAndModify(query, update).getLastCount();
	}

}
