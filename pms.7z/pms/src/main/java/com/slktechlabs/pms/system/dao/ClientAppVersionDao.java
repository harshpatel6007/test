package com.slktechlabs.pms.system.dao;

import static org.springframework.data.mongodb.core.query.Criteria.where;

import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Repository;

import com.slktechlabs.pms.system.constants.AppType;
import com.slktechlabs.pms.system.model.ClientAppVersion;

@Repository
public class ClientAppVersionDao extends HMISDao<ClientAppVersion, String> {

	public boolean checkVersion(String version) {
		Query query = new Query();
		query.addCriteria(where("version").is(version));
		return count(query) > 0;
	}
	
	public ClientAppVersion getVersion(String version, AppType appType) {
		Query query = new Query();
		Criteria criteria = new Criteria();
		criteria.orOperator(Criteria.where("version").is(version), Criteria.where("version").is("All"));
		query.addCriteria(criteria);
		query.addCriteria(where("appType").is(appType.name()));
		
		return findOne(query);
	}

	public ClientAppVersion getVersion() {
		Query query = new Query();
		query.addCriteria(where("downloadVersion").is(true));
		return findOne(query);
	}

	public ClientAppVersion getversion(String appType) {
		Query query = new Query();
		query.addCriteria(Criteria.where("appType").is(appType));
		return findOne(query);
	}

	public void changeClientAppVersionForAndroid(String appType, String version) {
		Query query = new Query();
		query.addCriteria(Criteria.where("appType").is(appType));
		
		Update update = new Update();
		update.set("version", version);
		updateWithoutHistory(query, update);
	}

}
