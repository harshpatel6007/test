package com.slktechlabs.pms.system.model;

import java.util.List;

import com.slktechlabs.pms.system.model.visit.Visit;

public class UserDashboard {

	private int scheduledPatientCount;
	private int completedPatientCount;
	private int inClinicPatientCount;
	
	private List<Visit> scheduledPatients;
	private List<Visit> inClinicPatients;
	private List<Visit> completedPatients;

	public int getScheduledPatientCount() {
		return scheduledPatientCount;
	}

	public void setScheduledPatientCount(int scheduledPatientCount) {
		this.scheduledPatientCount = scheduledPatientCount;
	}

	public int getCompletedPatientCount() {
		return completedPatientCount;
	}

	public void setCompletedPatientCount(int completedPatientCount) {
		this.completedPatientCount = completedPatientCount;
	}

	public int getInClinicPatientCount() {
		return inClinicPatientCount;
	}

	public void setInClinicPatientCount(int inClinicPatientCount) {
		this.inClinicPatientCount = inClinicPatientCount;
	}

	public List<Visit> getScheduledPatients() {
		return scheduledPatients;
	}

	public void setScheduledPatients(List<Visit> scheduledPatients) {
		this.scheduledPatients = scheduledPatients;
	}

	public List<Visit> getInClinicPatients() {
		return inClinicPatients;
	}

	public void setInClinicPatients(List<Visit> inClinicPatients) {
		this.inClinicPatients = inClinicPatients;
	}

	public List<Visit> getCompletedPatients() {
		return completedPatients;
	}

	public void setCompletedPatients(List<Visit> completedPatients) {
		this.completedPatients = completedPatients;
	}

	@Override
	public String toString() {
		return "UserDashboard [scheduledPatientCount=" + scheduledPatientCount
				+ ", completedPatientCount=" + completedPatientCount
				+ ", inClinicPatientCount=" + inClinicPatientCount
				+ ", scheduledPatients=" + scheduledPatients
				+ ", inClinicPatients=" + inClinicPatients
				+ ", completedPatients=" + completedPatients + "]";
	}
	
}
