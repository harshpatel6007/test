package com.slktechlabs.pms.system.dao;

import static org.springframework.data.mongodb.core.query.Criteria.where;

import java.beans.IntrospectionException;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;

import org.apache.log4j.Logger;
import org.bson.types.ObjectId;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.data.domain.Sort.Order;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Repository;
import org.springframework.util.StringUtils;

import com.mongodb.BasicDBList;
import com.mongodb.BasicDBObject;
import com.slktechlabs.pms.system.encryption.MD5Encryption;
import com.slktechlabs.pms.system.model.SearchCriteria;
import com.slktechlabs.pms.system.model.User;
import com.slktechlabs.pms.system.model.Response.ResponseBean;
import com.slktechlabs.pms.system.util.SearchUtils;

@Repository
public class UserDao extends HMISDao<User, String> {

	private static final Logger logger = Logger.getLogger(UserDao.class);

	public User checkUser(String userId, String password) {

		Query query = new Query();
		query.addCriteria(where("userId").regex(
				"^" + SearchUtils.getRegexCompatibleString(userId) + "$", "i"));
		String encryptedPassword = MD5Encryption.encrypt(password);
		query.addCriteria(where("password").is(encryptedPassword));
		// query.addCriteria(where("status").is(true));
		// logger.info(query.getQueryObject());

		return (User) findOne(query);
	}

	public List<User> autoSearchUser(SearchCriteria searchCriteria) {
		Query query = new Query();
		// query.addCriteria(Criteria.where(key)
		// .regex(SearchUtils.getRegexPatternForSearchAtStart(value), "i"));
		// query.addCriteria(Criteria.where("status").is(true));
		// query.fields().include(key);
		// query.with(new Sort(Sort.Direction.ASC, key));
		// List<String> lstvalues = distinct(key, query);
		// return lstvalues;

		if (searchCriteria.getValue() != null) {
			query.addCriteria(Criteria.where(searchCriteria.getKey()).regex(
					SearchUtils.getRegexPatternForSearchAtStart(searchCriteria
							.getValue()), "i"));
		}
		query.addCriteria(Criteria.where("status").is(true));
		query.with(new Sort(Direction.DESC, "modified"));
		return findAll(query);
	}

	public List<User> getAllUser(SearchCriteria searchCriteria) {
		logger.info(searchCriteria);
		Query query = new Query();
		if (searchCriteria != null) {
			query.addCriteria(Criteria.where(searchCriteria.getKey()).regex(
					SearchUtils.getRegexPatternForSearchAtStart(searchCriteria
							.getValue()), "i"));
		}
		query.with(new Sort(Direction.DESC, "modified"));
		return findAll(query);
	}

	public List<User> searchUser(List<SearchCriteria> list) {
		Query query = new Query();
		Order order = null;
		if (list != null && list.size() > 0) {
			Map<String, BasicDBList> map2 = new HashMap<String, BasicDBList>();
			map2.put("or", new BasicDBList());
			map2.put("and", new BasicDBList());

			for (SearchCriteria searchCriteria : list) {
				BasicDBObject objList = new BasicDBObject();
				String value = SearchUtils
						.getRegexPatternForSearchWithinText(searchCriteria
								.getValue());
				objList.put(searchCriteria.getKey(),
						Pattern.compile(value, Pattern.CASE_INSENSITIVE));

				map2.get(searchCriteria.getOperation()).add(objList);
				order = new Order(searchCriteria.getKey());

			}

			for (Map.Entry<String, BasicDBList> entry : map2.entrySet()) {

				if (entry.getValue().size() != 0) {
					query.addCriteria(new Criteria("$" + entry.getKey())
							.is(entry.getValue()));
				}
			}
		} else {
			order = new Order(Direction.DESC, "createdDate");
		}

		Sort sort = new Sort(order);
		query.with(sort);
		query.limit(100);

		logger.debug(query);

		return findAll(query);
	}

	public boolean checkDuplicateUserId(String userId) {

		Query query = new Query();

		query.addCriteria(where("userId").regex(
				"^" + SearchUtils.getRegexCompatibleString(userId) + "$", "i"));

		return (count(query) == 0);
	}

	public boolean changePassword(User user) {
		Query query = new Query();
		Update update = new Update();
		String encryptedPassword = MD5Encryption.encrypt(user.getPassword());
		query.addCriteria(Criteria.where("id").is(user.getId()));
		query.addCriteria(Criteria.where("password").is(encryptedPassword));

		String newEncryptedPassword = MD5Encryption.encrypt(user
				.getNewPassword());
		update.set("password", newEncryptedPassword);
		return findAndModify(query, update) != null;
	}

	public List<User> getSmallListByType(List<String> typeList) {
		Query query = new Query();
		if (typeList != null && !typeList.isEmpty()) {
			Criteria criteria = new Criteria();
			criteria.orOperator(Criteria.where("userType").in(typeList),
					Criteria.where("subType").in(typeList));
			query.addCriteria(criteria);
		}
		query.addCriteria(Criteria.where("status").is(true));
		query.fields().include("userId");
		query.fields().include("userType");
		query.fields().include("subType");
		query.fields().include("displayName");
		query.fields().include("isHeadOfUnit");
		query.fields().include("status");
		return findAll(query);
	}

	public List<User> getUserIdsBySingleType(String type) {
		Query query = new Query();
		if (type != null && !type.equals(null)) {
			Criteria criteria = new Criteria();
			criteria.orOperator(Criteria.where("userType").is(type), Criteria
					.where("subType").is(type));
			query.addCriteria(criteria);
		}
		query.addCriteria(Criteria.where("status").is(true));
		query.fields().include("displayName");
		return find(query);
	}

	public List<ObjectId> getUserIdsByType(List<String> typeList) {
		Query query = new Query();
		if (typeList != null && !typeList.isEmpty()) {
			Criteria criteria = new Criteria();
			criteria.orOperator(Criteria.where("userType").in(typeList),
					Criteria.where("subType").in(typeList));
			query.addCriteria(criteria);
		}
		query.addCriteria(Criteria.where("status").is(true));
		return distinct("_id", query);
	}

	public List<User> findUserByRoleId(String roleId) {
		Query query = new Query();
		query.addCriteria(Criteria.where("roleId").is(roleId));
		return findAll(query);
	}

	public void changePasswordByUser(String userId, String password) {
		Query query = new Query();
		query.addCriteria(Criteria.where("_id").is(userId));

		Update update = new Update();
		String encryptedPassword = MD5Encryption.encrypt(password);
		update.set("password", encryptedPassword);
		update(query, update, "Change Password");
	}

	public List<User> getSmallListByIds(List<String> userIds) {
		Query query = new Query();
		query.addCriteria(Criteria.where("_id").in(userIds));
		query.fields().include("userId");
		query.fields().include("displayName");
		return find(query);
	}

	public List<User> customAutoSearch(SearchCriteria searchCriteria,
			String userType, String userId, String accessName,
			List<String> subTypes, String displayName) {
		Query query = new Query();
		if (userType != null && StringUtils.hasText(userType)) {
			query.addCriteria(Criteria.where("userType").is(userType));
		}
		if (subTypes != null && !subTypes.isEmpty()) {
			query.addCriteria(Criteria.where("subType").in(subTypes));
		}
		if (displayName != null && !displayName.isEmpty()) {
			String value = SearchUtils
					.getRegexPatternForSearchWithinText(displayName);
			query.addCriteria(Criteria.where("displayName").regex(value, "i"));
		}
		if (userId != null) {
			query.addCriteria(Criteria.where("userId").regex(
					SearchUtils.getRegexPatternForSearchAtStart(userId), "i"));
		}
		if (searchCriteria != null) {
			query.addCriteria(Criteria.where(searchCriteria.getKey()).regex(
					SearchUtils.getRegexPatternForSearchAtStart(searchCriteria
							.getValue()), "i"));
		}
		if (accessName != null && StringUtils.hasText(accessName)) {
			query.addCriteria(Criteria.where("role.access." + accessName).is(
					true));
		}
		query.addCriteria(Criteria.where("status").is(true));
		query.fields().include("userId");
		query.fields().include("displayName");
		query.fields().include("userType");
		query.fields().include("subType");
		return find(query);
	}

	public List<String> getNotifyUsers(List<String> userTypes,
			List<String> userSubTypes) {
		List<String> userIds = new ArrayList<>();
		Query query = new Query();
		query.addCriteria(Criteria.where("userType").in(userTypes));
		if (userSubTypes != null && !userSubTypes.isEmpty()) {
			query.addCriteria(Criteria.where("subType").in(userSubTypes));
		}
		query.fields().include("_id");
		for (User user : find(query)) {
			userIds.add(user.getId());
		}
		return userIds;
	}

	public User findOneSmallUserById(String id) {
		Query query = new Query();
		query.addCriteria(Criteria.where("id").is(id));
		query.fields().include("displayName");
		query.fields().include("phoneno");
		return findOne(query);
	}

	public List<User> getUsers() {
		Query query = new Query();
		query.fields().include("displayName");
		return find(query);
	}

	public List<User> getActiveUserByRole(List<String> roleAccessList) {
		Query query = new Query();
		query.with(new Sort(Direction.ASC, "userId"));
		query.addCriteria(Criteria.where("status").is(true));
		for (String access : roleAccessList) {
			query.addCriteria(Criteria.where("role.access." + access).is(true));
		}
		query.fields().include("userId");
		query.fields().include("displayName");
		query.limit(100);
		return findAll(query);
	}

	public List<User> getActiveUsersByAnyRole(List<String> roleAccessList) {
		Query query = new Query();
		query.with(new Sort(Direction.ASC, "userId"));

		Criteria criteria = Criteria.where("status").is(true);

		List<Criteria> criterias = new ArrayList<Criteria>();
		for (String access : roleAccessList) {
			criterias.add(Criteria.where("role.access." + access).is(true));
		}

		criteria.orOperator(criterias.toArray(new Criteria[criterias.size()]));

		query.addCriteria(criteria);

		query.fields().include("userId");
		query.fields().include("displayName");
		query.limit(100);
		return findAll(query);
	}

	public User getUserIdAndName(String userMongoId) {
		Query query = new Query();
		query.addCriteria(Criteria.where("_id").is(userMongoId));
		query.fields().include("userId");
		query.fields().include("displayName");
		return findOne(query);
	}

	public User userLimitedDetail(String id) {
		Query query = new Query();
		query.addCriteria(Criteria.where("_id").is(id));
		query.fields().exclude("role.access");
		query.fields().exclude("role.status");
		query.fields().exclude("customRole");
		return findOne(query);
	}

	public List<User> getUserByDrId(List<String> listOfDrIds) {
		Query query = new Query();
		query.addCriteria(Criteria.where("_id").in(listOfDrIds));
		query.fields().include("email");
		query.fields().include("phoneno");
		return findAll(query);
	}

	public List<User> getUserNameById(List<String> listofHistoryById) {
		Query query = new Query();
		query.addCriteria(Criteria.where("_id").in(listofHistoryById));
		query.fields().include("displayName");
		return find(query);
	}

	public boolean checkRoleUsed(String roleId) {
		Query query = new Query();
		query.addCriteria(Criteria.where("roleId").is(roleId));
		return count(query) > 0;
	}

	public void changeStatus(String id, Boolean status) {
		Query query = new Query();
		query.addCriteria(Criteria.where("_id").is(id));
		Update update = new Update();
		update.set("status", status);
		update(query, update, "changeStatus to " + status);
	}

}
