package com.slktechlabs.pms.system.service.pvb;

import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.slktechlabs.pms.system.constants.LastCountDetailEnum;
import com.slktechlabs.pms.system.dao.pvb.PatientDao;
import com.slktechlabs.pms.system.model.RefferMaster;
import com.slktechlabs.pms.system.model.SearchCriteria;
import com.slktechlabs.pms.system.model.patient.Patient;
import com.slktechlabs.pms.system.model.patient.PatientDetail;
import com.slktechlabs.pms.system.model.patient.Patient_Visit;
import com.slktechlabs.pms.system.model.visit.Visit;
import com.slktechlabs.pms.system.service.HMISService;
import com.slktechlabs.pms.system.service.LastCountDetailService;
import com.slktechlabs.pms.system.service.RefferMasterService;
import com.slktechlabs.pms.system.util.MyUtils;

@Service
public class PatientService extends HMISService<Patient, String>{
	
	private Logger logger = Logger.getLogger(getClass());
	
	private PatientDao patientDao;
	
	@Autowired
	private VisitService visitService;
	
	@Autowired
	private RefferMasterService refferMasterService;
	
	@Autowired
	public PatientService(PatientDao patientDao) {
		super(patientDao);
		this.patientDao = patientDao;
	}
	
	@Autowired
	LastCountDetailService lastCountDetailService; 

	public Patient_Visit add(Patient patient) {
		Patient_Visit patient_Visit = new Patient_Visit();
		patient.setRegistrationDate(new Date());
		patient.setCreatedBy(getLoggedUserMongoId());
		
		String patientId = getPatientId(); 
		patient.setPatientId(patientId);
		if(StringUtils.hasText(patient.getRefferalOther())){
			RefferMaster refferMaster = refferMasterService.addOtherReffer(patient.getRefferalOther());
			logger.info("refferMaster >>>>>"+refferMaster);
			patient.setReferalDoctor(refferMaster.getId());
		}
		
		patient = save(patient, "Add Patient");
		Visit visit = null;
		if(MyUtils.getBooleanFromValue(patient.getIsWalkIn())){
			visit = visitService.addVisit(patient);
		}
		patient_Visit.setPatient(patient);
		patient_Visit.setVisit(visit);
		return patient_Visit;
	}
	
	private String getPatientId(){
		Calendar day = Calendar.getInstance();
		String year = String.valueOf(day.get(Calendar.YEAR));		
		String month = String.format("%0" + 2 + "d", day.get(Calendar.MONTH)+1);
		
		Long count = lastCountDetailService.getLastCountForEnum(LastCountDetailEnum.PATIENT_COUNT);
		String subNumber = String.format("%0" + 7 + "d", count);
		
		
		return year+month+"-"+subNumber;
	}

	public List<Patient> customAutoSearch(String input) {
		return patientDao.customAutoSearch(input);
	}
	
	public void updatePhoto(String storagePathName, String imageName, String patientId) {
		patientDao.updatePhoto(storagePathName, imageName, patientId);
	}

	public List<Patient> search(SearchCriteria searchCriteria) {
		return patientDao.search(searchCriteria);
	}

	public Patient getPatientNameById(String id) {
		return patientDao.getPatientNameById(id);
	}

	public PatientDetail getPatientDetail(String patientId) {
		PatientDetail patientDetail = new PatientDetail();
		patientDetail.setPatient(findOne(patientId));
		patientDetail.setVisits(visitService.getVisitsOfPatient(patientId));
		return patientDetail;
	}

	public void changeWalkInValue(Patient patient) {
		update(patient, "patientUpadte");
	}

}
