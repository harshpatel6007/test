package com.slktechlabs.pms.system.constants;

public enum StatusConstants {
	success,
	error
}
