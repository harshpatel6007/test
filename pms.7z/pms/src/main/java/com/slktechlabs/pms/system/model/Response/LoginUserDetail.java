package com.slktechlabs.pms.system.model.Response;

import com.slktechlabs.pms.system.model.role.Role;

public class LoginUserDetail {

	private String id;
	private String displayName;
	private String userId;
	private Role role;
	private String token_id;
	private String userType;
	
	public LoginUserDetail(String id, String displayName, String userId, Role role,
			String token_id, String userType) {
		this.id = id;
		this.displayName = displayName;
		this.userId = userId;
		this.role = role;
		this.token_id = token_id;
		this.userType = userType;
	}

	public String getUserType() {
		return userType;
	}
	
	public void setUserType(String userType) {
		this.userType = userType;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getDisplayName() {
		return displayName;
	}

	public void setDisplayName(String displayName) {
		this.displayName = displayName;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public Role getRole() {
		return role;
	}

	public void setRole(Role role) {
		this.role = role;
	}

	public String getToken_id() {
		return token_id;
	}

	public void setToken_id(String token_id) {
		this.token_id = token_id;
	}

	@Override
	public String toString() {
		return "UserDetail [id=" + id + ", displayName=" + displayName
				+ ", userId=" + userId + ", role=" + role + ", token_id="
				+ token_id + ", userType=" + userType + "]";
	}

}
