package com.slktechlabs.pms.system.constants;

public enum PaymentType {

        PAYMENT_BY_PATIENT("Advance Patient Payment"), 
        REFUND_TO_PATIENT("Refund To Patient"), 
        OTHER_PAYMENTS("Other Payments");
        
        private final String payment_type;

        private PaymentType(String payment_type) {
            this.payment_type = payment_type;
        }

        public String getPayment_type() {
            return payment_type;
        }

        @Override
        public String toString() {
            return payment_type;
        }
    }
