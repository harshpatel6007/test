package com.slktechlabs.pms.system;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpOutputMessage;
import org.springframework.http.converter.HttpMessageNotWritableException;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;

import com.slktechlabs.pms.system.oauth2.ClientDetailsService;

//@Component
public class CustomMappingJackson2HttpMessageConverter extends
		MappingJackson2HttpMessageConverter {

//	private Logger logger = Logger
//			.getLogger(CustomMappingJackson2HttpMessageConverter.class);

	@Autowired
	ClientDetailsService tempInMemoryClientDetailsService;

	@Override
	protected void writeInternal(Object object, HttpOutputMessage outputMessage)
			throws IOException, HttpMessageNotWritableException {

//		logger.info("--------CustomMappingJackson2HttpMessageConverter--------");

//		if (object != null && object instanceof ResponseBean) {
//
//			ResponseBean responseBean = (ResponseBean) object;
//
//			HttpServletRequest request = ((ServletRequestAttributes) RequestContextHolder
//					.currentRequestAttributes()).getRequest();
//
//			/*Enumeration e = request.getHeaderNames();
//			while (e.hasMoreElements()) {
//				String headers = (String) e.nextElement();
//				if (headers != null) {
//					logger.info(headers + " --------->>>"
//							+ request.getHeader(headers));
//				}
//			}*/
//
//			String isBringNotificationString = request
//					.getHeader("isBringNotification");
//			
//			String notificationStartTimeString = request
//					.getHeader("notificationLastSyncTime");
//			
//			boolean isBringNotification = false;
//			if (isBringNotificationString != null) {
//				isBringNotification = Boolean
//						.parseBoolean(isBringNotificationString);
//			}
//
//			if (isBringNotification && notificationStartTimeString != null) {
//
//				String token_id = request.getHeader("token_id");
//				if (token_id == null) {
//					token_id = (String) request.getAttribute("token");
//				}
//
//				if (token_id != null) {
//
//					ClientDetails clientDetails = tempInMemoryClientDetailsService
//							.getClientDetailsStore().get(token_id);
//					if (clientDetails != null) {
//
////						String userID = (String) clientDetails
////								.getAdditionalInformation().get("id");
//						UserDetail userDetail = (UserDetail)clientDetails.getAdditionalInformation().get("userDetail");
//						Date notificationEndTime = new Date();
//
//						Date notificationStartTime = new Date(
//								Long.parseLong(notificationStartTimeString));
//
//						if (notificationStartTime != null && notificationEndTime != null) {
//							List<NotificationCollection> userNotificationCollections = new ArrayList<NotificationCollection>();
//							List<NotificationCollection> systemNotificationCollections = notificationService
//									.getSystemNotification(notificationStartTime, notificationEndTime, userDetail.getUserMongoId(),
//											userDetail.getUserType(), userDetail.getSubType());
//							
////							if(notificationManager.isNotificationExist(userID)){
////								userNotificationCollections = notificationService.getUserNotification(userID, notificationStartTime,notificationEndTime);
////							}else{
////								logger.info("No Notifications Avalilable Currently  For User "+userID);
////								userNotificationCollections =  new ArrayList<NotificationCollection>();
////							}
//							
//							if(systemNotificationCollections!=null && systemNotificationCollections.size()>0)	 {								
//								userNotificationCollections.addAll(systemNotificationCollections);
//							}
//							
//							responseBean.setNotificationData(userNotificationCollections,notificationEndTime);
//						}
//					}
//				}
//			}
//		}

		super.writeInternal(object, outputMessage);
	}
}
