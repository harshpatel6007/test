package com.slktechlabs.pms.system.controller.masters;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.slktechlabs.pms.system.annotation.RequestBodyParam;
import com.slktechlabs.pms.system.constants.MessageConstants.UserMessagesEnum;
import com.slktechlabs.pms.system.constants.StatusConstants;
import com.slktechlabs.pms.system.model.Response.ResponseBean;
import com.slktechlabs.pms.system.model.master.DocumentSubTypeMaster;
import com.slktechlabs.pms.system.service.masters.DocumentSubTypeMasterService;
import com.slktechlabs.pms.system.util.ResponseGenerator;

@Controller
@RequestMapping("documentSubTypeMaster")
public class DocumentSubTypeMasterController {
	
	@Autowired
	DocumentSubTypeMasterService documentSubTypeMasterService;

	@RequestMapping(value ="add", method= RequestMethod.POST)
	@ResponseBody
	public ResponseBean add(@RequestBody DocumentSubTypeMaster documentSubTypeMaster) {
		Boolean exist = documentSubTypeMasterService.uniqueCheck("name", documentSubTypeMaster.getName(), documentSubTypeMaster.getId());
		if(exist){
			return ResponseGenerator.generateResponse(StatusConstants.error, UserMessagesEnum.UNIQUE.message("name"));
		}
		documentSubTypeMasterService.save(documentSubTypeMaster, "Document Sub Type Master Add");
		return ResponseGenerator.generateResponse(StatusConstants.success,
				UserMessagesEnum.ADD_SUCCESS.message("Document Sub Type  Master"), documentSubTypeMaster);
	}
	
	@RequestMapping(value ="update", method= RequestMethod.POST)
	@ResponseBody
	public ResponseBean update(@RequestBody DocumentSubTypeMaster documentSubTypeMaster) {
		Boolean exist = documentSubTypeMasterService.uniqueCheck("name", documentSubTypeMaster.getName(), documentSubTypeMaster.getId());
		if(exist){
			return ResponseGenerator.generateResponse(StatusConstants.error, UserMessagesEnum.UNIQUE.message("name"));
		}
		documentSubTypeMasterService.update(documentSubTypeMaster, "Document Sub Type Master Update");
		return ResponseGenerator.generateResponse(StatusConstants.success,
				UserMessagesEnum.UPDATE_SUCCESS.message("Document Sub Type  Master"), documentSubTypeMaster);
	}
	
	@RequestMapping(value ="search", method= RequestMethod.POST)
	@ResponseBody
	public ResponseBean search(@RequestBodyParam String documentSubTypeName, @RequestBodyParam String documentTypeId) {
		return ResponseGenerator.generateResponse(StatusConstants.success,
				documentSubTypeMasterService.search(documentSubTypeName, documentTypeId));
	}
	
	@RequestMapping(value ="delete", method= RequestMethod.POST)
	@ResponseBody
	public ResponseBean delete(@RequestBodyParam String id) {
		documentSubTypeMasterService.delete(id);
		return ResponseGenerator.generateResponse(StatusConstants.success,
				UserMessagesEnum.DELETE_SUCCESS.message("Document Sub Type  Master"));
	}
	
	@RequestMapping(value ="get", method= RequestMethod.POST)
	@ResponseBody
	public ResponseBean get(@RequestBodyParam String id) {
		return ResponseGenerator.generateResponse(StatusConstants.success,
				documentSubTypeMasterService.findOne(id));
	}
	
	@RequestMapping(value ="getByDocTypeId", method= RequestMethod.POST)
	@ResponseBody
	public ResponseBean getByDocTypeId(@RequestBodyParam String docTypeId) {
		return ResponseGenerator.generateResponse(StatusConstants.success,
				documentSubTypeMasterService.getByDocTypeId(docTypeId));
	}
}
