package com.slktechlabs.pms.system.controller.web;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.slktechlabs.pms.system.service.pvb.VisitService;

@Controller
@RequestMapping("web/bill")
public class BillWebController {

	private Logger logger = Logger.getLogger(getClass());
	
	private final String PAGE_PREFIX = "pms/bill/";
	
	@Autowired
	private VisitService visitService;
	
	@RequestMapping(value = "view", method = RequestMethod.POST)
	public String view(@PathVariable String visitId, ModelMap modelMap){
		logger.info("visitId :-- " + visitId);
		List<String> billNumbers = visitService.getBillNumberOfVisit(visitId);
		modelMap.put("billNumbers", billNumbers);
		return PAGE_PREFIX + "billDetailView";
	}
}
