package com.slktechlabs.pms.system.controller.masters;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.slktechlabs.pms.system.annotation.RequestBodyParam;
import com.slktechlabs.pms.system.constants.MessageConstants.UserMessagesEnum;
import com.slktechlabs.pms.system.constants.StatusConstants;
import com.slktechlabs.pms.system.model.RefferMaster;
import com.slktechlabs.pms.system.model.SearchCriteria;
import com.slktechlabs.pms.system.model.Response.ResponseBean;
import com.slktechlabs.pms.system.service.RefferMasterService;
import com.slktechlabs.pms.system.util.ResponseGenerator;

@Controller
@RequestMapping("reffer")
public class RefferMasterController {
	
	Logger logger = Logger.getLogger(this.getClass());
	
	@Autowired
	RefferMasterService refferMasterService;
	
	@RequestMapping(value = "add", method = RequestMethod.POST)
	@ResponseBody
	public ResponseBean createUser(@RequestBody RefferMaster refferMaster) {
		Boolean exist = refferMasterService.uniqueCheck("name", refferMaster.getName(), refferMaster.getId());
		if(exist){
			return ResponseGenerator.generateResponse(StatusConstants.error, UserMessagesEnum.UNIQUE.message("name"));
		}
		refferMasterService.save(refferMaster, "Reffer Added");
			return ResponseGenerator.generateResponse(StatusConstants.success,
					UserMessagesEnum.ADD_SUCCESS.message("Reffer Master"));
		}
	
	@RequestMapping(value ="update", method= RequestMethod.POST)
	@ResponseBody
	public ResponseBean update(@RequestBody RefferMaster refferMaster) {
		Boolean exist = refferMasterService.uniqueCheck("name", refferMaster.getName(), refferMaster.getId());
		if(exist){
			return ResponseGenerator.generateResponse(StatusConstants.error, UserMessagesEnum.UNIQUE.message("name"));
		}
		refferMasterService.update(refferMaster, "Reffer Master Update");
		return ResponseGenerator.generateResponse(StatusConstants.success,
				UserMessagesEnum.UPDATE_SUCCESS.message("Reffer master"), refferMaster);
	}
	@RequestMapping(value ="search", method= RequestMethod.POST)
	@ResponseBody
	public ResponseBean search(@RequestBody SearchCriteria searchCriteria) {
		return ResponseGenerator.generateResponse(StatusConstants.success,
				refferMasterService.search(searchCriteria));
	}
	
	@RequestMapping(value ="delete", method= RequestMethod.POST)
	@ResponseBody
	public ResponseBean delete(@RequestBodyParam String id) {
		refferMasterService.delete(id);
		return ResponseGenerator.generateResponse(StatusConstants.success,
				UserMessagesEnum.DELETE_SUCCESS.message("Reffer Master"));
	}
	
	@RequestMapping(value ="get", method= RequestMethod.POST)
	@ResponseBody
	public ResponseBean get(@RequestBodyParam String id) {
		return ResponseGenerator.generateResponse(StatusConstants.success,
				refferMasterService.findOne(id));
	}
	
}
