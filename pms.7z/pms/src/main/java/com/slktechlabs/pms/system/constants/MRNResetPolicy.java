package com.slktechlabs.pms.system.constants;

public enum MRNResetPolicy {
	MONTHLY("MONTHLY","Month Wise"), YEARLY("YEARLY","Year Wise"),NONE("NONE","NONE");
	
	private String policy;
	private String displayPolicy;
	
	private MRNResetPolicy(String policy, String displayPolicy){
		this.displayPolicy = displayPolicy;
		this.policy = policy;
	}

	public String getPolicy() {
		return policy;
	}

	public String getDisplayPolicy() {
		return displayPolicy;
	}
	
	@Override
	public String toString() {
		return policy;
	}

}
