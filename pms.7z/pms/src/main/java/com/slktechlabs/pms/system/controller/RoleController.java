package com.slktechlabs.pms.system.controller;

import java.beans.IntrospectionException;
import java.lang.reflect.InvocationTargetException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.slktechlabs.pms.system.annotation.RequestBodyParam;
import com.slktechlabs.pms.system.constants.MessageConstants.UserMessagesEnum;
import com.slktechlabs.pms.system.constants.MasterStatus;
import com.slktechlabs.pms.system.constants.StatusConstants;
import com.slktechlabs.pms.system.model.SearchCriteria;
import com.slktechlabs.pms.system.model.Response.ResponseBean;
import com.slktechlabs.pms.system.model.role.Role;
import com.slktechlabs.pms.system.service.RoleService;
import com.slktechlabs.pms.system.util.ResponseGenerator;

@Controller
@RequestMapping("role")
public class RoleController {
	
	@Autowired
	private RoleService roleService;
	
	/**
	 * Search The List of Roles According To List of SearchCriteria
	 * @param list of search criteria
	 * @return list of role
	 * @throws IntrospectionException 
	 * @throws InvocationTargetException 
	 * @throws IllegalArgumentException 
	 * @throws IllegalAccessException 
	 */
	@ResponseBody
	@RequestMapping(value = "list", method = RequestMethod.POST)
	public ResponseBean getRolesList(@RequestBody(required=false) SearchCriteria searchCriteria){
		return ResponseGenerator.generateResponse(StatusConstants.success, 
				roleService.searchRole(searchCriteria));
	}
	
	/** add new role
	 * @param role
	 * @return message
	 */
	@RequestMapping(value = "add", method = RequestMethod.POST)
	@ResponseBody
	public ResponseBean add(@RequestBody Role role) {
		boolean isExist = roleService.uniqueCheck("name", role.getName(), role.getId());
		if(isExist){
			return ResponseGenerator.generateResponse(StatusConstants.error, UserMessagesEnum.UNIQUE.message("name"));
		}
		roleService.save(role, "Add Role");
		return ResponseGenerator.generateResponse(StatusConstants.success,
					UserMessagesEnum.ADD_SUCCESS.message("Role"));
	}
	
	/**
	 * @param searchCriteria
	 * @return List<String> list of values of key get from searchCriteria
	 * @throws Exception
	 */
	@RequestMapping(value = "autoSearch", method = RequestMethod.POST)
	@ResponseBody
	public ResponseBean autoSearch(@RequestBody SearchCriteria searchCriteria){
		return ResponseGenerator.generateResponse(StatusConstants.success,
				 roleService.autoSearchRole(searchCriteria));
	}

	/**
	 * update role
	 * @param role
	 * @return message
	 */
	@RequestMapping(value = "update", method = RequestMethod.POST)
	@ResponseBody
	public ResponseBean update(@RequestBody Role role) {
		ResponseBean responseBean = roleService.checkNameAvailabilityAndRoleStatus(role, true);
		if(responseBean.getType() == StatusConstants.error){
			return responseBean;
		}
		roleService.update(role, "Role Update");
		return ResponseGenerator.generateResponse(StatusConstants.success,
				UserMessagesEnum.UPDATE_SUCCESS.message("Role"));
	}
	
	@RequestMapping(value = "get", method = RequestMethod.POST)
	@ResponseBody
	public Object get(@RequestBodyParam String id) throws Exception {
		return ResponseGenerator.generateResponse(StatusConstants.success,
				 roleService.findOne(id));
	}
	
	@ResponseBody
	@RequestMapping(value = "changeStatus", method = RequestMethod.POST)
	public ResponseBean changeStatus(@RequestBodyParam String roleId, @RequestBodyParam MasterStatus status) {
		return roleService.changeStatus(roleId, status);
	}
	
}
