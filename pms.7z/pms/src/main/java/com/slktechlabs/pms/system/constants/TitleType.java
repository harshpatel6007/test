package com.slktechlabs.pms.system.constants;

public enum TitleType {
	
	Mrs("Mrs"), 
	Miss("Miss"),
	Mr("Mr"),
	Shri("Shri"),
	Smt("Smt");
	
	private final String displayTitle;

	private TitleType(String displayTitle) {
		this.displayTitle = displayTitle;
	}

	public String getDisplayTitle() {
		return displayTitle;
	}

	@Override
	public String toString() {
		return displayTitle;
	}

}
