package com.slktechlabs.pms.system.dao;

import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Repository;

import com.slktechlabs.pms.system.constants.SessionType;
import com.slktechlabs.pms.system.model.UserSessionDetail;

@Repository
public class UserSessionDetailDao extends HMISDao<UserSessionDetail, String>{

//	private Logger logger = Logger.getLogger(getClass());
	
	public UserSessionDetail getLoginSessionByUserAndTokenId(String token_id,
			String userMongoId) {
		Query query = new Query();
		query.addCriteria(Criteria.where("userMongoId").is(userMongoId));
		query.addCriteria(Criteria.where("token_id").is(token_id));
		query.addCriteria(Criteria.where("sessionType").is(SessionType.LOGIN.name()));
		query.fields().include("appType");
		return findOne(query);
	}

}
