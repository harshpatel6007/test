package com.slktechlabs.pms.system.controller;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.mongodb.Mongo;
import com.slktechlabs.pms.system.HmisMongoDetail;
import com.slktechlabs.pms.system.constants.StatusConstants;
import com.slktechlabs.pms.system.oauth2.UserDetail;
import com.slktechlabs.pms.system.util.RequestUtils;
import com.slktechlabs.pms.system.util.ResponseGenerator;

/**
 * Default controller
 */
@Controller
public class DefaultController {

	Logger logger = Logger.getLogger(DefaultController.class);

	@Autowired
	Mongo mongo;
	
	@Autowired
	HmisMongoDetail hmisMongoDetail;  
	
	@RequestMapping("echo")
	@ResponseBody
	public Object unmappedRequest() {
		return ResponseGenerator.generateResponse(StatusConstants.success, "Echo Request !!!!!");
	}
	
	@RequestMapping("echoWithAuth")
	@ResponseBody
	public Object echoWithAuth() {
		UserDetail userDetail = RequestUtils.getUserDetail();
		if(userDetail != null) {
			return ResponseGenerator.generateResponse(StatusConstants.success, 
					"User Authnticated successfully!!!!!");
		} else {
			return ResponseGenerator.generateResponse(StatusConstants.error, 
					"User session invalid");
		}
		
	}
	
	@RequestMapping("getMongoDetail")
	@ResponseBody
	public Object getMongoDetail() {
		
		
		StringBuilder builder = new StringBuilder();
		
		builder.append("mongo -->"+ mongo);
		
		builder.append("mongo.getServerAddressList() -->"+ mongo.getServerAddressList());
		
		builder.append("mongo.getAddress() -->"+ mongo.getAddress());
		
		builder.append("mongo.getReplicaSetStatus()-->"+ mongo.getReplicaSetStatus());
		
		builder.append("hmisMongoDetail-->"+ hmisMongoDetail.toString());
		
		return ResponseGenerator.generateResponse(StatusConstants.success, builder);
	}

	@RequestMapping("echoNotification")
	@ResponseBody
	public Object echoNotification() {
		return ResponseGenerator.generateResponse(StatusConstants.success, "Echo Notification Request !!!!!");
	}
}
