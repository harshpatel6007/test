package com.slktechlabs.pms.system;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

import org.apache.log4j.Logger;

public class HIMSServletContextListener implements ServletContextListener {

	Logger logger = Logger.getLogger(this.getClass());

	@Override
	public void contextInitialized(ServletContextEvent sce) {
		
		System.out.println("context initialized........." + sce.getServletContext()
				.getRealPath(""));
		
		System.out.println("context initialized.........");

	}

	@Override
	public void contextDestroyed(ServletContextEvent sce) {
		logger.info("context destroyed........");

	}
}
