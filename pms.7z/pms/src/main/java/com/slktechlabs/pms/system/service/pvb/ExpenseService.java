package com.slktechlabs.pms.system.service.pvb;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.slktechlabs.pms.system.dao.pvb.ExpenseDao;
import com.slktechlabs.pms.system.model.bill.ExpenseCollection;
import com.slktechlabs.pms.system.service.HMISService;

@Service
public class ExpenseService extends HMISService<ExpenseCollection, String>{

	private ExpenseDao expenseDao;
	
	@Autowired
	public ExpenseService(ExpenseDao expenseDao) {
		super(expenseDao);
		this.expenseDao = expenseDao;
	}

}
