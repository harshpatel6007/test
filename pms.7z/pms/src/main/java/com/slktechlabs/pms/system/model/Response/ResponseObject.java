package com.slktechlabs.pms.system.model.Response;

import com.slktechlabs.pms.system.constants.StatusConstants;

public class ResponseObject<T> {

	private String message;
	private StatusConstants type;
	private String code;
	private T data;

	public ResponseObject() {
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public StatusConstants getType() {
		return type;
	}

	public void setType(StatusConstants type) {
		this.type = type;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public T getData() {
		return data;
	}

	public void setData(T data) {
		this.data = data;
	}

	@Override
	public String toString() {
		return "ResponseObject [message=" + message + ", type=" + type + ", code=" + code + ", data=" + data + "]";
	}

}