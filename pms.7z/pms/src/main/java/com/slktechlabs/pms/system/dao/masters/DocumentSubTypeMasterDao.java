package com.slktechlabs.pms.system.dao.masters;

import java.util.List;

import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Repository;
import org.springframework.util.StringUtils;

import com.slktechlabs.pms.system.dao.HMISDao;
import com.slktechlabs.pms.system.model.master.DocumentSubTypeMaster;

@Repository
public class DocumentSubTypeMasterDao extends HMISDao<DocumentSubTypeMaster, String>{

	public List<DocumentSubTypeMaster> search(String documentSubTypeName, String documentTypeId) {
		Query query = new Query();
		if(StringUtils.hasText(documentSubTypeName)){
			query.addCriteria(Criteria.where("name").is(documentSubTypeName));
		}
		if(StringUtils.hasText(documentTypeId)){
			query.addCriteria(Criteria.where("documentTypeId").is(documentTypeId));
		}
    	query.with(new Sort(Direction.DESC, "modified"));        
    	return findAll(query);
	}

	public boolean checkDocumentTypeMasterExist(String documentTypeId) {
		Query query = new Query();
		query.addCriteria(Criteria.where("documentTypeId").is(documentTypeId));
		return count(query)>0;
	}

	public List<DocumentSubTypeMaster> getByDocTypeId(String docTypeId) {
		Query query = new Query();
		query.addCriteria(Criteria.where("documentTypeId").is(docTypeId));
		return findAll(query);
	}

}
