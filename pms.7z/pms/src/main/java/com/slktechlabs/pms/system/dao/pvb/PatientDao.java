package com.slktechlabs.pms.system.dao.pvb;

import java.util.List;

import org.apache.log4j.Logger;
import org.bson.types.ObjectId;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Repository;

import com.slktechlabs.pms.system.dao.HMISDao;
import com.slktechlabs.pms.system.model.SearchCriteria;
import com.slktechlabs.pms.system.model.patient.Patient;
import com.slktechlabs.pms.system.util.SearchUtils;

@Repository
public class PatientDao extends HMISDao<Patient, String> {

	private Logger logger = Logger.getLogger(getClass());

	public List<Patient> customAutoSearch(String input) {
		
		String regexString = SearchUtils.getRegexPatternForSearchAtStart(input);
		
		Criteria criteria = new Criteria();
		criteria.orOperator(
			Criteria.where("patientId").regex(regexString, "i"),
			Criteria.where("firstName").regex(regexString, "i"),
			Criteria.where("phoneNumber").regex(regexString, "i"),
			Criteria.where("middleName").regex(regexString, "i"),
			Criteria.where("lastName").regex(regexString, "i")
		);
		
		Query query = new Query();
		query.addCriteria(criteria);
		
		query.fields().include("patientId");
		query.fields().include("firstName");
		query.fields().include("phoneNumber");
		query.fields().include("middleName");
		query.fields().include("lastName");
		
		query.with(new Sort(Sort.Direction.DESC, "registrationDate"));
		query.limit(20);
		
		return findAll(query);
	}	
	public void updatePhoto(String storagePathName, String imageName,
			String patientId) {
		Query query = new Query();
		query.addCriteria(Criteria.where("_id").is(patientId));
		Update update =  new Update();
		update.set("patientPhotoStoragePath", storagePathName);
		update.set("patientPhotoName", imageName);
		update(query, update, "Photo Uploaded");
	}
	public List<Patient> search(SearchCriteria searchCriteria) {
		Query query = new Query();
    	if (searchCriteria != null) {
    		query.addCriteria(Criteria.where(searchCriteria.getKey())
        		.regex(SearchUtils.getRegexPatternForSearchAtStart(searchCriteria.getValue()), "i"));
    	}
    	query.limit(20);
    	query.with(new Sort(Direction.DESC, "modified"));        
    	return findAll(query);
	}
	public Patient getPatientNameById(String id) {
		System.out.println("id >>>" +id);
		Query query = new Query();
		query.addCriteria(Criteria.where("_id").is(new ObjectId(id)));
		query.fields().include("patientId");
		query.fields().include("firstName");
		query.fields().include("phoneNumber");
		query.fields().include("middleName");
		query.fields().include("lastName");
		return findOne(query);
	}
	
}
