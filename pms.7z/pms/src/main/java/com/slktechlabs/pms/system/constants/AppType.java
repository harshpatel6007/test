package com.slktechlabs.pms.system.constants;

public enum AppType {

	JavaFX("Java FX"), Android("Andriod"), IPhone("IPhone"), 
	ThirdParty("Third Party") , Webbrowser("Web browser"),JavaFX_Patho_Machine("Java FX Patho Machine") ;
	
	private String appTypeDisplayName;
	
	private AppType(String appTypeDisplayName) {
		this.appTypeDisplayName = appTypeDisplayName;
	}
	
	@Override
	public String toString() {
		return appTypeDisplayName;
	}
}
