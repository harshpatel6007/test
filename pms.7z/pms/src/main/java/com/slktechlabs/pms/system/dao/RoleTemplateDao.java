package com.slktechlabs.pms.system.dao;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Repository;

import com.slktechlabs.pms.system.model.role.RoleTemplate;

@Repository
public class RoleTemplateDao extends HMISDao<RoleTemplate, String>{

	Logger logger=Logger.getLogger(getClass());
	
	/**
	 * Change The Name Of Given Access In Group
	 * @param group
	 */
	public void changeAccess(RoleTemplate group){
		RoleTemplate resultGroup=(RoleTemplate) findOne(group.getId());
		Update update=new Update();
		
		for(int i=0;i<group.getAccess().size();i++){
			for(int j=0;j<resultGroup.getAccess().size();j++){
				if(group.getAccess().get(i).getKey().equals(resultGroup.getAccess().get(j).getKey())){
					Query query=new Query();
					query.addCriteria(Criteria.where("_id").is(group.getId()));
					query.addCriteria(Criteria.where("access.key").is(group.getAccess().get(i).getKey()));
					logger.info("inside if");					
					update.set("access.$.name",group.getAccess().get(i).getName());
					update.set("access.$.description",group.getAccess().get(i).getDescription());
					update(query, update, "Change Access");
					break;
				}
			}			
		}		
	}
	
	/**
	 * Add Accesses At The End Of List Without Checking Existence
	 * @param group
	 */
	public void addAccess(RoleTemplate group){
		Query query=new Query();
		query.addCriteria(Criteria.where("_id").is(group.getId()));
		Update update=new Update();
		update.pushAll("access", group.getAccess().toArray());
		update(query, update, "Add Access");
	}
	
	public List<RoleTemplate> findAll() {
		Query query = new Query();
		query.with(new Sort(Direction.ASC, "name"));
		return find(query);
	}

	
}
