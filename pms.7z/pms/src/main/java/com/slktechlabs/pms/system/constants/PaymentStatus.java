package com.slktechlabs.pms.system.constants;

public enum PaymentStatus {

	CLEARED("Clear"),NON_CLEARED("Non Clear"),CANCELLED("Cancelled");

	private final String type;

	private PaymentStatus(String displayName) {
		type = displayName;
	}

	public String getType() {
		return type;
	}

	@Override
	public String toString() {
		return type;
	}
}
