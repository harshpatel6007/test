package com.slktechlabs.pms.system.model;

import org.springframework.data.mongodb.core.mapping.Document;

import com.slktechlabs.pms.system.constants.MRNType;

@Document(collection = "systemMRNConfiguration")
public class SystemMRNConfiguration extends AbstractDocument{
	private MRNType mrnType;
	private MRNConfiguration mrnConfiguration;

	public MRNType getMrnType() {
		return mrnType;
	}

	public void setMrnType(MRNType mrnType) {
		this.mrnType = mrnType;
	}

	public MRNConfiguration getMrnConfiguration() {
		return mrnConfiguration;
	}

	public void setMrnConfiguration(MRNConfiguration mrnConfiguration) {
		this.mrnConfiguration = mrnConfiguration;
	}

	@Override
	public String toString() {
		return "SystemMRNConfiguration [mrnType=" + mrnType
				+ ", mrnConfiguration=" + mrnConfiguration + "]";
	}

}
