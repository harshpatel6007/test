package com.slktechlabs.pms.system.model.bill;

import java.util.Date;

import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

import com.slktechlabs.pms.system.annotation.CustomJoin;
import com.slktechlabs.pms.system.model.AbstractDocument;
import com.slktechlabs.pms.system.model.User;

@Document(collection = "expenseCollection")
public class ExpenseCollection extends AbstractDocument{

	private String itemId;

	private String patientId;
	private String billId;
	private String visitId;
	
	private Date date;
	private String expenseBy;
	@CustomJoin(joinId = "expenseBy", value = { "displayName" }, isInclude = true)
	private User expenseUser;
	
	private String status;
	
	private String deletedBy;
	@CustomJoin(joinId = "deletedBy", value = { "displayName" }, isInclude = true)
	private User deletedByUser;
	@Indexed(useGeneratedName = true, background = true)
	private Date deletedDate;
	
	private double quantity;
	private double originalItemPrice;
	private double discount;
	/**
	 * amount of single item after counting discount available on it
	 */
	private double amount;	
	private double concession;
	private double netPrice;
	
	public String getItemId() {
		return itemId;
	}
	public void setItemId(String itemId) {
		this.itemId = itemId;
	}
	public String getPatientId() {
		return patientId;
	}
	public void setPatientId(String patientId) {
		this.patientId = patientId;
	}
	public String getBillId() {
		return billId;
	}
	public void setBillId(String billId) {
		this.billId = billId;
	}
	public String getVisitId() {
		return visitId;
	}
	public void setVisitId(String visitId) {
		this.visitId = visitId;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	public String getExpenseBy() {
		return expenseBy;
	}
	public void setExpenseBy(String expenseBy) {
		this.expenseBy = expenseBy;
	}
	public User getExpenseUser() {
		return expenseUser;
	}
	public void setExpenseUser(User expenseUser) {
		this.expenseUser = expenseUser;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getDeletedBy() {
		return deletedBy;
	}
	public void setDeletedBy(String deletedBy) {
		this.deletedBy = deletedBy;
	}
	public User getDeletedByUser() {
		return deletedByUser;
	}
	public void setDeletedByUser(User deletedByUser) {
		this.deletedByUser = deletedByUser;
	}
	public Date getDeletedDate() {
		return deletedDate;
	}
	public void setDeletedDate(Date deletedDate) {
		this.deletedDate = deletedDate;
	}
	public double getQuantity() {
		return quantity;
	}
	public void setQuantity(double quantity) {
		this.quantity = quantity;
	}
	public double getOriginalItemPrice() {
		return originalItemPrice;
	}
	public void setOriginalItemPrice(double originalItemPrice) {
		this.originalItemPrice = originalItemPrice;
	}
	public double getDiscount() {
		return discount;
	}
	public void setDiscount(double discount) {
		this.discount = discount;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	public double getConcession() {
		return concession;
	}
	public void setConcession(double concession) {
		this.concession = concession;
	}
	public double getNetPrice() {
		return netPrice;
	}
	public void setNetPrice(double netPrice) {
		this.netPrice = netPrice;
	}
	
	@Override
	public String toString() {
		return "ExpenseCollection [itemId=" + itemId + ", patientId="
				+ patientId + ", billId=" + billId + ", visitId=" + visitId
				+ ", date=" + date + ", expenseBy=" + expenseBy
				+ ", expenseUser=" + expenseUser + ", status=" + status
				+ ", deletedBy=" + deletedBy + ", deletedByUser="
				+ deletedByUser + ", deletedDate=" + deletedDate
				+ ", quantity=" + quantity + ", originalItemPrice="
				+ originalItemPrice + ", discount=" + discount + ", amount="
				+ amount + ", concession=" + concession + ", netPrice="
				+ netPrice + "]";
	}	
	
}
