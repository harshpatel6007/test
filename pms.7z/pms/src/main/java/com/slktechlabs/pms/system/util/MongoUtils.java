package com.slktechlabs.pms.system.util;

import java.util.ArrayList;
import java.util.List;

import org.bson.types.ObjectId;
import org.springframework.util.Assert;

public class MongoUtils {

	public static List<String> getStringFromObjectIds(List<ObjectId> objectIds) {
		Assert.notNull(objectIds, "ObjectId List must not be null");
		List<String> list = new ArrayList<String>();
		for(ObjectId objectId : objectIds) {
			list.add(objectId.toHexString());
		}
		return list;
	}
	
	public static List<ObjectId> getObjectIdsFromString(List<String> list) {
		Assert.notNull(list, "String List must not be null");
		List<ObjectId> objectIds = new ArrayList<ObjectId>();
		for(String string : list) {
			objectIds.add(new ObjectId(string));
		}
		return objectIds;
	}
	
}
