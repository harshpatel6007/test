package com.slktechlabs.pms.system.controller.masters;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.slktechlabs.pms.system.annotation.RequestBodyParam;
import com.slktechlabs.pms.system.constants.MessageConstants.UserMessagesEnum;
import com.slktechlabs.pms.system.constants.StatusConstants;
import com.slktechlabs.pms.system.model.ConcessionTypeMaster;
import com.slktechlabs.pms.system.model.SearchCriteria;
import com.slktechlabs.pms.system.model.Response.ResponseBean;
import com.slktechlabs.pms.system.service.ConcessionMasterService;
import com.slktechlabs.pms.system.util.ResponseGenerator;

@Controller
@RequestMapping("concession")
public class ConcessionMasterController {
	
	Logger logger = Logger.getLogger(this.getClass());
	
	@Autowired
	ConcessionMasterService concessionMasterService;
	
	@RequestMapping(value = "add", method = RequestMethod.POST)
	@ResponseBody
	public ResponseBean createUser(@RequestBody ConcessionTypeMaster concessionTypeMaster) {
		Boolean exist = concessionMasterService.uniqueCheck("name", concessionTypeMaster.getName(), concessionTypeMaster.getId());
		if(exist){
			return ResponseGenerator.generateResponse(StatusConstants.error, UserMessagesEnum.UNIQUE.message("name"));
		}
		concessionMasterService.save(concessionTypeMaster, "Concession Type Added");
			return ResponseGenerator.generateResponse(StatusConstants.success,
					UserMessagesEnum.ADD_SUCCESS.message("Concession Type"));
		}
	
	@RequestMapping(value ="update", method= RequestMethod.POST)
	@ResponseBody
	public ResponseBean update(@RequestBody ConcessionTypeMaster concessionTypeMaster) {
		Boolean exist = concessionMasterService.uniqueCheck("name", concessionTypeMaster.getName(), concessionTypeMaster.getId());
		if(exist){
			return ResponseGenerator.generateResponse(StatusConstants.error, UserMessagesEnum.UNIQUE.message("name"));
		}
		concessionMasterService.update(concessionTypeMaster, "Concession Type Master Update");
		return ResponseGenerator.generateResponse(StatusConstants.success,
				UserMessagesEnum.UPDATE_SUCCESS.message("Concession Type master"), concessionTypeMaster);
	}
	@RequestMapping(value ="search", method= RequestMethod.POST)
	@ResponseBody
	public ResponseBean search(@RequestBody SearchCriteria searchCriteria) {
		return ResponseGenerator.generateResponse(StatusConstants.success,
				concessionMasterService.search(searchCriteria));
	}
	
	@RequestMapping(value ="delete", method= RequestMethod.POST)
	@ResponseBody
	public ResponseBean delete(@RequestBodyParam String id) {
		concessionMasterService.delete(id);
		return ResponseGenerator.generateResponse(StatusConstants.success,
				UserMessagesEnum.DELETE_SUCCESS.message("Concession Type Master"));
	}
	
	@RequestMapping(value ="get", method= RequestMethod.POST)
	@ResponseBody
	public ResponseBean get(@RequestBodyParam String id) {
		return ResponseGenerator.generateResponse(StatusConstants.success,
				concessionMasterService.findOne(id));
	}
	
}
