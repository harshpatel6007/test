package com.slktechlabs.pms.system.constants;

public enum MasterStatus {

	ACTIVE("Active"), 
	INACTIVE("In-Active");
	
	private final String displayStatus;

	private MasterStatus(String displayStatus) {
		this.displayStatus = displayStatus;
	}

	public String getDisplayStatus() {
		return displayStatus;
	}

	@Override
	public String toString() {
		return displayStatus;
	}
}
