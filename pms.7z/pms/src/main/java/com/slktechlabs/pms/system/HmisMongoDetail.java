package com.slktechlabs.pms.system;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.mongodb.Mongo;

@Component
public class HmisMongoDetail {

	@Autowired
	Mongo mongo;

	@Value("${dbname}")
	private String dbname;

	@Value("${mongoDBusername}")
	private String username;

	@Value("${mongoDBpassword}")
	private String password;

	@Value("${mongoDBauthenticationdbname}")
	private String authenticationdbname;

	@Value("${remoteMongoDbBackuoLocation}")
	private String remoteMongoDbBackuoLocation;

	
	public String getPort() {
		return String.valueOf(mongo.getAddress().getPort());
	}

	public String getHost() {
		return String.valueOf(mongo.getAddress().getHost());
	}

	public String getDbname() {
		return dbname;
	}

	public String getUsername() {
		return username;
	}

	public String getPassword() {
		return password;
	}

	public String getAuthenticationdbname() {
		return authenticationdbname;
	}

	public String getRemoteMongoDbBackuoLocation() {
		return remoteMongoDbBackuoLocation;
	}

	@Override
	public String toString() {
		return "HmisMongoDetail [dbname=" + dbname + ", username=" + username + ", password=" + password
				+ ", authenticationdbname=" + authenticationdbname + ", remoteMongoDbBackuoLocation=" + remoteMongoDbBackuoLocation + ", getPort()="
				+ getPort() + ", getHost()=" + getHost() + "]";
	}
	
}
