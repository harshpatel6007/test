package com.slktechlabs.pms.system.oauth2;

import org.springframework.stereotype.Component;

import com.slktechlabs.pms.system.util.RequestUtils;

@Component
public class ClientDetailsService {

	public UserDetail getUserDetail() {
		return RequestUtils.getUserDetail();
	}

}
