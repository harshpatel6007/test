package com.slktechlabs.pms.system.controller.pvb;

import java.io.File;
import java.util.Date;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.io.FilenameUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import com.slktechlabs.pms.system.annotation.RequestBodyParam;
import com.slktechlabs.pms.system.constants.MessageConstants;
import com.slktechlabs.pms.system.constants.MessageConstants.UserMessagesEnum;
import com.slktechlabs.pms.system.constants.SettingsConstants;
import com.slktechlabs.pms.system.constants.StatusConstants;
import com.slktechlabs.pms.system.model.Response.ResponseBean;
import com.slktechlabs.pms.system.model.visit.ScanDocumentDetails;
import com.slktechlabs.pms.system.model.visit.Visit;
import com.slktechlabs.pms.system.model.visit.VisitStatus;
import com.slktechlabs.pms.system.service.pvb.VisitService;
import com.slktechlabs.pms.system.util.ResponseGenerator;

@Controller
@RequestMapping("visit")
public class VisitController {

	@Autowired
	private VisitService visitService;
	
	Logger logger = Logger.getLogger(getClass());
	
	@RequestMapping(value ="update", method= RequestMethod.POST)
	@ResponseBody
	public ResponseBean update(@RequestBody Visit visit ) {
		visitService.update(visit, "Clinic Note Added");
		return ResponseGenerator.generateResponse(StatusConstants.success,
				UserMessagesEnum.UPDATE_SUCCESS.message("Visit"), visit);
	}
	
	@RequestMapping(value ="get", method= RequestMethod.POST)
	@ResponseBody
	public ResponseBean get(@RequestBodyParam String id) {
		return ResponseGenerator.generateResponse(StatusConstants.success,
				visitService.findOne(id));
	}
	
	@RequestMapping(value ="add", method= RequestMethod.POST)
	@ResponseBody
	public ResponseBean add(@RequestBodyParam String id) {
		return ResponseGenerator.generateResponse(StatusConstants.success,UserMessagesEnum.ADD_SUCCESS.message("Visit"),
				visitService.createVisitFromWalkIn(id));
	}
	
	@RequestMapping(value ="uploadScanDocuments", method= RequestMethod.POST)
	@ResponseBody
	public ResponseBean uploadScanDocuments(@ModelAttribute MultipartFile file, 
			@ModelAttribute("documentSubTypeId") String documentSubTypeId,
			@ModelAttribute("documentTypeId") String documentTypeId,
			@ModelAttribute("visitId") String visitId, @ModelAttribute("documentUuid") String documentUuid, HttpServletRequest request) {
		
		ScanDocumentDetails scanDocumentDetails = new ScanDocumentDetails();
		
		String uuid = UUID.randomUUID().toString();
		String fileName = file.getOriginalFilename();
		String fileExtension = FilenameUtils.getExtension(fileName);
		
		File visitStorage = new File(SettingsConstants.VISIT_DOCUMENT_PATH + File.separator + visitId,
								scanDocumentDetails.getDocumentSubTypeId());
		
		if (!visitStorage.exists()) {
			visitStorage.getParentFile().mkdirs();
			visitStorage.mkdirs();
		}

		File pdfFile = new File(visitStorage, uuid + "." + fileExtension);

		if (!pdfFile.exists()) {
			pdfFile.getParentFile().mkdirs();
		}

		if (!pdfFile.canWrite()) {
			pdfFile.setWritable(true);
		}
		try {
			file.transferTo(pdfFile);
			
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
			return ResponseGenerator.generateResponse(StatusConstants.error,
					"Error occured while reading the file.");
		}
		scanDocumentDetails.setDocumentSubTypeId(documentSubTypeId);
		scanDocumentDetails.setDocumentTypeId(documentTypeId);
		scanDocumentDetails.setUploadDate(new Date());
		scanDocumentDetails.setUuid(uuid);
		scanDocumentDetails.setDocumentFileName(fileName);
		scanDocumentDetails.setDocumentStoragePath(pdfFile.getName());
		scanDocumentDetails.setLastViewedDate(new Date());
		Visit visit = visitService.updateScanDocument(scanDocumentDetails, visitId);
		
		System.out.println("visit.getScanDocumentDetails() >>>>>>>>>>>" +visit.getScanDocumentDetails());
		return ResponseGenerator.generateResponse(StatusConstants.success, MessageConstants.FILE_UPLOAD, visit.getScanDocumentDetails());
	}
	
	@RequestMapping(value ="changeStatus", method= RequestMethod.POST)
	@ResponseBody
	public ResponseBean changeStatusToArrived(@RequestBodyParam String visitId, 
			@RequestBodyParam String userId, @RequestBodyParam VisitStatus status) {
		visitService.changeStatus(visitId, userId, status);
		return ResponseGenerator.generateResponse(StatusConstants.success,
				UserMessagesEnum.UPDATE_SUCCESS.message("Visit Status"));
	}
	
}
