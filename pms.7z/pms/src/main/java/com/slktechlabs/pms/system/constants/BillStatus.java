package com.slktechlabs.pms.system.constants;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;

public enum BillStatus {

		Open("Open", "Open"), 
		FinalBillInitiated("FinalBillInitiated", "Final Bill Initiated"), 
		FinalBillGenerated("FinalBillGenerated", "Final Bill Generated"), 
		DischargeCancelInitiated("DischargeCancelInitiated", 
				"Discharge Cancel Initiated"),
		ReOpen("ReOpen", "ReOpen"),
		Cancelled("Cancelled","Cancelled");
		
		private String name;
		private String displayName;

		private BillStatus(String name, String displayName) {
			this.name = name;
			this.displayName = displayName;
		}

		@JsonValue
		public String getName() {
			return name;
		}

		public String getDisplayName() {
			return displayName;
		}

		@JsonCreator
		public BillStatus fromStatusCode(String status) {
			for (BillStatus wfType : BillStatus.values()) {
				return wfType;
			}
			throw new IllegalArgumentException("Invalid Status type code: " + status);
		}

		@Override
		public String toString() {
			return name;
		}
	}
