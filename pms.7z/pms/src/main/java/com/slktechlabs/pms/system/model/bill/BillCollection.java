package com.slktechlabs.pms.system.model.bill;

import java.util.Date;

import org.springframework.data.mongodb.core.mapping.Document;

import com.slktechlabs.pms.system.constants.BillStatus;
import com.slktechlabs.pms.system.model.AbstractDocument;

@Document(collection = "billCollection")
public class BillCollection extends AbstractDocument {

	private String patientId;
	private String billNumber;
	private String visitId;	

	private Date createdDate;
	private String createdBy;

	private BillStatus status;
	
	private double totalExpense;
	/**
	 * net total expense which should be paid by patient
	 */
	private double netExpense;

	// self payment detail
	private double paymentByPatient;
	private double usedSelfAmount;// used self amount
	private double remainingSelfAmount;

	//relief
	private double totalDiscount;
	private String concessionId;
	
	
	public String getPatientId() {
		return patientId;
	}
	public void setPatientId(String patientId) {
		this.patientId = patientId;
	}
	public String getBillNumber() {
		return billNumber;
	}
	public void setBillNumber(String billNumber) {
		this.billNumber = billNumber;
	}
	public String getVisitId() {
		return visitId;
	}
	public void setVisitId(String visitId) {
		this.visitId = visitId;
	}
	public Date getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public BillStatus getStatus() {
		return status;
	}
	public void setStatus(BillStatus status) {
		this.status = status;
	}
	public double getTotalExpense() {
		return totalExpense;
	}
	public void setTotalExpense(double totalExpense) {
		this.totalExpense = totalExpense;
	}
	public double getNetExpense() {
		return netExpense;
	}
	public void setNetExpense(double netExpense) {
		this.netExpense = netExpense;
	}
	public double getPaymentByPatient() {
		return paymentByPatient;
	}
	public void setPaymentByPatient(double paymentByPatient) {
		this.paymentByPatient = paymentByPatient;
	}
	public double getUsedSelfAmount() {
		return usedSelfAmount;
	}
	public void setUsedSelfAmount(double usedSelfAmount) {
		this.usedSelfAmount = usedSelfAmount;
	}
	public double getRemainingSelfAmount() {
		return remainingSelfAmount;
	}
	public void setRemainingSelfAmount(double remainingSelfAmount) {
		this.remainingSelfAmount = remainingSelfAmount;
	}
	public double getTotalDiscount() {
		return totalDiscount;
	}
	public void setTotalDiscount(double totalDiscount) {
		this.totalDiscount = totalDiscount;
	}
	public String getConcessionId() {
		return concessionId;
	}
	public void setConcessionId(String concessionId) {
		this.concessionId = concessionId;
	}
	
	@Override
	public String toString() {
		return "BillCollection [patientId=" + patientId + ", billNumber="
				+ billNumber + ", visitId=" + visitId + ", createdDate="
				+ createdDate + ", createdBy=" + createdBy + ", status="
				+ status + ", totalExpense=" + totalExpense + ", netExpense="
				+ netExpense + ", paymentByPatient=" + paymentByPatient
				+ ", usedSelfAmount=" + usedSelfAmount
				+ ", remainingSelfAmount=" + remainingSelfAmount
				+ ", totalDiscount=" + totalDiscount + ", concessionId="
				+ concessionId + "]";
	}

}
