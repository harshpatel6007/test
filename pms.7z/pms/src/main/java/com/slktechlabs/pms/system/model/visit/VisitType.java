package com.slktechlabs.pms.system.model.visit;

/**
 * Enum for Visit Types
 */
public enum VisitType {

	OPD("OPD"), IPD("IPD"); 
	
	/*
	 * , FOLLOW_UP_OPD("FOLLOW_UP_OPD", "Followup OPD"),
	 * FOLLOW_UP_IPD("FOLLOW_UP_IPD", "Followup IPD")
	*/

	private final String visitTypeDisplayName;

	private VisitType(String visitTypeDisplayName) {
		this.visitTypeDisplayName = visitTypeDisplayName;
	}

	public String getVisitTypeDisplayName() {
		return visitTypeDisplayName;
	}

}
