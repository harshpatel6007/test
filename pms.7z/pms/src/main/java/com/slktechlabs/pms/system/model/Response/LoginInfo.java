package com.slktechlabs.pms.system.model.Response;

import java.util.Date;

public class LoginInfo {

	private LoginUserDetail userDetail;
	private Date serverDate;

	public LoginInfo(LoginUserDetail userDetail) {
		super();
		this.userDetail = userDetail;
		serverDate = new Date();
	}

	public LoginUserDetail getUserDetail() {
		return userDetail;
	}

	public void setUserDetail(LoginUserDetail userDetail) {
		this.userDetail = userDetail;
	}

	public Date getServerDate() {
		return serverDate;
	}

	public void setServerDate(Date serverDate) {
		this.serverDate = serverDate;
	}

	@Override
	public String toString() {
		return "LoginInfo [userDetail=" + userDetail + ", serverDate="
				+ serverDate + "]";
	}

}
