package com.slktechlabs.pms.system.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.slktechlabs.pms.system.dao.PatientTypeMasterDao;
import com.slktechlabs.pms.system.model.PatientTypeMaster;
import com.slktechlabs.pms.system.model.SearchCriteria;

@Service
public class PatientTypeMasterService extends HMISService<PatientTypeMaster, String>  {

	PatientTypeMasterDao patientTypeMasterDao;
	
	@Autowired
	public PatientTypeMasterService(PatientTypeMasterDao patientTypeMasterDao) {
		super(patientTypeMasterDao);
		this.patientTypeMasterDao = patientTypeMasterDao;
	}

	public List<PatientTypeMaster> search(SearchCriteria searchCriteria) {
		return patientTypeMasterDao.search(searchCriteria);
	}
}
