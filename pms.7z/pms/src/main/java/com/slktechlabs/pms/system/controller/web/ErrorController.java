package com.slktechlabs.pms.system.controller.web;

import javax.servlet.http.HttpServletRequest;

import org.apache.avalon.framework.ExceptionUtil;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.slktechlabs.pms.system.service.ExceptionDetailService;

@Controller
public class ErrorController {

	private static final Logger logger = Logger.getLogger(ErrorController.class);
	
	@Autowired
	ExceptionDetailService exceptionDetailService;
	
	@RequestMapping("servletError")
	public String servletError(HttpServletRequest request) {

		// retrieve some useful information from the request
//		Integer statusCode = (Integer) request.getAttribute("javax.servlet.error.status_code");
//		Throwable throwable = (Throwable) request.getAttribute("javax.servlet.error.exception");
//		// String servletName =
//		// (String)request.getAttribute("javax.servlet.error.servlet_name");
//		String exceptionClass = null;
//		String exceptionMessage = null;
//		String exceptionStackTrace = null;
//		String requestUri = (String) request.getAttribute("javax.servlet.error.request_uri");
//		if (requestUri == null) {
//			requestUri = "Unknown";
//		}
//
//		request.setAttribute("statusCode", statusCode);
//		if(throwable != null) {
//			exceptionClass = throwable.getClass().toString();
//			exceptionMessage = throwable.getMessage();
//			exceptionStackTrace = ExceptionUtil.printStackTrace(throwable);
//			request.setAttribute("exception", exceptionMessage);
//			request.setAttribute("exceptionStackTrace", exceptionStackTrace);
//		}
//		request.setAttribute("url", requestUri);
//		
//		String id = exceptionDetailService.addException(exceptionClass, exceptionMessage, exceptionStackTrace, 
//				requestUri, request.getRemoteAddr());
//		request.setAttribute("id", id);
		logger.info("in error page");
		return "error/servletError";
	}
	
	@RequestMapping("pageError")
	public String pageError() {
		return "error/pageError";
	}
	
	@RequestMapping("noscript")
	public String noscript(HttpServletRequest request) {
		
		logger.info("in noscript page");
		return "error/noscript";
	}
	
	@RequestMapping("noLocalStorage")
	public String noLocalStorage(HttpServletRequest request) {
		return "error/localStorage";
	}
	
	
}
