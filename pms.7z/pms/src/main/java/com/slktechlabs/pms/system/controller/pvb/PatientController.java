package com.slktechlabs.pms.system.controller.pvb;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FilenameUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.util.FileCopyUtils;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import com.slktechlabs.pms.system.annotation.RequestBodyParam;
import com.slktechlabs.pms.system.constants.MessageConstants.UserMessagesEnum;
import com.slktechlabs.pms.system.constants.SettingsConstants;
import com.slktechlabs.pms.system.constants.StatusConstants;
import com.slktechlabs.pms.system.model.SearchCriteria;
import com.slktechlabs.pms.system.model.Response.ResponseBean;
import com.slktechlabs.pms.system.model.patient.Patient;
import com.slktechlabs.pms.system.service.pvb.PatientService;
import com.slktechlabs.pms.system.util.ResponseGenerator;

@Controller
@RequestMapping("patient")
public class PatientController {

	@Autowired
	private PatientService patientService;
	
	Logger logger = Logger.getLogger(getClass());
	
	@RequestMapping(value = "add", method = RequestMethod.POST)
	@ResponseBody
	public ResponseBean add(@RequestBody Patient patient) {
		return ResponseGenerator.generateResponse(StatusConstants.success,
				UserMessagesEnum.ADD_SUCCESS.message("Patient Details"), 
				patientService.add(patient));
	}
	
	@RequestMapping(value = "update", method = RequestMethod.POST)
	@ResponseBody
	public ResponseBean update(@RequestBody Patient patient) {
		patientService.update(patient, "patientUpadte");
		return ResponseGenerator.generateResponse(StatusConstants.success,
				UserMessagesEnum.UPDATE_SUCCESS.message("Patient Details"));
	}
	
	@RequestMapping(value = "customAutoSearch", method = RequestMethod.POST)
	@ResponseBody
	public ResponseBean customAutoSearch(@RequestBody String input) {
		return ResponseGenerator.generateResponse(StatusConstants.success, 
				patientService.customAutoSearch(input));
	}
	
	@RequestMapping(value = "search", method = RequestMethod.POST)
	@ResponseBody
	public ResponseBean search(@RequestBody SearchCriteria searchCriteria) {
		return ResponseGenerator.generateResponse(StatusConstants.success, 
				patientService.search(searchCriteria));
	}
	
	@RequestMapping(value = "get", method = RequestMethod.POST)
	@ResponseBody
	public ResponseBean get(@RequestBodyParam String id) {
		return ResponseGenerator.generateResponse(StatusConstants.success, 
				patientService.findOne(id));
	}
	
	@RequestMapping(value = "getPatientNameById", method = RequestMethod.POST)
	@ResponseBody
	public ResponseBean getPatientNameById(@RequestBodyParam String id) {
		return ResponseGenerator.generateResponse(StatusConstants.success, 
				patientService.getPatientNameById(id));
	}

	@RequestMapping(value = "uploadPatientPhoto", method = RequestMethod.POST)
	@ResponseBody
	public ResponseBean uploadEmployeePhoto(@ModelAttribute MultipartFile file,
			@ModelAttribute("patientId") String patientId) throws IOException {
		Patient patient = patientService.findOne(patientId);
		
		if (patient.getPatientPhotoStoragePath() != null) {
			File oldPhoto = new File(SettingsConstants.PATIENT_PHOTO_PATH + File.separator + patientId,	patient.getPatientPhotoStoragePath());
			if (oldPhoto.exists()) {
				oldPhoto.delete();
			}
		}
		String fileName = file.getOriginalFilename();
		String fileExtension = FilenameUtils.getExtension(fileName);
		File imageFile = new File(SettingsConstants.PATIENT_PHOTO_PATH + File.separator + patientId, "Photo." + fileExtension);
		if (!imageFile.exists()) {
			imageFile.getParentFile().mkdirs();
		}
		if (!imageFile.canWrite()) {
			imageFile.setWritable(true);
		}
		try {
			file.transferTo(imageFile);
			patientService.updatePhoto(fileName, imageFile.getName(), patientId);
		} catch (Exception e) {
			return ResponseGenerator.generateResponse(StatusConstants.error,
					"Error occured while uploading the photo.");
		}
		return ResponseGenerator.generateResponse(StatusConstants.success,
				"Photo Uploaded Successfully.");
	}

	@RequestMapping(value = "getPhoto/{pId}")
	public Object getPhoto(@PathVariable("pId") String patientId)	throws Exception {
		Patient patient= patientService.findOne(patientId);
		File imageFile = null;
		if(StringUtils.hasText(patient.getPatientPhotoStoragePath())){
			imageFile = new File(SettingsConstants.PATIENT_PHOTO_PATH
					+ File.separator + patientId, patient.getPatientPhotoStoragePath());
		}		
		if (imageFile == null || !imageFile.exists() ) {
			if(patient.getGender().equalsIgnoreCase("Female")){
				imageFile = new File(SettingsConstants.defaultPatientFemalePhotoPath);
			}else{
				imageFile = new File(SettingsConstants.defaultPatientMalePhotoPath);
			}
			
		}
		byte[] bytes = null;
		HttpHeaders responseHeaders = new HttpHeaders();
		responseHeaders.add("Content-Disposition", "inline; filename=\""
				+ patient.getPatientPhotoName());
		responseHeaders.setContentType(MediaType.IMAGE_JPEG);
		try{
			 bytes = FileCopyUtils.copyToByteArray(imageFile);
		}catch(IOException e){
			e.printStackTrace();
		}		
		if (bytes == null) {
			return bytes;
		}
		responseHeaders.setContentLength(bytes.length);
		return new ResponseEntity<byte[]>(bytes, responseHeaders, HttpStatus.OK);
	}
	
	@RequestMapping(value = "getPatientDetail", method = RequestMethod.POST)
	@ResponseBody
	public ResponseBean getPatientDetail(@RequestBody String patientId) {
		return ResponseGenerator.generateResponse(StatusConstants.success, 
				patientService.getPatientDetail(patientId));
	}
	
}
