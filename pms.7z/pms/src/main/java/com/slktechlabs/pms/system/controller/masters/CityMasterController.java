package com.slktechlabs.pms.system.controller.masters;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("cityMaster")
public class CityMasterController {

}
