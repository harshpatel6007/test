package com.slktechlabs.pms.system.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.slktechlabs.pms.system.annotation.RequestBodyParam;
import com.slktechlabs.pms.system.constants.AppType;
import com.slktechlabs.pms.system.constants.StatusConstants;
import com.slktechlabs.pms.system.model.Response.ResponseBean;
import com.slktechlabs.pms.system.service.ClientAppVersionService;
import com.slktechlabs.pms.system.util.ResponseGenerator;

@Controller
@RequestMapping("clientAppVersion")
public class ClientAppVersionController {

	@Autowired
	ClientAppVersionService clientAppVersionService;

	@RequestMapping(value = "getVersion", method = RequestMethod.POST)
	@ResponseBody
	public ResponseBean getversion(@RequestBodyParam String appType) {
		return ResponseGenerator.generateResponse(StatusConstants.success,
				clientAppVersionService.getversion(appType));
	}

	@RequestMapping(value = "clientAppVersionForAndroid", method = RequestMethod.POST)
	@ResponseBody
	public ResponseBean changeClientAppVersionForAndroid(
			@RequestBodyParam String appType, @RequestBodyParam String version) {
		if (appType.equals(AppType.Android.name())) {

			clientAppVersionService.changeClientAppVersionForAndroid(appType,
					version);
			return ResponseGenerator.generateResponse(StatusConstants.success,
					"Version Successfully Changed.");

		}
		return ResponseGenerator.generateResponse(StatusConstants.error,
				"Application type is not compatible, It should be Android.");
	}
}
