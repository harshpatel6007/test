package com.slktechlabs.pms.system.service;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.slktechlabs.pms.system.dao.OccupationMasterDao;
import com.slktechlabs.pms.system.model.OccupationMaster;
import com.slktechlabs.pms.system.model.SearchCriteria;
@Service
public class OccupationMasterService extends HMISService<OccupationMaster, String> {

	Logger logger = Logger.getLogger(this.getClass());

	OccupationMasterDao occupationMasterDao;

	@Autowired
	public OccupationMasterService(OccupationMasterDao occupationMasterDao) {
		super(occupationMasterDao);
		this.occupationMasterDao = occupationMasterDao;
	}

	public List<OccupationMaster> search(SearchCriteria searchCriteria) {
		return occupationMasterDao.search(searchCriteria);
	}


}
