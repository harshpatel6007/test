package com.slktechlabs.pms.system.model.visit;

import java.util.Date;

import com.slktechlabs.pms.system.annotation.CustomJoin;
import com.slktechlabs.pms.system.model.User;

public class AppointmentDetail {

	private String appointmentNumber;
	private Date appointmentDate;	
	private String visitReason;
	private int duration;
	private String appointmentNotes;
	
	private Boolean repeatApplointment;
	private AppointmentRepeatType applointmentRepeatType;
	private int dayOfWeek;//1 for sunday
	private AppointmentLimitType applointmentLimitType;
	private Date repeatUptoDate;
	private int repeatUptoNumber;
	
	public String getAppointmentNumber() {
		return appointmentNumber;
	}
	public void setAppointmentNumber(String appointmentNumber) {
		this.appointmentNumber = appointmentNumber;
	}
	public Date getAppointmentDate() {
		return appointmentDate;
	}
	public void setAppointmentDate(Date appointmentDate) {
		this.appointmentDate = appointmentDate;
	}
	public String getVisitReason() {
		return visitReason;
	}
	public void setVisitReason(String visitReason) {
		this.visitReason = visitReason;
	}
	public int getDuration() {
		return duration;
	}
	public void setDuration(int duration) {
		this.duration = duration;
	}
	public String getAppointmentNotes() {
		return appointmentNotes;
	}
	public void setAppointmentNotes(String appointmentNotes) {
		this.appointmentNotes = appointmentNotes;
	}
	public Boolean getRepeatApplointment() {
		return repeatApplointment;
	}
	public void setRepeatApplointment(Boolean repeatApplointment) {
		this.repeatApplointment = repeatApplointment;
	}
	public AppointmentRepeatType getApplointmentRepeatType() {
		return applointmentRepeatType;
	}
	public void setApplointmentRepeatType(
			AppointmentRepeatType applointmentRepeatType) {
		this.applointmentRepeatType = applointmentRepeatType;
	}
	public int getDayOfWeek() {
		return dayOfWeek;
	}
	public void setDayOfWeek(int dayOfWeek) {
		this.dayOfWeek = dayOfWeek;
	}
	public AppointmentLimitType getApplointmentLimitType() {
		return applointmentLimitType;
	}
	public void setApplointmentLimitType(AppointmentLimitType applointmentLimitType) {
		this.applointmentLimitType = applointmentLimitType;
	}
	public Date getRepeatUptoDate() {
		return repeatUptoDate;
	}
	public void setRepeatUptoDate(Date repeatUptoDate) {
		this.repeatUptoDate = repeatUptoDate;
	}
	public int getRepeatUptoNumber() {
		return repeatUptoNumber;
	}
	public void setRepeatUptoNumber(int repeatUptoNumber) {
		this.repeatUptoNumber = repeatUptoNumber;
	}
	
	@Override
	public String toString() {
		return "AppointmentDetail [appointmentNumber=" + appointmentNumber
				+ ", appointmentDate=" + appointmentDate + ", visitReason="
				+ visitReason + ", duration=" + duration
				+ ", appointmentNotes=" + appointmentNotes
				+ ", repeatApplointment=" + repeatApplointment
				+ ", applointmentRepeatType=" + applointmentRepeatType
				+ ", dayOfWeek=" + dayOfWeek + ", applointmentLimitType="
				+ applointmentLimitType + ", repeatUptoDate=" + repeatUptoDate
				+ ", repeatUptoNumber=" + repeatUptoNumber + "]";
	}
}
