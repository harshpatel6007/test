package com.slktechlabs.pms.system.model;

import java.util.Date;
import java.util.Map;

import org.springframework.data.mongodb.core.index.CompoundIndex;
import org.springframework.data.mongodb.core.index.CompoundIndexes;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

import com.slktechlabs.pms.system.annotation.CustomJoin;
import com.slktechlabs.pms.system.constants.RoleAccessEnum;
import com.slktechlabs.pms.system.model.role.Role;

@Document(collection = "userCollection")
@CompoundIndexes(value = { @CompoundIndex(useGeneratedName = true, def = "{'userId':1,'password':1}", background = true) })
public class User extends AbstractDocument {

	private String displayName;
	@Indexed(useGeneratedName = true, background = true)
	private String userId;// email
	private String password;
	@Indexed(useGeneratedName = true, background = true)
	private String roleId;// fk of Role
	private Role role;
	private Map<RoleAccessEnum, Boolean> customRole;
	private Boolean status;
	private Date createdDate;
	private String email;
	private String phoneno;
	private String newPassword;
	private String userType;
	@CustomJoin(joinId = "userType", value = { "name" }, isInclude = true)
	private UserTypeMaster userTypeMaster ;
	private String code;
	
	

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getDisplayName() {
		return displayName;
	}

	public void setDisplayName(String displayName) {
		this.displayName = displayName;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getRoleId() {
		return roleId;
	}

	public void setRoleId(String roleId) {
		this.roleId = roleId;
	}

	public Role getRole() {
		return role;
	}

	public void setRole(Role role) {
		this.role = role;
	}

	public Map<RoleAccessEnum, Boolean> getCustomRole() {
		return customRole;
	}

	public void setCustomRole(Map<RoleAccessEnum, Boolean> customRole) {
		this.customRole = customRole;
	}

	public Boolean getStatus() {
		return status;
	}

	public void setStatus(Boolean status) {
		this.status = status;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPhoneno() {
		return phoneno;
	}

	public void setPhoneno(String phoneno) {
		this.phoneno = phoneno;
	}

	public String getNewPassword() {
		return newPassword;
	}

	public void setNewPassword(String newPassword) {
		this.newPassword = newPassword;
	}

	public String getUserType() {
		return userType;
	}

	public void setUserType(String userType) {
		this.userType = userType;
	}

	public UserTypeMaster getUserTypeMaster() {
		return userTypeMaster;
	}

	public void setUserTypeMaster(UserTypeMaster userTypeMaster) {
		this.userTypeMaster = userTypeMaster;
	}

	@Override
	public String toString() {
		return "User [displayName=" + displayName + ", userId=" + userId
				+ ", password=" + password + ", roleId=" + roleId + ", role="
				+ role + ", customRole=" + customRole + ", status=" + status
				+ ", createdDate=" + createdDate + ", email=" + email
				+ ", phoneno=" + phoneno + ", newPassword=" + newPassword
				+ ", userType=" + userType + ", userTypeMaster="
				+ userTypeMaster + ", code=" + code + "]";
	}

}
