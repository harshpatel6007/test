package com.slktechlabs.pms.system.controller.masters;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.slktechlabs.pms.system.annotation.RequestBodyParam;
import com.slktechlabs.pms.system.constants.MessageConstants.UserMessagesEnum;
import com.slktechlabs.pms.system.constants.StatusConstants;
import com.slktechlabs.pms.system.model.DrugAllergyMaster;
import com.slktechlabs.pms.system.model.SearchCriteria;
import com.slktechlabs.pms.system.model.Response.ResponseBean;
import com.slktechlabs.pms.system.service.DrugAllergyMasterService;
import com.slktechlabs.pms.system.util.ResponseGenerator;

@Controller
@RequestMapping("drugAllergy")
public class DrugAllergyMasterController {
	
	Logger logger = Logger.getLogger(this.getClass());
	
	@Autowired
	DrugAllergyMasterService drugAllergyMasterService;
	
	@RequestMapping(value = "add", method = RequestMethod.POST)
	@ResponseBody
	public ResponseBean createUser(@RequestBody DrugAllergyMaster drugAllergyMaster) {
		Boolean exist = drugAllergyMasterService.uniqueCheck("name", drugAllergyMaster.getName(), drugAllergyMaster.getId());
		if(exist){
			return ResponseGenerator.generateResponse(StatusConstants.error, UserMessagesEnum.UNIQUE.message("name"));
		}
		drugAllergyMasterService.save(drugAllergyMaster, "Drug Allergy Added");
			return ResponseGenerator.generateResponse(StatusConstants.success,
					UserMessagesEnum.ADD_SUCCESS.message("Drug Allergy Master"));
		}
	
	@RequestMapping(value ="update", method= RequestMethod.POST)
	@ResponseBody
	public ResponseBean update(@RequestBody DrugAllergyMaster drugAllergyMaster) {
		Boolean exist = drugAllergyMasterService.uniqueCheck("name", drugAllergyMaster.getName(), drugAllergyMaster.getId());
		if(exist){
			return ResponseGenerator.generateResponse(StatusConstants.error, UserMessagesEnum.UNIQUE.message("name"));
		}
		drugAllergyMasterService.update(drugAllergyMaster, "Drug Allergy Master Update");
		return ResponseGenerator.generateResponse(StatusConstants.success,
				UserMessagesEnum.UPDATE_SUCCESS.message("Drug Allergy master"), drugAllergyMaster);
	}
	@RequestMapping(value ="search", method= RequestMethod.POST)
	@ResponseBody
	public ResponseBean search(@RequestBody SearchCriteria searchCriteria) {
		return ResponseGenerator.generateResponse(StatusConstants.success,
				drugAllergyMasterService.search(searchCriteria));
	}
	
	@RequestMapping(value ="delete", method= RequestMethod.POST)
	@ResponseBody
	public ResponseBean delete(@RequestBodyParam String id) {
		drugAllergyMasterService.delete(id);
		return ResponseGenerator.generateResponse(StatusConstants.success,
				UserMessagesEnum.DELETE_SUCCESS.message("Drug Allergy Master"));
	}
	
	@RequestMapping(value ="get", method= RequestMethod.POST)
	@ResponseBody
	public ResponseBean get(@RequestBodyParam String id) {
		return ResponseGenerator.generateResponse(StatusConstants.success,
				drugAllergyMasterService.findOne(id));
	}
	
	@RequestMapping(value ="getAllName", method= RequestMethod.POST)
	@ResponseBody
	public ResponseBean getAllName() {
		return ResponseGenerator.generateResponse(StatusConstants.success,
				drugAllergyMasterService.getAllName());
	}
	
}
