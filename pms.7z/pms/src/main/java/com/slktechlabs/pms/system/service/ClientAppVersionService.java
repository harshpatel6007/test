package com.slktechlabs.pms.system.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.slktechlabs.pms.system.constants.AppType;
import com.slktechlabs.pms.system.dao.ClientAppVersionDao;
import com.slktechlabs.pms.system.model.ClientAppVersion;

@Service
public class ClientAppVersionService extends
		HMISService<ClientAppVersion, String> {

	ClientAppVersionDao clientAppVersionDao;

	@Autowired
	public ClientAppVersionService(ClientAppVersionDao clientAppVersionDao) {
		super(clientAppVersionDao);
		this.clientAppVersionDao = clientAppVersionDao;
	}

	public boolean checkVersion(String version) {
		return clientAppVersionDao.checkVersion(version);
	}

	public ClientAppVersion getVersion(String version, AppType appType) {
		return clientAppVersionDao.getVersion(version, appType);
	}

	public ClientAppVersion getVersion() {
		return clientAppVersionDao.getVersion();
	}

	public String getVersions() {
		List<ClientAppVersion> clientAppVersions = findAll();
		String temp = "";
		for (ClientAppVersion clientAppVersion : clientAppVersions) {
			temp += clientAppVersion.getAppType().name() + " - "
					+ clientAppVersion.getVersion() + ", ";
		}
		String result = temp.substring(0, temp.length() - 2);
		return result;
	}

	public void changeClientAppVersionForAndroid(String appType, String version) {
		clientAppVersionDao.changeClientAppVersionForAndroid(appType, version);
	}

	public ClientAppVersion getversion(String appType) {
		return clientAppVersionDao.getversion(appType);
	}
}
