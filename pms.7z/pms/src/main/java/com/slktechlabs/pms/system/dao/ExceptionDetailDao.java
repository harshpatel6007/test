package com.slktechlabs.pms.system.dao;

import java.util.Date;
import java.util.List;

import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Repository;

import com.slktechlabs.pms.system.model.ExceptionDetail;
import com.slktechlabs.pms.system.model.SearchCriteria;
import com.slktechlabs.pms.system.util.SearchUtils;

@Repository
public class ExceptionDetailDao extends HMISDao<ExceptionDetail, String>{

	public List<ExceptionDetail> search(SearchCriteria searchCriteria, Date from, Date to) {
		Query query = new Query();
		if(searchCriteria != null){
			query.addCriteria(Criteria.where(searchCriteria.getKey()).regex("^" + 
					SearchUtils.getRegexCompatibleString(searchCriteria.getValue()) + ".*", "i"));
		}
		
		if(to != null && from != null){
			query.addCriteria(Criteria.where("date").lte(to).gte(from));
		}else if(to == null && from != null){
			query.addCriteria(Criteria.where("date").gte(from));
		}else if(to != null && from == null){
			query.addCriteria(Criteria.where("date").lte(to));
		}
		query.with(new Sort(Direction.DESC , "date"));
		return find(query);
	}
	public List<ExceptionDetail> searchToday(SearchCriteria searchCriteria) {
		Query query = new Query();
		query.with(new Sort(Direction.DESC , "date"));
		return find(query);
	}
	public void updateUserMessage(String id, String userMessage) {
		Query query = new Query();
		query.addCriteria(Criteria.where("id").is(id));
		Update update = new Update();
		update.set("userMessage", userMessage);
		update(query, update, "Update User Message");
	}

	
}
