package com.slktechlabs.pms.system.controller.web;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.slktechlabs.pms.system.constants.RoleAccessEnum;
import com.slktechlabs.pms.system.constants.RoleGroupEnum;
import com.slktechlabs.pms.system.util.JSONUtils;

@Controller
@RequestMapping("roleWebController")
public class RoleWebController {
	
	private final String PAGE_PREFIX = "pms/role/";

	@RequestMapping("manage")
	public String manage(ModelMap modelMap) throws JsonGenerationException, JsonMappingException, IOException{
		Map<RoleGroupEnum, List<RoleAccessEnum>>  roleGroupMap = new HashMap<>();
		for(RoleGroupEnum roleGroupEnum : RoleGroupEnum.values()){
			List<RoleAccessEnum> enums = new ArrayList<>();
			for(RoleAccessEnum roleAccessEnum :  roleGroupEnum.getAccesses()){
				enums.add(roleAccessEnum);
			}
			roleGroupMap.put(roleGroupEnum, enums);
		}
		modelMap.put("RoleGroupEnum", JSONUtils.jsonFromObject(roleGroupMap));
		return PAGE_PREFIX + "roleManage";
	}
	
	@RequestMapping("view")
	public String view(){
		return PAGE_PREFIX + "roleView";
	}
	
	@RequestMapping("viewPopUp")
	public String viewPopUp(){
		return PAGE_PREFIX + "roleViewPopup";
	}
}
