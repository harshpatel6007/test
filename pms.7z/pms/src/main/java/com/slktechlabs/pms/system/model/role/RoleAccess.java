package com.slktechlabs.pms.system.model.role;

import com.slktechlabs.pms.system.constants.MasterStatus;

public class RoleAccess {
	private String key;
	private String name;
	private String description;
	private MasterStatus status;

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getKey() {
		return key;
	}

	public void setKey(String key) {
		this.key = key;
	}

	public MasterStatus getStatus() {
		return status;
	}

	public void setStatus(MasterStatus status) {
		this.status = status;
	}

	@Override
	public String toString() {
		return "RoleAccess [key=" + key + ", name=" + name + ", description="
				+ description + ", status=" + status + "]";
	}
}
