package com.slktechlabs.pms.system.controller.web;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

import com.slktechlabs.pms.system.service.ConcessionMasterService;
import com.slktechlabs.pms.system.service.OccupationMasterService;
import com.slktechlabs.pms.system.service.PatientTypeMasterService;
import com.slktechlabs.pms.system.service.RefferMasterService;
import com.slktechlabs.pms.system.service.masters.CountryMasterService;
import com.slktechlabs.pms.system.service.masters.DocumentTypeMasterService;
import com.slktechlabs.pms.system.service.masters.RelationMasterService;
import com.slktechlabs.pms.system.service.masters.ReligionMasterService;
import com.slktechlabs.pms.system.service.masters.StateMasterService;
import com.sun.media.jfxmedia.logging.Logger;

@Controller
@RequestMapping("patientWebController")
public class PatientWebController {
	
	@Autowired
	RefferMasterService refferMasterService;
	
	@Autowired
	ConcessionMasterService concessionTypeMasterService;
	
	@Autowired
	PatientTypeMasterService patientTypeMasterService;
	
	@Autowired
	ReligionMasterService religionMasterService;
	
	@Autowired
	OccupationMasterService occupationMasterService;
	
	@Autowired
	RelationMasterService relationMasterService;
	
	@Autowired
	StateMasterService stateMasterService;
	
	@Autowired
	CountryMasterService countryMasterService;
	
	@Autowired
	DocumentTypeMasterService documentTypeMasterService;
	
	@RequestMapping("addPatient")
	public String addPatient(ModelMap modelMap){
		System.out.println("in add patient poage");
		modelMap.addAttribute("refferMasterList", refferMasterService.findAll_E());
		modelMap.addAttribute("concessionTypeMasterList", concessionTypeMasterService.findAll_E());
		modelMap.addAttribute("patientTypeMasterList", patientTypeMasterService.findAll_E());
		modelMap.addAttribute("religionMasterList", religionMasterService.findAll_E());
		modelMap.addAttribute("occupationMasterList", occupationMasterService.findAll_E());
		modelMap.addAttribute("relationMasterList", relationMasterService.findAll_E());
		modelMap.addAttribute("stateMasterList", stateMasterService.findAll_E());
		modelMap.addAttribute("countryMasterList", countryMasterService.findAll_E());
		return "pms/patient/addPatient";
	}
	
	@RequestMapping("searchPatient")
	public String searchPatient(){
		return "pms/patient/searchPatient";
	}
	
	@RequestMapping("uploadDocument")
	public String uploadDocument(ModelMap modelMap){
		modelMap.addAttribute("documentTypeMasterList", documentTypeMasterService.findAll_E());
		return "pms/patient/uploadDocument";
	}
	
	@RequestMapping("uploadDocumentSubType")
	public String uploadDocumentSubType(ModelMap modelMap){
		modelMap.addAttribute("documentTypeMasterList", documentTypeMasterService.findAll_E());
		return "pms/patient/uploadDocument";
	}
}
