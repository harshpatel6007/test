package com.slktechlabs.pms.system.dao.masters;

import java.util.List;

import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Repository;

import com.slktechlabs.pms.system.dao.HMISDao;
import com.slktechlabs.pms.system.model.SearchCriteria;
import com.slktechlabs.pms.system.model.master.DocumentTypeMaster;
import com.slktechlabs.pms.system.util.SearchUtils;

@Repository
public class DocumentTypeMasterDao extends HMISDao<DocumentTypeMaster, String>{

	public List<DocumentTypeMaster> search(SearchCriteria searchCriteria) {
		Query query = new Query();
    	if (searchCriteria != null) {
    		query.addCriteria(Criteria.where(searchCriteria.getKey())
        		.regex(SearchUtils.getRegexPatternForSearchAtStart(searchCriteria.getValue()), "i"));
    	}
    	query.with(new Sort(Direction.DESC, "modified"));        
    	return findAll(query);
	}

}
