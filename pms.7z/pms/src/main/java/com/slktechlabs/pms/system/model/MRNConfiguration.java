package com.slktechlabs.pms.system.model;

import java.util.Date;

import com.slktechlabs.pms.system.constants.MRNResetPolicy;

public class MRNConfiguration {
	private String pattern;
	private Integer numberSize;
	private MRNResetPolicy mrnResetPolicy;
	private Integer mrnResetMonth;
	private Date lastResetDate;
	private Boolean changeSequenceNumber;
	private Long currentSequenceNumber;
	private Long oldSequenceNumber;

	public String getPattern() {
		return pattern;
	}

	public void setPattern(String pattern) {
		this.pattern = pattern;
	}

	public Integer getNumberSize() {
		return numberSize;
	}

	public void setNumberSize(Integer numberSize) {
		this.numberSize = numberSize;
	}

	public MRNResetPolicy getMrnResetPolicy() {
		return mrnResetPolicy;
	}

	public void setMrnResetPolicy(MRNResetPolicy mrnResetPolicy) {
		this.mrnResetPolicy = mrnResetPolicy;
	}

	public Integer getMrnResetMonth() {
		return mrnResetMonth;
	}

	public void setMrnResetMonth(Integer mrnResetMonth) {
		this.mrnResetMonth = mrnResetMonth;
	}

	public Date getLastResetDate() {
		return lastResetDate;
	}

	public void setLastResetDate(Date lastResetDate) {
		this.lastResetDate = lastResetDate;
	}

	public Boolean getChangeSequenceNumber() {
		return changeSequenceNumber;
	}

	public void setChangeSequenceNumber(Boolean changeSequenceNumber) {
		this.changeSequenceNumber = changeSequenceNumber;
	}

	public Long getCurrentSequenceNumber() {
		return currentSequenceNumber;
	}

	public void setCurrentSequenceNumber(Long currentSequenceNumber) {
		this.currentSequenceNumber = currentSequenceNumber;
	}

	public Long getOldSequenceNumber() {
		return oldSequenceNumber;
	}

	public void setOldSequenceNumber(Long oldSequenceNumber) {
		this.oldSequenceNumber = oldSequenceNumber;
	}

	@Override
	public String toString() {
		return "MRNConfiguration [pattern=" + pattern + ", numberSize="
				+ numberSize + ", mrnResetPolicy=" + mrnResetPolicy
				+ ", mrnResetMonth=" + mrnResetMonth + ", lastResetDate="
				+ lastResetDate + ", changeSequenceNumber="
				+ changeSequenceNumber + ", currentSequenceNumber="
				+ currentSequenceNumber + ", oldSequenceNumber="
				+ oldSequenceNumber + "]";
	}

}
