package com.slktechlabs.pms.system.service.masters;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.slktechlabs.pms.system.dao.masters.CountryMasterDao;
import com.slktechlabs.pms.system.model.SearchCriteria;
import com.slktechlabs.pms.system.model.master.CountryMaster;
import com.slktechlabs.pms.system.service.HMISService;

@Service
public class CountryMasterService extends HMISService<CountryMaster, String>{
	
	CountryMasterDao countryMasterDao;
	
	@Autowired
	StateMasterService stateMasterService;
	
	@Autowired
	public CountryMasterService(CountryMasterDao countryMasterDao) {
		super(countryMasterDao);
		
		this.countryMasterDao = countryMasterDao;
	}

	public List<CountryMaster> search(SearchCriteria searchCriteria) {
		return countryMasterDao.search(searchCriteria);
	}

	public String checkReferenceExist(String countryId) {
		
		if(stateMasterService.checkCountryMasterExist(countryId)){
			return "State Master";
		}
		
		return null;
	}

	public List<CountryMaster> getCountryList() {
		return countryMasterDao.getCountryList();
	}

}
