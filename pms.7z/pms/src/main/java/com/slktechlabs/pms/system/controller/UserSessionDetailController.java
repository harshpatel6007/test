package com.slktechlabs.pms.system.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("userSession")
public class UserSessionDetailController {

	
	//search request not implemented for web so remove existing methods which are used for desktop app
}
