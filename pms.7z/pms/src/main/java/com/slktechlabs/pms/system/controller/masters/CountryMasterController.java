package com.slktechlabs.pms.system.controller.masters;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.slktechlabs.pms.system.annotation.RequestBodyParam;
import com.slktechlabs.pms.system.constants.StatusConstants;
import com.slktechlabs.pms.system.constants.MessageConstants.UserMessagesEnum;
import com.slktechlabs.pms.system.model.SearchCriteria;
import com.slktechlabs.pms.system.model.Response.ResponseBean;
import com.slktechlabs.pms.system.model.master.CountryMaster;
import com.slktechlabs.pms.system.service.masters.CountryMasterService;
import com.slktechlabs.pms.system.util.ResponseGenerator;

@Controller
@RequestMapping("countryMaster")
public class CountryMasterController {
	@Autowired
CountryMasterService countryMasterService;

	@RequestMapping(value ="add", method= RequestMethod.POST)
	@ResponseBody
	public ResponseBean add(@RequestBody CountryMaster countryMaster) {

		Boolean exist = countryMasterService.uniqueCheck("name", countryMaster.getName(), countryMaster.getId());
		if(exist){
			return ResponseGenerator.generateResponse(StatusConstants.error, UserMessagesEnum.UNIQUE.message("name"));
		}
		countryMasterService.save(countryMaster, "country Master Add");
		return ResponseGenerator.generateResponse(StatusConstants.success,
				UserMessagesEnum.ADD_SUCCESS.message("country Master"), countryMaster);
	}
	
	@RequestMapping(value ="update", method= RequestMethod.POST)
	@ResponseBody
	public ResponseBean update(@RequestBody CountryMaster countryMaster) {
		Boolean exist = countryMasterService.uniqueCheck("name", countryMaster.getName(), countryMaster.getId());
		if(exist){
			return ResponseGenerator.generateResponse(StatusConstants.error, UserMessagesEnum.UNIQUE.message("name"));
		}
		countryMasterService.update(countryMaster, "country Master Update");
		return ResponseGenerator.generateResponse(StatusConstants.success,
				UserMessagesEnum.UPDATE_SUCCESS.message("country Master"), countryMaster);
	}
	
	@RequestMapping(value ="search", method= RequestMethod.POST)
	@ResponseBody
	public ResponseBean search(@RequestBody SearchCriteria searchCriteria) {
		return ResponseGenerator.generateResponse(StatusConstants.success,
				countryMasterService.search(searchCriteria));
	}
	
	@RequestMapping(value ="delete", method= RequestMethod.POST)
	@ResponseBody
	public ResponseBean delete(@RequestBodyParam String id) {
		String reference = countryMasterService.checkReferenceExist(id);
		if(reference != null){
			return ResponseGenerator.generateResponse(StatusConstants.error, UserMessagesEnum.REFRENCE_EXIST.message(reference));
		}
		countryMasterService.delete(id);
		return ResponseGenerator.generateResponse(StatusConstants.success,
				UserMessagesEnum.DELETE_SUCCESS.message("country Master"));
	}
	
	@RequestMapping(value ="get", method= RequestMethod.POST)
	@ResponseBody
	public ResponseBean get(@RequestBodyParam String id) {
		return ResponseGenerator.generateResponse(StatusConstants.success,
				countryMasterService.findOne(id));
	}
	
	@RequestMapping(value ="getCountryList", method= RequestMethod.POST)
	@ResponseBody
	public ResponseBean getCountryList() {
		return ResponseGenerator.generateResponse(StatusConstants.success,
				countryMasterService.getCountryList());
	}

}
