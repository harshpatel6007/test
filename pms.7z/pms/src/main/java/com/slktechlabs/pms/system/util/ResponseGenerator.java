package com.slktechlabs.pms.system.util;

import com.slktechlabs.pms.system.constants.StatusConstants;
import com.slktechlabs.pms.system.model.Response.ResponseBean;


/**
 * Generate different type of response according to request
 */
public class ResponseGenerator {

	public static ResponseBean generateResponse(StatusConstants status, String message , Object data) {
		ResponseBean resObj = new ResponseBean();
		resObj.setType(status);
		resObj.setMessage(message);
		resObj.setData(data);
		return resObj;
	}
	
	public static ResponseBean generateResponse(StatusConstants status, String message , Object data ,  String code) {
		ResponseBean resObj = new ResponseBean();
		resObj.setType(status);
		resObj.setCode(code);
		resObj.setMessage(message);
		resObj.setData(data);
		return resObj;
	}
	
	public static ResponseBean generateResponse(StatusConstants status, String message) {
		ResponseBean resObj = new ResponseBean();
		resObj.setType(status);
		resObj.setMessage(message);
		return resObj;
	}
	
	public static ResponseBean generateResponse(StatusConstants status, Object data) {
		ResponseBean resObj = new ResponseBean();
		resObj.setType(status);
		resObj.setData(data);
		return resObj;
	}
}
