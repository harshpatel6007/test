package com.slktechlabs.pms.system.exception;

import javax.servlet.http.HttpServletRequest;

import org.apache.avalon.framework.ExceptionUtil;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessResourceFailureException;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.slktechlabs.pms.system.constants.StatusConstants;
import com.slktechlabs.pms.system.service.ExceptionDetailService;
import com.slktechlabs.pms.system.util.ResponseGenerator;

@ControllerAdvice
public class CustomExceptionHandler {

	Logger logger = Logger.getLogger(getClass());

	@Autowired
	RestResponseEntityExceptionHandler restResponseEntityExceptionHandler;
	
	@Autowired
	ExceptionDetailService exceptionDetailService;

	@ExceptionHandler(value = DataAccessResourceFailureException.class)
	private Object handleDataAccessResourceFailureException(Exception exception, HttpServletRequest request) {
		logger.error("Mongo server Not started, Please Start it", exception);
		return getResponseEntity(HttpStatus.EXPECTATION_FAILED, HttpStatus.EXPECTATION_FAILED.value(), exception, request);
	}

	@ExceptionHandler(value = Exception.class)
	public Object handleException(Exception exception, HttpServletRequest request) {
		return getResponseEntity(HttpStatus.EXPECTATION_FAILED, HttpStatus.EXPECTATION_FAILED.value(), exception, request);
	}

	public Object getResponseEntity(HttpStatus status, int exceptionCode, Exception ex, HttpServletRequest request) {
		
		RestError restError = new RestError(status, status.value(), ex.getMessage(), ExceptionUtil.printStackTrace(ex), "");

		String contentType = request.getContentType();
		System.out.println("contentType :-- " + contentType);

		if (isContentJson(contentType)) {

			if (ex instanceof AuthException) {
				return new ResponseEntity<Object>(ResponseGenerator.generateResponse(StatusConstants.error, ex.getMessage(), null, "750"),
						HttpStatus.OK);
			} else {
				logger.error(ex.getMessage(), ex);
				HttpHeaders headers = new HttpHeaders();
				headers.setContentType(MediaType.APPLICATION_JSON);
				return new ResponseEntity<Object>(restError, headers, status);
			}
		} else {

			logger.error(ex.getMessage(), ex);
			if (ex instanceof AuthException) {
				return "error/servletError";
			} else {
				logger.error(ex.getMessage(), ex);
				request.setAttribute("exception", ex.getMessage());
				request.setAttribute("exceptionStackTrace", ExceptionUtil.printStackTrace(ex));
				request.setAttribute("url", request.getRequestURL());
				String id = exceptionDetailService.addException(ex.getClass().getName(), ex.getMessage(),
						ExceptionUtil.printStackTrace(ex), request.getRequestURL().toString(), 
						request.getRemoteAddr());
				request.setAttribute("id", id);
				return "error/servletError";
			}
		}
	}
	
	private boolean isContentJson(String contentType) {
		if (contentType != null) {
			return contentType.startsWith("application/json");
		}
		return false;
	}
}
