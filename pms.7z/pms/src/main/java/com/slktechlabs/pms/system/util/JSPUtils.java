package com.slktechlabs.pms.system.util;

import javax.servlet.http.HttpServletRequest;

import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

public class JSPUtils {
	
	private static String appVersion = "";
	
	public static String getTitle(String title) {
		return "Hops Application :: " + title;
	}

	public static HttpServletRequest getRequest() {
		HttpServletRequest request = ((ServletRequestAttributes) RequestContextHolder.currentRequestAttributes()).getRequest();
		return request;
	}
	
	public static String getURLWithToken(String url) {
		return getURLWithToken(url, getRequest());
	}
	
	public static String getURLWithToken(String url, HttpServletRequest request) {
		return getURLWithToken(url, request , null);
	}
	
	public static String getURLWithToken(String url , String param) {
		return getURLWithOutToken(url, getRequest(), param);
	}
	
	public static String getURLWithToken(String url , HttpServletRequest request , String param) {
		String contextPath = request.getContextPath();
		
		String URL = contextPath + url ;
				
		if(param != null){
			URL += "?" + param ;
		}
		
		return URL;
	}

	public static String getURLWithOutToken(String url) {
		return getURLWithOutToken(url, getRequest());
	}
	
	public static String getURLWithOutToken(String url, HttpServletRequest request) {
		String contextPath = request.getContextPath();
		String URL = contextPath + url;
//		System.out.println("URL :-- " + URL);
		return URL;
	}
	
	public static String getURLWithOutToken(String url, String param) {
		return getURLWithOutToken(url, getRequest(), param);
	}
	
	public static String getURLWithOutToken(String url, HttpServletRequest request, String param) {
		
		String contextPath = request.getContextPath();
		String URL = contextPath + url ;
		if(param != null){
			URL += "?" + param ;
		}
		return URL;
	}

	public static String getParameter(String key) {
		return getParameter(key, getRequest());
	}
	
	public static String getParameter(String key, HttpServletRequest request) {
		return request.getParameter(key) == null ? "" : request.getParameter(key);
	}

	public static String getResourceURL(String url){
		return getResourceURL(url, getRequest());
	}
			
	public static String getResourceURL(String url, HttpServletRequest request) {
		String resourcePath = request.getContextPath() + "/web-resources";
		String URL = resourcePath + url;
		return URL;
	}	
}
