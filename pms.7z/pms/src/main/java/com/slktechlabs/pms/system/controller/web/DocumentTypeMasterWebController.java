package com.slktechlabs.pms.system.controller.web;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("documentTypeMasterWeb")
public class DocumentTypeMasterWebController {
	private final String PAGE_PREFIX = "pms/masters/documentTypeMaster/";
	
	@RequestMapping("view")
	public String view(){
		return PAGE_PREFIX + "documentTypeMasterView";
	}
	
	@RequestMapping("manage")
	public String manage(){
		return PAGE_PREFIX + "documentTypeMasterManage";
	}
	
}
