package com.slktechlabs.pms.system.constants;

public enum RoleAccessEnum {
	
	ROLE_VIEW( "Role View"  , "Can View Role"  ,true) ,
	ROLE_MANAGE( "Role Manage"  , "Can Manage Role"  ,true) ,
	IS_ADMIN( "Is Admin"  , "Shows Whether User is Admin or Not?"  ,true) ,
	RELIGION_MASTER_VIEW("Religion Master View", "Can View Religion Master", true),
	RELIGION_MASTER_MANAGE("Religion Master Manage", "Can Manage Religion Master", true),
	RELATION_MASTER_VIEW("Relation Master View", "Can View Relaton Master", true),
	RELATION_MASTER_MANAGE("Relation Master Manage", "Can Manage Relaton Master", true),
	COUNTRY_MASTER_VIEW("Country Master View", "Can View Country Master", true),
	COUNTRY_MASTER_MANAGE("Country Master Manage", "Can Manage Country Master", true),
	STATE_MASTER_VIEW("State Master View", "Can View State Master", true),
	STATE_MASTER_MANAGE("State Master Manage", "Can Manage State Master", true);
	
	
	
	private String name;
	private String description;
	private boolean publicRole;
	private HospitalType[] excludeHospitals;
	
	private RoleAccessEnum(String name, String desc, boolean publicRole, HospitalType...excludeList) {
		this.name = name;
		this.description = desc;
		this.publicRole = publicRole;
		this.excludeHospitals = excludeList;
	}

	public String getName() {
		return name;
	}

	public String getDescription() {
		return description;
	}

	public boolean isPublicRole() {
		return publicRole;
	}

	public HospitalType[] getExcludeHospitals() {
		return excludeHospitals;
	}


}
