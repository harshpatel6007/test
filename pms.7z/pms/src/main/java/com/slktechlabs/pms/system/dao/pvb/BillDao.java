package com.slktechlabs.pms.system.dao.pvb;

import java.util.List;

import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Repository;

import com.slktechlabs.pms.system.dao.HMISDao;
import com.slktechlabs.pms.system.model.bill.BillCollection;

@Repository
public class BillDao extends HMISDao<BillCollection, String>{

	public List<BillCollection> getBillForVisit(String visitId) {
		Query query = new Query();
		query.addCriteria(Criteria.where("visitId").is(visitId));
		return find(query);
	}

	public List<String> getBillNumberOfVisit(String visitId) {
		Query query = new Query();
		query.addCriteria(Criteria.where("visitId").is(visitId));
		return distinct("billNumber", query);
	}

	
}
