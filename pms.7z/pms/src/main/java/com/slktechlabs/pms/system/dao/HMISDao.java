package com.slktechlabs.pms.system.dao;

import static org.springframework.data.mongodb.core.query.Criteria.where;

import java.io.IOException;
import java.io.InputStream;
import java.io.Serializable;
import java.lang.reflect.Field;
import java.lang.reflect.ParameterizedType;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.annotation.PostConstruct;
import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.MongoDbFactory;
import org.springframework.data.mongodb.core.FindAndModifyOptions;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.convert.MongoConverter;
import org.springframework.data.mongodb.core.convert.QueryMapper;
import org.springframework.data.mongodb.core.mapping.MongoPersistentEntity;
import org.springframework.data.mongodb.core.mapreduce.GroupBy;
import org.springframework.data.mongodb.core.mapreduce.GroupByResults;
import org.springframework.data.mongodb.core.mapreduce.MapReduceOptions;
import org.springframework.data.mongodb.core.mapreduce.MapReduceResults;
import org.springframework.data.mongodb.core.query.BasicQuery;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.util.Assert;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.mongodb.AggregationOptions;
import com.mongodb.AggregationOutput;
import com.mongodb.BasicDBList;
import com.mongodb.BasicDBObject;
import com.mongodb.Cursor;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import com.mongodb.gridfs.GridFS;
import com.mongodb.gridfs.GridFSDBFile;
import com.mongodb.gridfs.GridFSInputFile;
import com.slktechlabs.pms.system.annotation.NoHistory;
import com.slktechlabs.pms.system.annotation.SetToNull;
import com.slktechlabs.pms.system.constants.MasterStatus;
import com.slktechlabs.pms.system.model.AbstractDocument;
import com.slktechlabs.pms.system.model.UpdateHistory;
import com.slktechlabs.pms.system.oauth2.ClientDetailsService;
import com.slktechlabs.pms.system.oauth2.UserDetail;
import com.slktechlabs.pms.system.util.JSONUtils;
import com.slktechlabs.pms.system.util.MyUtils;
import com.slktechlabs.pms.system.util.SearchUtils;

public class HMISDao<T extends AbstractDocument, ID extends Serializable>{

	@Autowired
	protected MongoTemplate mongoTemplate;

	protected String collection_name;
	
	protected Class<T> theType;

	private MongoConverter mongoConverter;
	QueryMapper queryMapper;

	@Autowired
	HttpServletRequest request;
	
	@Autowired
	MongoDbFactory mongoDbFactory;
	
	@Autowired
	ApplicationContext applicationContext;
	
	@Autowired
	ClientDetailsService inMemoryClientDetailsService;
	
	List<String> setToNullValue;
	
	private Logger logger = Logger.getLogger(getClass());

	
	@SuppressWarnings("unchecked")
	public HMISDao(){
		theType = (Class<T>) ((ParameterizedType) getClass()
				.getGenericSuperclass()).getActualTypeArguments()[0];
//		logger.info(" Type --->> " + theType);
		
		setToNullValue = new ArrayList<String>();
	}

	private static boolean waitForConnection = true;
	
	@PostConstruct
	public void PostConstruct(){
		
		try {
			waitForConnection();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		
		collection_name = mongoTemplate.getCollectionName(theType);
		mongoConverter = mongoTemplate.getConverter();
		queryMapper = new QueryMapper(this.mongoConverter);
		
//		logger.info("mongo-->"+ mongo);
		
		//find @SetToNull and put this key in list
		
		Field[] field  = theType.getDeclaredFields();
		
		for (int i = 0; i < field.length; i++) {
			Field field2 = field[i];
			
			if(field2.isAnnotationPresent(SetToNull.class)){
				setToNullValue.add(field2.getName());
			}
		}
		
//		if(!setToNullValue.isEmpty()){
//			logger.info("--------------setToNullValue---->> "+ theType + " --->> "+ setToNullValue);
//		}
	}
	
	
	private void checkConnection(){
		logger.info("---------------------Check Connection------------------------");
		mongoTemplate.getCollectionNames();
	}

	private void waitForConnection() throws InterruptedException {
		try {
			if(waitForConnection){
				this.checkConnection();
			}
		} catch (Exception e) {
			try {
				logger.info("-->>" + e.getMessage());
				Thread.sleep(10000);
			} catch (InterruptedException e1) {
				throw e1;
			}
			this.waitForConnection();
		}
		waitForConnection = false;
	}
	
	
	/**
	 * Saves all given entities.
	 * 
	 * @param entities
	 * @return the saved entities
	 * @throws IllegalArgumentException
	 *             in case the given entity is (@literal null}.
	 */
	
	public Query getIdQuery(Object id) {
		return new Query(getIdCriteria(id));
	}

	public Criteria getIdCriteria(Object id) {
		return Criteria.where("_id").is(id);
	}

	/**
	 * Retrives an entity by its id.
	 * 
	 * @param id
	 *            must not be {@literal null}.
	 * @return the entity with the given id or {@literal null} if none found
	 * @throws IllegalArgumentException
	 *             if {@code id} is {@literal null}
	 */
	public T findOne(ID id) {
		Assert.notNull(id, "The given id must not be null!");

		return findOne(getIdQuery(id));
	}
	
	public T findOneWithoutHistory(ID id) {
		Assert.notNull(id, "The given id must not be null!");
		Query query = getIdQuery(id);
		query.fields().exclude("history");
		return findOne(query);
	}

	public T findOne(Query query) {
		Assert.notNull(query, "The given query must not be null!");
		checkAndExcludeHistoryKey(query);
		return mongoTemplate.findOne(query, theType);
	}

	public List<T> find(Query query){
		checkAndExcludeHistoryKey(query);
		return mongoTemplate.find(query, theType);
	}
	
	void checkAndExcludeHistoryKey(Query query){
		if(query != null && query.fields().getFieldsObject().keySet().size() == 0){
			query.fields().exclude("history");
		}
	}
	
	/**
	 * Returns whether an entity with the given id exists.
	 * 
	 * @param id
	 *            must not be {@literal null}.
	 * @return true if an entity with the given id exists, {@literal false}
	 *         otherwise
	 * @throws IllegalArgumentException
	 *             if {@code id} is {@literal null}
	 */
	public boolean exists(ID id) {

		Assert.notNull(id, "The given id must not be null!");
		return mongoTemplate.findOne(getIdQuery(id), theType) != null;
	}

	/**
	 * Returns the number of entities available.
	 * 
	 * @return the number of entities
	 */
	public long count() {
		return mongoTemplate.count(new Query(), theType);
	}
	
	/**
	 * Returns the number of entities available.
	 * 
	 * @return the number of entities
	 */
	public long count(Query query) {
		return mongoTemplate.count(query, theType);
	}

	/**
	 * Returns all instances of the type.
	 * 
	 * @return all entities
	 */
	public List<T> findAllWithoutHistory() {
		Query query = new Query();
		checkAndExcludeHistoryKey(query);
		return findAll(query);
	}

	
	/**
	 * Returns all instances of the type.
	 * 
	 * @return all entities
	 */
	public List<T> findAll() {
		return findAll(new Query());
	}

	/**
	 * Returns all instances of the type with the given IDs.
	 * 
	 * @param ids
	 * @return
	 */
	public Iterable<T> findAll(Iterable<ID> ids) {

		Set<ID> parameters = new HashSet<ID>();
		for (ID id : ids) {
			parameters.add(id);
		}
		return findAll(new Query(Criteria.where("_id").in(parameters)));
	}

	/**
	 * Returns a {@link Page} of entities meeting the paging restriction
	 * provided in the {@code Pageable} object.
	 * 
	 * @param pageable
	 * @return a page of entities
	 */
	public Page<T> findAll(final Pageable pageable) {

		Long count = count();
		List<T> list = findAll(new Query().with(pageable));

		return new PageImpl<T>(list, pageable, count);
	}

	/**
	 * Returns all entities sorted by the given options.
	 * 
	 * @param sort
	 * @return all entities sorted by the given options
	 */
	public List<T> findAll(Sort sort) {
		return findAll(new Query().with(sort));
	}

	/**
	 * Returns all entities sorted by the given Query.
	 * 
	 * @param query
	 * @return all entities sorted by the given options
	 * @throws Exception 
	 */
	public List<T> findAll(Query query) {

		if (query == null) {
			return Collections.emptyList();
		}
		checkAndExcludeHistoryKey(query);
		return mongoTemplate.find(query, theType);
	}

	/**
	 * Returns all entities sorted by the given entity.
	 * 
	 * @param entity
	 * @return all entities sorted by the given options
	 */
	public List<T> findAll(T entity, Sort... sorts) {

		String jsonStr = objToJsonStr(entity);
		Assert.notNull(jsonStr, "The given entity must not be null!");

		return findAll(jsonStr, sorts);
	}
	
	public List<T> findAll(T entity, Query query) {

		String jsonStr = objToJsonStr(entity);
		Assert.notNull(jsonStr, "The given entity must not be null!");

		BasicQuery searchUserQuery;
		if(query.getFieldsObject() == null)
		{
			searchUserQuery = new BasicQuery(jsonStr);
		}else{
			searchUserQuery = new BasicQuery(jsonStr , query.getFieldsObject().toString());
		}
		
		searchUserQuery.setSortObject(query.getSortObject());
		
		return findAll(searchUserQuery);
	}
	
	/**
	 * Returns all entities sorted by the given json String.
	 * 
	 * @param jsonStr
	 * @return all entities sorted by the given options
	 */
	public List<T> findAll(String jsonStr, Sort... sorts) {

		Assert.notNull(jsonStr, "The given Jsonstring must not be null!");
		Query searchUserQuery = new BasicQuery(jsonStr);
		logger.info("searchUserQuery:-- " + searchUserQuery.getQueryObject());
		if (sorts.length == 1) {
			searchUserQuery.with(sorts[0]);
		}
		checkAndExcludeHistoryKey(searchUserQuery);

		return (mongoTemplate.find(searchUserQuery, theType));
	}

	
	public List distinct(String field, Query query){ 
		
		Assert.notNull(field, "The given field must not be null!");
		Assert.notNull(query, "The given query must not be null!");
		
		List list = mongoTemplate.getCollection(collection_name).distinct(field, query.getQueryObject());
		
		return list;
	}
	
	
	public String objToJsonStr(T t) {

		String value = null;
		try {
			value = JSONUtils.jsonFromObject(t);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return value;
	}

	
	/**
	 * Groups according to the key given in GroupBy
	 * 
	 * @param groupBy
	 * @param entity
	 * @return
	 * @throws IOException 
	 * @throws JsonMappingException 
	 * @throws JsonParseException 
	 */
	public <S> List<S> groupByResults(Criteria criteria,GroupBy groupBy,Class<S> entity) 
	{		
		List<S> list2 = new ArrayList<S>();
		GroupByResults<S> results = mongoTemplate.group(criteria,collection_name, groupBy, entity);
		BasicDBList list = (BasicDBList) results.getRawResults().get("retval");
		for(int i =0; i< list.size();i++){			
			BasicDBObject dbObject = (BasicDBObject) list.get(i);
			S object = mongoConverter.read(entity, dbObject);
			list2.add(object);
		}
		return list2;
	}

	public MapReduceResults<BasicDBObject> mapReduceQuery(Query query, String inputCollection, String map,
			String reduce, MapReduceOptions mapReduceOptions, Class<BasicDBObject> class1) {
		return mongoTemplate.mapReduce(query, inputCollection, map, reduce, mapReduceOptions, class1);
	}
	public BasicDBList groupBy(Criteria criteria, GroupBy groupBy) {
		GroupByResults<BasicDBList> result = mongoTemplate.group(criteria, collection_name, groupBy, BasicDBList.class);
		return (BasicDBList) result.getRawResults().get("retval");
	}
	
	public <S extends T> S save(S entity , String action) {
		Assert.notNull(entity, "Entity must not be null!");
		updateHistory(entity , action);
		mongoTemplate.save(entity);
		return entity;
	}

	public boolean uniqueCheck(String key, String valueofKey, String id) {
		Query query = new Query();
		String value = SearchUtils.getRegexCompatibleString(valueofKey);
		query.addCriteria(Criteria.where(key).regex("^"+value+"$", "i"));
		if (id != null) {
			query.addCriteria(where("_id").ne(id));
		}
		return (count(query) > 0);
	}
	
	public void update(T entity , String action) {

		Assert.notNull(entity, "Entity must not be null!");
		Assert.notNull(entity.getId(), "Entity ID must not be null!");

		@SuppressWarnings("unchecked")
		ID id = (ID) entity.getId();

		Update update = updateObj(entity);
		
		Query query = new Query(Criteria.where("_id").is(id));

		update(query, update , action);
	}
	
	public void upsert(T entity ,  String action) {

		Assert.notNull(entity, "Entity must not be null!");
		Assert.notNull(entity.getId(), "Entity ID must not be null!");
		
		@SuppressWarnings("unchecked")
		ID id = (ID) entity.getId();

		Update update = updateObj(entity);
		
		Query query = new Query(Criteria.where("_id").is(id));
		upsert(query, update , action);
	}
	
	public void upsertWithNull(T entity ,  String action) {

		Assert.notNull(entity, "Entity must not be null!");
		Assert.notNull(entity.getId(), "Entity ID must not be null!");
		
		@SuppressWarnings("unchecked")
		ID id = (ID) entity.getId();

		Update update =  updateObjWithNull(entity);
		
		Query query = new Query(Criteria.where("_id").is(id));
		upsert(query, update , action);
	}
	
	public void updateWithNull(T entity , String action) {

		Assert.notNull(entity, "Entity must not be null!");
		Assert.notNull(entity.getId(), "Entity ID must not be null!");

		@SuppressWarnings("unchecked")
		ID id = (ID) entity.getId();

		Update update =  updateObjWithNull(entity);
		
		Query query = new Query(Criteria.where("_id").is(id));

		update(query, update , action);
	}

	/**
	 * Get current logged User Detail.
	 */
	public UserDetail getCurrentLoggedInUser() {
		UserDetail userDetail = inMemoryClientDetailsService.getUserDetail();
		return userDetail;
	}

	public void update(Query query, Update update , String action) {
		updateHistory(update, action);
		mongoTemplate.updateFirst(query, update, theType);
	}
	
	public void updateWithoutHistory(Query query, Update update) {
		mongoTemplate.updateFirst(query, update, theType);
	}
	
	protected void updateHistory( Update update , String action) {
		
//		logger.info(update.getUpdateObject());
		
		update.set("modified", new Date());
		
		UserDetail userDetail = inMemoryClientDetailsService.getUserDetail();
		if(userDetail != null){
			action = userDetail.getAppType().name() + "_" +  action; 
		}
		
		UpdateHistory updateHistory = new UpdateHistory(action);
		
		if(userDetail != null) {
			update.set("modifiedBy", userDetail.getUserMongoId());
			
			updateHistory.setUpdateBy(userDetail.getUserMongoId());
			updateHistory.setUpdateByUserId(userDetail.getUserId());
			updateHistory.setUpdateByUserName(userDetail.getDisplayUserName());
		}
		
		if(!theType.isAnnotationPresent(NoHistory.class)){
			update.push("history", updateHistory);
		}
	}
	
	public void updateHistory(T entity ,String action) {
		
		entity.setModified(new Date());
		
		UserDetail userDetail = inMemoryClientDetailsService.getUserDetail();
		if(userDetail != null){
			action = userDetail.getAppType().name() + "_" +  action; 
		}
		
		UpdateHistory updateHistory = new UpdateHistory(action);
		
		if(userDetail != null) {
			entity.setModifiedBy(userDetail.getUserMongoId());
			
			updateHistory.setUpdateBy(userDetail.getUserMongoId());
			updateHistory.setUpdateByUserId(userDetail.getUserId());
			updateHistory.setUpdateByUserName(userDetail.getDisplayUserName());
		}

		if(!entity.getClass().isAnnotationPresent(NoHistory.class)){
			List<UpdateHistory> list = new ArrayList<UpdateHistory>();
			list.add(updateHistory);		
			entity.setHistory(list);
		}
	}
	
	public <S extends T> List<S> save(Iterable<S> entities , String action) {

		Assert.notNull(entities, "The given Iterable of entities not be null!");

		List<S> result = new ArrayList<S>();

		for (S entity : entities) {
			save(entity , action);
			result.add(entity);
		}

		return result;
	}

	/**
	 * Deletes the entity with the given id.
	 * 
	 * @param id
	 *            must not be {@literal null}.
	 * @throws IllegalArgumentException
	 *             in case the given {@code id} is {@literal null}
	 */
	public void delete(ID id) {
		Assert.notNull(id, "The given id must not be null!");
		mongoTemplate.remove(getIdQuery(id), theType);

	}

	/**
	 * Deletes a given entity.
	 * 
	 * @param entity
	 * @throws IllegalArgumentException
	 *             in case the given entity is (@literal null}.
	 */
	//TODO :: Need To Test ...
	public void delete(T entity) {

		String jsonStr = objToJsonStr(entity);
		Assert.notNull(jsonStr, "The given entity must not be null!");
		Query searchQuery = new BasicQuery(jsonStr);
		mongoTemplate.remove(searchQuery, theType);
	}

	/**
	 * Deletes the given entities.
	 * 
	 * @param entities
	 * @throws IllegalArgumentException
	 *             in case the given {@link Iterable} is (@literal null}.
	 */
	public void delete(Iterable<? extends T> entities) {

		Assert.notNull(entities, "The given Iterable of entities not be null!");

		for (T entity : entities) {
			delete(entity);
		}
	}

	/**
	 * Deletes all entities managed by the repository.
	 */
	public void delete(Query query) {
		mongoTemplate.remove(query, theType);
	}

	/**
	 * Deletes all entities managed by the repository.
	 */
	public void deleteAll() {
		mongoTemplate.dropCollection(theType);
	}

	public T findAndModify(Query query, Update update) {
		checkAndExcludeHistoryKey(query);
		T entity = mongoTemplate.findAndModify(query, update, new FindAndModifyOptions().returnNew(true), theType);
		if (entity != null) {
			return entity;
		}
		return null;
	}

	public T findAndModify(Query query, Update update, FindAndModifyOptions findAndModifyOptions) {
		checkAndExcludeHistoryKey(query);
		T entity = mongoTemplate.findAndModify(query, update, findAndModifyOptions, theType);
		if (entity != null) {
			return entity;
		}
		return null;
	}

	public void updateMulti(Query query, Update update) {
		mongoTemplate.updateMulti(query, update, theType);
	}
	
	public void upsert(Query query, Update update , String action) {
		updateHistory(update, action);
		mongoTemplate.upsert(query, update, theType);
	}


	/**
	 * store image in database in given nameSpace
	 * 
	 * @param nameSpace
	 *            nameSpace in which image will be stored
	 * @param multipartFile
	 *            image will be created from this file
	 * @param imageName
	 *            name of image to be add
	 */
	public void addImage(String nameSpace, MultipartFile multipartFile, String imageName) {

		// create a namespace
		GridFS gfsPhoto = new GridFS(mongoTemplate.getDb(), nameSpace);

		try {
			// get image file from multipartFile
			GridFSInputFile gfsFile = gfsPhoto.createFile(multipartFile.getInputStream());

			// set a new filename for identify purpose
			gfsFile.setFilename(imageName);

			// save the image file into mongoDB
			gfsFile.save();

		} catch (IOException e) {
			logger.error("IOException thrown during create file from multipart file" + e.getMessage(), e);
		}
	}

	/**
	 * get image with given name from given nameSpace
	 * 
	 * @param nameSpace
	 *            name of nameSpace
	 * @param imageName
	 *            name of image to be find
	 * @return
	 */
	public InputStream getImage(String nameSpace, String imageName) {
		GridFS gfsPhoto = new GridFS(mongoTemplate.getDb(), nameSpace);
		GridFSDBFile imageForOutput = gfsPhoto.findOne(imageName);
		if (imageForOutput == null) {
			return null;
		}
		return imageForOutput.getInputStream();
	}

	/**
	 * remove image with given name from given name space
	 * 
	 * @param nameSpace
	 *            namSpace name
	 * @param imageName
	 *            name of image to be removed
	 */
	public void removeImage(String nameSpace, String imageName) {
		GridFS gfsPhoto = new GridFS(mongoTemplate.getDb(), nameSpace);
		GridFSDBFile imageForOutput = gfsPhoto.findOne(imageName);
		gfsPhoto.remove(imageForOutput);
	}
	
	public List<DBObject> getAggregationResult(List<DBObject> aggregationList) {
		List<DBObject> dbObjects = new ArrayList<>();
		try{
			AggregationOutput aggregationOutput = mongoTemplate
					.getCollection(collection_name)
					.aggregate(aggregationList);
			
			dbObjects = (List<DBObject>) aggregationOutput.results();
			
		}catch(Exception e){
			logger.info(e.getClass().getSimpleName() + " Occured during perform aggregation");
			logger.error(e.getMessage(), e);
		}
		return dbObjects;
	}
	
	public List<DBObject> getAggregationResultWithAllowDiskUse(List<DBObject> aggregationList) {
		List<DBObject> dbObjects = new ArrayList<>();
		try{
			Cursor cursor = mongoTemplate.getCollection(collection_name)
					.aggregate(aggregationList,	AggregationOptions.builder()
							.allowDiskUse(true).build());
			
			while(cursor.hasNext()) {
				dbObjects.add(cursor.next());
			}
		}catch(Exception e){
			logger.info(e.getClass().getSimpleName() + " Occured during perform aggregation");
			logger.error(e.getMessage(), e);
		}
		return dbObjects;
	}
	
	protected Update updateObj(T entity) {
	
		DBObject object = new BasicDBObject();
		mongoConverter.write(entity, object);

		Update update = new Update();
		for (String key : object.keySet()) {
			if (key.equals("_id") || key.equals("history")) {
				continue;
			} else if (key.equals("nursingHistory")) {
				BasicDBList basicDBList = (BasicDBList) object.get(key) ;
				if(basicDBList != null && basicDBList.size() > 0){
					update.push(key, basicDBList.get(0));
				}
			} else {
				update.set(key, object.get(key));
			}
		}
		return update;
		
	}
	
	protected Update updateObjWithNull(T entity) {
		
		DBObject object = new BasicDBObject();
		mongoConverter.write(entity, object);

		Set<String> keys = object.keySet();
		Update update = new Update();
		for (String key : keys) {
			if (key.equals("_id")  || key.equals("history")) {
				continue;
			} else {
				update.set(key, object.get(key));
			}
		}
		
		for (String nullKey : setToNullValue) {
			 if(!keys.contains(nullKey)){
				 update.unset(nullKey);
			 }
		}
		
		return update;
	}
	
	public List<T> findWithoutJoin() {
		return findWithoutJoin(new Query());
	}
	
	public List<T> findWithoutJoin(Query query){
		
		try {
			checkAndExcludeHistoryKey(query);
			
			DBObject queryDbObject = query.getQueryObject();
			DBObject fieldsDbObject = query.getFieldsObject();
			
			MongoPersistentEntity<?> entity = this.mongoConverter.getMappingContext().getPersistentEntity(theType);
			DBObject mappedFields = fieldsDbObject == null ? null : queryMapper.getMappedObject(fieldsDbObject, entity);
			DBObject mappedQuery = queryMapper.getMappedObject(queryDbObject, entity);
			
			QueryCursorPreparer queryCursorPreparer = new QueryCursorPreparer(query, theType); 
			
			DBCursor cursor ;
			if(mappedFields == null){
				cursor = mongoTemplate.getCollection(collection_name).find(mappedQuery);
			}else{
				cursor = mongoTemplate.getCollection(collection_name).find(mappedQuery , mappedFields);
			}
		    
			cursor = queryCursorPreparer.prepare(cursor);
			
			List<T> result = new ArrayList<T>();
			
			while (cursor.hasNext()) {
                DBObject object = cursor.next();
                result.add(mongoConverter.read(theType, object));
            }
			
			return result;
		}catch (RuntimeException e) {
			throw e;
		}
	}
	
	class QueryCursorPreparer {

		private final Query query;
		private final Class<?> type;

		public QueryCursorPreparer(Query query, Class<?> type) {

			this.query = query;
			this.type = type;
		}

		public DBCursor prepare(DBCursor cursor) {

			if (query == null) {
				return cursor;
			}

			if (query.getSkip() <= 0 && query.getLimit() <= 0 && query.getSortObject() == null
					&& !StringUtils.hasText(query.getHint())) {
				return cursor;
			}

			DBCursor cursorToUse = cursor;

			try {
				if (query.getSkip() > 0) {
					cursorToUse = cursorToUse.skip(query.getSkip());
				}
				if (query.getLimit() > 0) {
					cursorToUse = cursorToUse.limit(query.getLimit());
				}
				if (query.getSortObject() != null) {
					cursorToUse = cursorToUse.sort(getMappedSortObject(query, type));
				}
				if (StringUtils.hasText(query.getHint())) {
					cursorToUse = cursorToUse.hint(query.getHint());
				}
			} catch (RuntimeException e) {
				throw e;
			}

			return cursorToUse;
		}
	}
	
	private DBObject getMappedSortObject(Query query, Class<?> type) {

		if (query == null || query.getSortObject() == null) {
			return null;
		}

		MongoPersistentEntity<?> entity = this.mongoConverter.getMappingContext().getPersistentEntity(type);
		return queryMapper.getMappedObject(query.getSortObject(), entity);
	}


	public List<T> findAll_B() {
		Query query = new Query();
		query.addCriteria(Criteria.where("status").is(true));
		return find(query);
	}
	
	public List<T> findAll_E() {
		Query query = new Query();
		query.addCriteria(Criteria.where("status").is(MasterStatus.ACTIVE));
		return find(query);
	}
	
	public boolean hasAccessRole(String role){
		UserDetail currentLoggedInUser = getCurrentLoggedInUser();
		return MyUtils.getBooleanFromValue(currentLoggedInUser.getRole().getAccess().get(role));
	}
	
	public boolean canAccessVip(){
		return hasAccessRole("ACCESS_VIP_PATIENT");
	}

}
