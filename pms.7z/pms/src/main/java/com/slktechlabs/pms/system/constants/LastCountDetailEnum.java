package com.slktechlabs.pms.system.constants;

public enum LastCountDetailEnum {
	
	PATIENT_COUNT("Patient Count"),
	PAYMENT("Payment"),
	BILL("Bill");
	
	String displayName;

	LastCountDetailEnum(String displayName) {
		this.displayName = displayName;
	}

	public String getDisplayName() {
		return displayName;
	}

}
