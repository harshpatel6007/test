package com.slktechlabs.pms.system.model.patient;

import com.slktechlabs.pms.system.annotation.CustomJoin;
import com.slktechlabs.pms.system.model.master.RelationMaster;

public class PatientRelation {

	private String userId;
	@CustomJoin(joinId = "userId", value = { "firstName", "middleName", "lastName" }, isInclude = true)
	private Patient relative;
	private String relationId;
	@CustomJoin(joinId = "relationId", value = { "name" }, isInclude = true)
	private RelationMaster relationMaster;

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getRelationId() {
		return relationId;
	}

	public void setRelationId(String relationId) {
		this.relationId = relationId;
	}

	public Patient getRelative() {
		return relative;
	}

	public void setRelative(Patient relative) {
		this.relative = relative;
	}

	public RelationMaster getRelationMaster() {
		return relationMaster;
	}

	public void setRelationMaster(RelationMaster relationMaster) {
		this.relationMaster = relationMaster;
	}

	@Override
	public String toString() {
		return "PatientRelation [userId=" + userId + ", relative=" + relative
				+ ", relationId=" + relationId + ", relationMaster="
				+ relationMaster + "]";
	}
}
