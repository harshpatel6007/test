package com.slktechlabs.pms.system.model.visit;

public enum AppointmentLimitType {

	NUMBER("Number"),
	NONE("None"),
	DATE("End Date");

	private String limitType;
	
	private AppointmentLimitType(String limitType) {
		this.limitType = limitType;
	}

	public String getLimitType() {
		return limitType;
	}
	
}
