package com.slktechlabs.pms.system.model.bill;

import java.util.List;

public class FinalBill {

	private BillCollection bill;
	private List<PaymentCollection> payments;
	private List<ExpenseCollection> expenses;
	
	public BillCollection getBill() {
		return bill;
	}
	public void setBill(BillCollection bill) {
		this.bill = bill;
	}
	public List<PaymentCollection> getPayments() {
		return payments;
	}
	public void setPayments(List<PaymentCollection> payments) {
		this.payments = payments;
	}
	public List<ExpenseCollection> getExpenses() {
		return expenses;
	}
	public void setExpenses(List<ExpenseCollection> expenses) {
		this.expenses = expenses;
	}

	@Override
	public String toString() {
		return "FinalBill [bill=" + bill + ", payments=" + payments
				+ ", expenses=" + expenses + "]";
	}

}
