package com.slktechlabs.pms.system.controller.web;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

import com.slktechlabs.pms.system.service.masters.CountryMasterService;

@Controller
@RequestMapping("stateMasterWeb")
public class StateMasterWebController {
	
	@Autowired
	CountryMasterService countryMasterService;
	
	private final String PAGE_PREFIX = "pms/masters/stateMaster/";
	
	@RequestMapping("manage")
	public String manage(ModelMap modelMap){
		modelMap.addAttribute("countryMasterList", countryMasterService.findAll_E());
		return PAGE_PREFIX + "stateMasterMange";
	}
	
	@RequestMapping("view")
	public String view(ModelMap modelMap){
		modelMap.addAttribute("countryMasterList", countryMasterService.findAll_E());
		return PAGE_PREFIX + "stateMasterView";
	}
}
