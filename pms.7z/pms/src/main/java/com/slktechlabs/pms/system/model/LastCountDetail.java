package com.slktechlabs.pms.system.model;

import org.springframework.data.mongodb.core.mapping.Document;

import com.slktechlabs.pms.system.constants.LastCountDetailEnum;


@Document(collection = "lastCountDetail")
public class LastCountDetail extends AbstractDocument {

	private LastCountDetailEnum lastCountDetailEnum;
	private long lastCount;
	
	public LastCountDetailEnum getLastCountDetailEnum() {
		return lastCountDetailEnum;
	}
	public void setLastCountDetailEnum(LastCountDetailEnum lastCountDetailEnum) {
		this.lastCountDetailEnum = lastCountDetailEnum;
	}
	public long getLastCount() {
		return lastCount;
	}
	public void setLastCount(long lastCount) {
		this.lastCount = lastCount;
	}
	
	@Override
	public String toString() {
		return "LastCountDetail [lastCountDetailEnum=" + lastCountDetailEnum
				+ ", lastCount=" + lastCount + "]";
	}
	
}
