package com.slktechlabs.pms.system.constants;

public enum ItemType {

	PRODUCT("Product"), 
	SERVICE("Service");
	
	private final String displayStatus;

	private ItemType(String displayStatus) {
		this.displayStatus = displayStatus;
	}

	public String getDisplayStatus() {
		return displayStatus;
	}

	@Override
	public String toString() {
		return displayStatus;
	}
}
