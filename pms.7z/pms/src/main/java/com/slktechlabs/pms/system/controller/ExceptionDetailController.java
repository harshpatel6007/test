package com.slktechlabs.pms.system.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import com.slktechlabs.pms.system.annotation.RequestBodyParam;
import com.slktechlabs.pms.system.constants.MessageConstants;
import com.slktechlabs.pms.system.constants.StatusConstants;
import com.slktechlabs.pms.system.model.ExceptionDetail;
import com.slktechlabs.pms.system.model.SearchCriteria;
import com.slktechlabs.pms.system.service.ExceptionDetailService;
import com.slktechlabs.pms.system.util.ResponseGenerator;

@Controller
@RequestMapping("exceptionDetails")
public class ExceptionDetailController {
	  
	@Autowired
	private ExceptionDetailService exceptionDetailsService;
	  
	@Autowired
	private MongoTemplate mongoTemplate;
	
	@RequestMapping(value = "search", method = RequestMethod.POST)
	@ResponseBody
	public Object search(@RequestBodyParam SearchCriteria searchCriteria, 
			@RequestBodyParam Date from, @RequestBodyParam Date to){
		List<ExceptionDetail> list = exceptionDetailsService.search(searchCriteria, from, to);
		return ResponseGenerator.generateResponse(StatusConstants.success, list);
	}
	
	@RequestMapping(value = "searchToday", method = RequestMethod.POST)
	@ResponseBody
	public Object searchToday(@RequestBodyParam SearchCriteria searchCriteria) throws JsonGenerationException, JsonMappingException, IOException{
		DBCollection  dbCollection = mongoTemplate.getCollection("bugCollection");
		DBCursor cursor =  dbCollection.find();
		List<ExceptionDetail> list = new ArrayList<>();
		
		while (cursor.hasNext()) { 
			ExceptionDetail exceptionDetail = null;
		    DBObject obj = cursor.next(); 
		    exceptionDetail = mongoTemplate.getConverter().read(ExceptionDetail.class, obj);  
		    list.add(exceptionDetail); 
		}
		
		return ResponseGenerator.generateResponse(StatusConstants.success, list);
	}
	
}
