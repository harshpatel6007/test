package com.slktechlabs.pms.system.dao.pvb;

import org.springframework.stereotype.Repository;

import com.slktechlabs.pms.system.dao.HMISDao;
import com.slktechlabs.pms.system.model.bill.PaymentCollection;

@Repository
public class Paymentdao extends HMISDao<PaymentCollection, String>{

}
