package com.slktechlabs.pms.system.model.patient;

import com.slktechlabs.pms.system.annotation.CustomJoin;
import com.slktechlabs.pms.system.model.master.CountryMaster;
import com.slktechlabs.pms.system.model.master.StateMaster;

public class Address {

	private String country;
	@CustomJoin(joinId = "country", value = { "name" }, isInclude = true)
	private CountryMaster countryMaster;
	private String state;
	@CustomJoin(joinId = "state", value = { "name" }, isInclude = true)
	private StateMaster stateMaster;
	private String city;
	private String postalAddress;
	private String pincode;

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getPostalAddress() {
		return postalAddress;
	}

	public void setPostalAddress(String postalAddress) {
		this.postalAddress = postalAddress;
	}

	public String getPincode() {
		return pincode;
	}

	public void setPincode(String pincode) {
		this.pincode = pincode;
	}

	public CountryMaster getCountryMaster() {
		return countryMaster;
	}

	public void setCountryMaster(CountryMaster countryMaster) {
		this.countryMaster = countryMaster;
	}

	public StateMaster getStateMaster() {
		return stateMaster;
	}

	public void setStateMaster(StateMaster stateMaster) {
		this.stateMaster = stateMaster;
	}

	@Override
	public String toString() {
		return "Address [country=" + country + ", countryMaster="
				+ countryMaster + ", state=" + state + ", stateMaster="
				+ stateMaster + ", city=" + city + ", postalAddress="
				+ postalAddress + ", pincode=" + pincode + "]";
	}

}
