package com.slktechlabs.pms.system.service.pvb;

import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.slktechlabs.pms.system.constants.BillStatus;
import com.slktechlabs.pms.system.constants.LastCountDetailEnum;
import com.slktechlabs.pms.system.dao.pvb.BillDao;
import com.slktechlabs.pms.system.model.bill.BillCollection;
import com.slktechlabs.pms.system.model.visit.Visit;
import com.slktechlabs.pms.system.service.HMISService;
import com.slktechlabs.pms.system.service.LastCountDetailService;

@Service
public class BillService extends HMISService<BillCollection, String>{

	private BillDao billDao;
	
	@Autowired
	private LastCountDetailService lastCountDetailService;
	
	@Autowired
	public BillService(BillDao billDao) {
		super(billDao);		
		this.billDao = (BillDao) billDao;
	}

	public List<BillCollection> getBillForVisit(String visitId) {
		return billDao.getBillForVisit(visitId);
	}

	public void generateBillForVisit(Visit visit) {		
		BillCollection bill = new BillCollection();
		bill.setStatus(BillStatus.Open);
		bill.setVisitId(visit.getId());
		bill.setPatientId(visit.getPatientId());
		bill.setCreatedDate(new Date());
		bill.setCreatedBy(getLoggedUserMongoId());
		bill.setBillNumber(generateBillNumber());
		save(bill, "Create Bill");
	}

	private String generateBillNumber() {
		
		long count = lastCountDetailService.getLastCountForEnum(LastCountDetailEnum.BILL);
		String sequenceNumber = String.format("%0" + 7 + "d", count);
		
		Calendar cal = Calendar.getInstance();
		
		String year = String.valueOf(cal.get(Calendar.YEAR));		
		String month = String.format("%0" + 2 + "d", cal.get(Calendar.MONTH)+1);
		
		return "BILL-" + year + "-" + month + "-" + sequenceNumber;		
	}

	public List<String> getBillNumberOfVisit(String visitId) {
		return billDao.getBillNumberOfVisit(visitId);
	}

}
