package com.slktechlabs.pms.system.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.log4j.Logger;
import org.bson.types.ObjectId;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.slktechlabs.pms.system.constants.MessageConstants.UserMessagesEnum;
import com.slktechlabs.pms.system.constants.RoleAccessEnum;
import com.slktechlabs.pms.system.constants.StatusConstants;
import com.slktechlabs.pms.system.dao.UserDao;
import com.slktechlabs.pms.system.model.RefferMaster;
import com.slktechlabs.pms.system.model.SearchCriteria;
import com.slktechlabs.pms.system.model.User;
import com.slktechlabs.pms.system.model.UserDashboard;
import com.slktechlabs.pms.system.model.Response.ResponseBean;
import com.slktechlabs.pms.system.model.patient.Address;
import com.slktechlabs.pms.system.model.patient.Patient;
import com.slktechlabs.pms.system.model.patient.PhoneNumber;
import com.slktechlabs.pms.system.model.role.Role;
import com.slktechlabs.pms.system.model.visit.AppointmentDetail;
import com.slktechlabs.pms.system.model.visit.AppointmentStatus;
import com.slktechlabs.pms.system.model.visit.Visit;
import com.slktechlabs.pms.system.model.visit.VisitStatus;
import com.slktechlabs.pms.system.service.pvb.VisitService;
import com.slktechlabs.pms.system.util.DateUtils;
import com.slktechlabs.pms.system.util.ResponseGenerator;

@Service
public class UserService extends HMISService<User, String> {

	UserDao userDao;

	Logger logger = Logger.getLogger(getClass());

	@Autowired
	public UserService(UserDao userDao) {
		super(userDao);
		this.userDao = userDao;
	}

	@Autowired
	private RoleService roleService;

	@Autowired
	RoleTemplateService roleTemplateService;
	
	@Autowired
	private VisitService visitService;
	
	
	public User checkUser(String userId , String password){
		return userDao.checkUser(userId , password);
	}

	public List<User> autoSearchUser(SearchCriteria searchCriteria) {
		return userDao.getAllUser(searchCriteria);
	}

	public boolean checkDuplicateUserId(String userId) {
		return userDao.checkDuplicateUserId(userId);
	}

	public boolean changePassword(User user) {
		return userDao.changePassword(user);
	}

	public List<User> getSmallListByType(List<String> typeList) {
		return userDao.getSmallListByType(typeList);
	}

	public List<String> getUserIdsByType(List<String> typeList) {
		List<String> userIds = new ArrayList<>();
		List<ObjectId> objectIds = userDao.getUserIdsByType(typeList);
		if (objectIds != null) {
			for (ObjectId id : objectIds) {
				userIds.add(id.toHexString());
			}
		}
		return userIds;
	}

	public List<User> getUserIdsBySingleType(String type) {
		List<User> users = userDao.getUserIdsBySingleType(type);
		return users;
	}

	/**
	 * find role from database and update access according to user's custom role
	 * 
	 * @param user
	 */
	public void setRole(User user) {

		Role role = roleService.findOne(user.getRoleId());

		Map<RoleAccessEnum, Boolean> userAccessMap = user.getCustomRole();
		Map<RoleAccessEnum, Boolean> roleAccessMap = role.getAccess();

		if (userAccessMap != null) {
			for (Entry<RoleAccessEnum, Boolean> roleAccess : userAccessMap
					.entrySet()) {
				roleAccessMap.put(roleAccess.getKey(), roleAccess.getValue());
			}
		}
		user.setRole(role);
	}

	/**
	 * update role in given user
	 * 
	 * @param user
	 * @param role
	 */
	public void updateRole(User user, Role role) {

		// add to prevent main role from update
		Role tempRole = new Role();
		tempRole.setId(role.getId());
		tempRole.setName(role.getName());
		tempRole.setStatus(role.getStatus());
		tempRole.setAccess(new HashMap<RoleAccessEnum, Boolean>(role
				.getAccess()));

		if (user.getCustomRole() != null) {
			Map<RoleAccessEnum, Boolean> userAccessMap = user.getCustomRole();
			Map<RoleAccessEnum, Boolean> roleAccessMap = tempRole.getAccess();

			if (userAccessMap != null) {
				for (Entry<RoleAccessEnum, Boolean> customRoleAccess : userAccessMap
						.entrySet()) {
					roleAccessMap.put(customRoleAccess.getKey(),
							customRoleAccess.getValue());
				}
			}
		}
		user.setRole(tempRole);
		update(user, "Update Role");
	}

	/**
	 * update user's role according to role
	 * 
	 * @param role
	 */
	public void updateRoleInUsers(Role role) {
		List<User> users = userDao.findUserByRoleId(role.getId());
		for (User user : users) {
			updateRole(user, role);
		}
	}

	public void changePasswordByUser(String userId,String password ) {
		userDao.changePasswordByUser(userId , password);
	}

	/**
	 * find users with given Ids
	 * 
	 * @param userIds
	 * @return only specific details(userId, displayName)
	 */
	public List<User> getSmallListByIds(List<String> userIds) {
		return userDao.getSmallListByIds(userIds);
	}

	public List<User> customAutoSearch(SearchCriteria searchCriteria,
			String userType, String userId, String accessName,
			List<String> subTypes, String displayName) {
		List<User> users = userDao.customAutoSearch(searchCriteria, userType,
				userId, accessName, subTypes, displayName);
		return users;
	}

	public Map<String, String> getUserMap() {
		Map<String, String> userMap = new HashMap<>();
		List<User> users = userDao.getUsers();
		for (User user : users) {
			userMap.put(user.getId(), user.getDisplayName());
		}
		return userMap;
	}

	public List<User> getActiveUserByRole(List<String> roleAccessList) {
		return userDao.getActiveUserByRole(roleAccessList);
	}

	public List<User> getActiveUsersByAnyRole(List<String> roleAccessList) {
		return userDao.getActiveUsersByAnyRole(roleAccessList);
	}

	public User findOneSmallUserById(String id) {
		return userDao.findOneSmallUserById(id);
	}

	public User userLimitedDetail(String id) {
		return userDao.userLimitedDetail(id);

	}

	public List<User> getUserByDrId(List<String> listOfDrIds) {
		return userDao.getUserByDrId(listOfDrIds);
	}

	public List<User> getUserNameById(List<String> listofHistoryById) {
		return userDao.getUserNameById(listofHistoryById);
	}

	public boolean checkRoleUsed(String roleId) {
		return userDao.checkRoleUsed(roleId);
	}

	public ResponseBean changeStatus(String id, Boolean status) {
		userDao.changeStatus(id, status);
		return ResponseGenerator.generateResponse(StatusConstants.success,
				UserMessagesEnum.UPDATE_SUCCESS.message("User Status"));
	}
	
	public User getUserIdAndName(String userMongoId) {
		return userDao.getUserIdAndName(userMongoId);
	}
	
	public UserDashboard getDashBoardForUser(String userId, Date date) {
		
		Date from = DateUtils.setFromTimeTo0Hour(date);
		Date to = DateUtils.setToTimeTo24Hour(date);
		
		UserDashboard dashboard = new UserDashboard();
		
//		List<Visit> scheduledvisits = visitService.getApponitedVisitsForUser(userId, from, to);
//		
//		dashboard.setScheduledPatientCount(scheduledvisits.size());
//		dashboard.setScheduledPatients(scheduledvisits);
		
		List<Visit> todayVisits = visitService.getVisitsForUser(userId, from, to);
		
		List<Visit> inClinicVisits = new ArrayList<>();
		List<Visit> completedVisits = new ArrayList<>();
		List<Visit> scheduledVisits = new ArrayList<>();
		
		for(Visit visit : todayVisits) {
			if(Arrays.asList(VisitStatus.SCHEDULED, VisitStatus.ARRIVED, 
					VisitStatus.READY).contains(visit.getStatus())) {
				scheduledVisits.add(visit);
			} else if(visit.getStatus() == VisitStatus.IN_CLINIC) {
				inClinicVisits.add(visit);
			} else if(visit.getStatus() == VisitStatus.COMPLETE) {
				completedVisits.add(visit);
			}
		}
		
		dashboard.setScheduledPatientCount(scheduledVisits.size());
		dashboard.setScheduledPatients(scheduledVisits);
		
		dashboard.setInClinicPatients(inClinicVisits);
		dashboard.setInClinicPatientCount(inClinicVisits.size());
		
		dashboard.setCompletedPatients(completedVisits);
		dashboard.setCompletedPatientCount(completedVisits.size());
		
		return dashboard;
	}

//	private UserDashboard createDummyDashboard() {
//		UserDashboard dashboard = new UserDashboard();
//		
//		dashboard.setCompletedPatientCount((int)(Math.random() * 10));
//		dashboard.setInClinicPatientCount((int)(Math.random() * 5));
//		dashboard.setScheduledPatientCount(11);
//		
//		setVisitsInDashboard(dashboard);
//		
//		return dashboard;
//	}
//
//	private void setVisitsInDashboard(UserDashboard dashboard) {
//		
//		List<Visit> scheduledVisits = new ArrayList<>();
//		for(int i = 0; i <= 10; i++) {
//			Visit visit = new Visit();
//			
//			visit.setAppointmentDetail(getSampleAppointment(i));
//			visit.setPatient(getSamplePatient(i));
//			
//			scheduledVisits.add(visit);
//		}
//		dashboard.setScheduledPatients(scheduledVisits);
//		
//		
//		List<Visit> inClinicVisits = new ArrayList<>();
//		for(int i = 11; i < 11 + dashboard.getInClinicPatientCount(); i++) {
//			Visit visit = new Visit();
//			visit.setStatus(VisitStatus.OPEN);
//			visit.setAppointmentDetail(getSampleAppointment(i));
//			visit.setPatient(getSamplePatient(i));
//			
//			inClinicVisits.add(visit);
//		}
//		dashboard.setInClinicPatients(inClinicVisits);
//		
//		List<Visit> compltedVisits = new ArrayList<>();
//		for(int i = 11 + dashboard.getInClinicPatientCount();
//				i < 11 + dashboard.getInClinicPatientCount() + dashboard.getCompletedPatientCount(); 
//				i++) {
//			Visit visit = new Visit();
//			visit.setStatus(VisitStatus.CLOSE);
//			visit.setAppointmentDetail(getSampleAppointment(i));
//			visit.setPatient(getSamplePatient(i));
//			
//			compltedVisits.add(visit);
//		}
//		dashboard.setCompletedPatients(compltedVisits);
//		
//	}
//
//	private Patient getSamplePatient(int i) {
//		Patient patient = new Patient();
//		patient.setId(new ObjectId().toHexString());
//		Calendar calendar = Calendar.getInstance();
//		calendar.add(Calendar.YEAR, -i * 10);
//		patient.setDateOfBirth(calendar.getTime());
//		patient.setMiddleName("Middle name - " + i);
//		patient.setFirstName("First name - " + i);
//		patient.setGender((i % 2) == 0 ? "Male" : "Female");
//		patient.setLastName("Last name - " + i);
//		patient.setPatientId("PID-" + String.format("%0" + 7 + "d", i));
//		patient.setReferalDoctor("51ce8f2765365dc1794c6091");
//		patient.setEmailId("patient" + i + "@gmail.com");
//		PhoneNumber phoneNumber = new PhoneNumber();
//		phoneNumber.setNumber("987421561" + i);
//		phoneNumber.setType("M");
//		patient.setPhoneNumber("987421561" + i);
//		RefferMaster refferMaster = new RefferMaster();
//		refferMaster.setId("51ce8f2765365dc1794c6091");
//		refferMaster.setName("Dr. Om Prakash Mehra");
//		Address address = new Address();
//		address.setPostalAddress("block number - " + i+", street - " + i + 
//		"Nr. nearby place - " + i + " district - " + i);
//		patient.setAddress(address);
//		patient.setRefferMaster(refferMaster);
//		return patient;
//	}
//
//	private AppointmentDetail getSampleAppointment(int i) {
//		AppointmentDetail appointmentDetail = new AppointmentDetail();
//		appointmentDetail.setAppointmentNumber(String.format("%0" + 7 + "d", i));
//		Calendar calendar = Calendar.getInstance();
//		calendar.add(Calendar.HOUR_OF_DAY, 2);
//		calendar.add(Calendar.HOUR_OF_DAY, -i);
//		appointmentDetail.setAppointmentDate(calendar.getTime());
//		appointmentDetail.setAppointmentNotes("Notes : " + i);
//		appointmentDetail.setDuration(30);
//		appointmentDetail.setRepeatApplointment(false);		
//		appointmentDetail.setVisitReason("Visit reason - " + i);
//		return appointmentDetail;
//	}

}
