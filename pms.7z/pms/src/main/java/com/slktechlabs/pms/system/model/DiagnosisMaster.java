package com.slktechlabs.pms.system.model;

import org.springframework.data.mongodb.core.mapping.Document;

import com.slktechlabs.pms.system.constants.MasterStatus;

@Document(collection = "diagnosisMaster")
public class DiagnosisMaster extends AbstractDocument {

	private String name;
	private MasterStatus status;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public MasterStatus getStatus() {
		return status;
	}

	public void setStatus(MasterStatus status) {
		this.status = status;
	}

	@Override
	public String toString() {
		return "UserTypeMaster [name=" + name + ", status=" + status + "]";
	}

}
