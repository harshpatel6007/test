package com.slktechlabs.pms.system.controller.web;

import java.io.IOException;
import java.util.Date;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import com.slktechlabs.pms.system.model.UserDashboard;
import com.slktechlabs.pms.system.service.RoleService;
import com.slktechlabs.pms.system.service.UserService;
import com.slktechlabs.pms.system.service.UserTypeMasterService;
import com.slktechlabs.pms.system.util.JSONUtils;

@Controller
@RequestMapping("user")
public class UserWebController {

	@Autowired
	private UserService userService;
	
	private Logger logger = Logger.getLogger(getClass());
	
	private final String PAGE_PREFIX = "pms/user/";
	
	@Autowired
	UserTypeMasterService userTypeMasterService;
	
	@Autowired
	RoleService roleService;

	@RequestMapping("welcome")
	public String moveToWelocme() {
		logger.info("inside welocme");
		return PAGE_PREFIX + "welcome";
	}
	
	@RequestMapping("manage")
	public String manage(ModelMap modelMap){
		modelMap.addAttribute("userTypeList", userTypeMasterService.findAll_E());
		return "pms/user/userAdd";
	}
	@RequestMapping("dashboard/{userId}")
	public String moveToDashboard(@PathVariable("userId") String userId,
			ModelMap modelMap) {
		logger.info("inside dashboard " + userId);
		UserDashboard dashboard = userService.getDashBoardForUser(userId, new Date());
		try {
			modelMap.put("dashboard", JSONUtils.jsonFromObject(dashboard));
		} catch (IOException e) {
			logger.info("Error occured during convert dashboard into json");
			logger.error(e.getMessage(), e);
		}
		return PAGE_PREFIX + "dashBoard";
	}
	
}
