package com.slktechlabs.pms.system.model.patient;

import com.slktechlabs.pms.system.annotation.CustomJoin;
import com.slktechlabs.pms.system.model.master.RelationMaster;

public class EmergencyContact {

	private String conatctNumber;
	private String relationId;
	@CustomJoin(joinId = "relationId", value = { "name" }, isInclude = true)
	private RelationMaster relationMaster;
	
	public String getConatctNumber() {
		return conatctNumber;
	}
	public void setConatctNumber(String conatctNumber) {
		this.conatctNumber = conatctNumber;
	}
	public String getRelationId() {
		return relationId;
	}
	public void setRelationId(String relationId) {
		this.relationId = relationId;
	}
	public RelationMaster getRelationMaster() {
		return relationMaster;
	}
	public void setRelationMaster(RelationMaster relationMaster) {
		this.relationMaster = relationMaster;
	}
	@Override
	public String toString() {
		return "EmergencyContact [conatctNumber=" + conatctNumber
				+ ", relationId=" + relationId + ", relationMaster="
				+ relationMaster + "]";
	}

}
