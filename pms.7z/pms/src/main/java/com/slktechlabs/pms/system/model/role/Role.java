package com.slktechlabs.pms.system.model.role;

import java.util.Map;

import org.springframework.data.mongodb.core.mapping.Document;

import com.slktechlabs.pms.system.constants.MasterStatus;
import com.slktechlabs.pms.system.constants.RoleAccessEnum;
import com.slktechlabs.pms.system.model.AbstractDocument;

@Document(collection = "roleCollection")
public class Role extends AbstractDocument {

	private String name;
	private MasterStatus status;
	private Map<RoleAccessEnum, Boolean> access;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	/*
	 * public Boolean getStatus() { return status; }
	 * 
	 * public void setStatus(Boolean status) { this.status = status; }
	 */

	public Map<RoleAccessEnum, Boolean> getAccess() {
		return access;
	}

	public MasterStatus getStatus() {
		return status;
	}

	public void setStatus(MasterStatus status) {
		this.status = status;
	}

	public void setAccess(Map<RoleAccessEnum, Boolean> access) {
		this.access = access;
	}

	@Override
	public String toString() {
		return "Role [name=" + name + ", status=" + status + ", access="
				+ access + "]";
	}

}
