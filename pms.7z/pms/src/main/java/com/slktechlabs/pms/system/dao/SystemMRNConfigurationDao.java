package com.slktechlabs.pms.system.dao;

import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Repository;

import com.slktechlabs.pms.system.constants.MRNType;
import com.slktechlabs.pms.system.model.SystemMRNConfiguration;

@Repository
public class SystemMRNConfigurationDao extends HMISDao<SystemMRNConfiguration, String>{
	
	public SystemMRNConfiguration getByType(MRNType mrnType) {
		Query query = new Query();
		query.addCriteria(Criteria.where("mrnType").is(mrnType.name()));
		return findOne(query);
	}

	public void incrementLastNumberInMrnConfiguration(MRNType mrnType) {
		Query query = new Query();
		query.addCriteria(Criteria.where("mrnType").is(mrnType.name()));
		Update update = new Update();
		update.inc("mrnConfiguration.currentSequenceNumber", 1);
		updateWithoutHistory(query, update);
	}
}
