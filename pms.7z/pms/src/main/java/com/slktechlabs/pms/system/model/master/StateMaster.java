package com.slktechlabs.pms.system.model.master;

import org.springframework.data.mongodb.core.mapping.Document;

import com.slktechlabs.pms.system.annotation.CustomJoin;
import com.slktechlabs.pms.system.constants.MasterStatus;
import com.slktechlabs.pms.system.model.AbstractDocument;

@Document(collection = "stateMaster")
public class StateMaster extends AbstractDocument {
	private String name;
	private String countryId;
	@CustomJoin(joinId="countryId", value = {"name"}, isInclude = true)
	private CountryMaster countryMaster;
	private MasterStatus status;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCountryId() {
		return countryId;
	}

	public void setCountryId(String countryId) {
		this.countryId = countryId;
	}

	public MasterStatus getStatus() {
		return status;
	}

	public void setStatus(MasterStatus status) {
		this.status = status;
	}

	public CountryMaster getCountryMaster() {
		return countryMaster;
	}

	public void setCountryMaster(CountryMaster countryMaster) {
		this.countryMaster = countryMaster;
	}

	@Override
	public String toString() {
		return "StateMaster [name=" + name + ", countryId=" + countryId
				+ ", countryMaster=" + countryMaster + ", status=" + status
				+ "]";
	}

}
