package com.slktechlabs.pms.system.controller.masters;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.slktechlabs.pms.system.annotation.RequestBodyParam;
import com.slktechlabs.pms.system.constants.MessageConstants.UserMessagesEnum;
import com.slktechlabs.pms.system.constants.StatusConstants;
import com.slktechlabs.pms.system.model.Response.ResponseBean;
import com.slktechlabs.pms.system.model.master.StateMaster;
import com.slktechlabs.pms.system.service.masters.StateMasterService;
import com.slktechlabs.pms.system.util.ResponseGenerator;

@Controller
@RequestMapping("stateMaster")
public class StateMasterController {

	@Autowired
	StateMasterService stateMasterService;

	@RequestMapping(value ="add", method= RequestMethod.POST)
	@ResponseBody
	public ResponseBean add(@RequestBody StateMaster stateMaster) {

		Boolean exist = stateMasterService.uniqueCheck("name", stateMaster.getName(), stateMaster.getId());
		if(exist){
			return ResponseGenerator.generateResponse(StatusConstants.error, UserMessagesEnum.UNIQUE.message("name"));
		}
		stateMasterService.save(stateMaster, "State Master Add");
		return ResponseGenerator.generateResponse(StatusConstants.success,
				UserMessagesEnum.ADD_SUCCESS.message("State Master"), stateMaster);
	}
	
	@RequestMapping(value ="update", method= RequestMethod.POST)
	@ResponseBody
	public ResponseBean update(@RequestBody StateMaster stateMaster) {
		Boolean exist = stateMasterService.uniqueCheck("name", stateMaster.getName(), stateMaster.getId());
		if(exist){
			return ResponseGenerator.generateResponse(StatusConstants.error, UserMessagesEnum.UNIQUE.message("name"));
		}
		stateMasterService.update(stateMaster, "State Master Update");
		return ResponseGenerator.generateResponse(StatusConstants.success,
				UserMessagesEnum.UPDATE_SUCCESS.message("State Master"), stateMaster);
	}
	
	@RequestMapping(value ="search", method= RequestMethod.POST)
	@ResponseBody
	public ResponseBean search(@RequestBodyParam String stateName, @RequestBodyParam String countryId) {
		return ResponseGenerator.generateResponse(StatusConstants.success,
				stateMasterService.search(stateName, countryId));
	}
	
	@RequestMapping(value ="delete", method= RequestMethod.POST)
	@ResponseBody
	public ResponseBean delete(@RequestBodyParam String id) {
		
		stateMasterService.delete(id);
		return ResponseGenerator.generateResponse(StatusConstants.success,
				UserMessagesEnum.DELETE_SUCCESS.message("State Master"));
	}
	
	@RequestMapping(value ="get", method= RequestMethod.POST)
	@ResponseBody
	public ResponseBean get(@RequestBodyParam String id) {
		return ResponseGenerator.generateResponse(StatusConstants.success,
				stateMasterService.findOne(id));
	}
	
	@RequestMapping(value ="getStatesByCountry", method= RequestMethod.POST)
	@ResponseBody
	public ResponseBean getStatesByCountry(@RequestBodyParam String countryId) {
		return ResponseGenerator.generateResponse(StatusConstants.success,
				stateMasterService.getStatesByCountry(countryId));
	}
}
