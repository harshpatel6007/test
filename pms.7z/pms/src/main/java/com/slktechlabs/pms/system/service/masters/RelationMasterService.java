package com.slktechlabs.pms.system.service.masters;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.slktechlabs.pms.system.dao.masters.RelationMasterDao;
import com.slktechlabs.pms.system.model.SearchCriteria;
import com.slktechlabs.pms.system.model.master.RelationMaster;
import com.slktechlabs.pms.system.service.HMISService;

@Service
public class RelationMasterService extends HMISService<RelationMaster, String>{
	
	RelationMasterDao relationMasterDao;
	
	@Autowired
	public RelationMasterService(RelationMasterDao relationMasterDao) {
		super(relationMasterDao);
		this.relationMasterDao = relationMasterDao;
	}

	public List<RelationMaster> search(SearchCriteria searchCriteria) {
		return relationMasterDao.search(searchCriteria);
	}

	public List<RelationMaster> getRelationMasterList() {
		return relationMasterDao.findAll_E();
	}

	

}
