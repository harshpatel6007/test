package com.slktechlabs.pms.system.model.master;

import org.springframework.data.mongodb.core.mapping.Document;

import com.slktechlabs.pms.system.annotation.CustomJoin;
import com.slktechlabs.pms.system.constants.MasterStatus;
import com.slktechlabs.pms.system.model.AbstractDocument;

@Document(collection = "documentSubTypeMaster")
public class DocumentSubTypeMaster extends AbstractDocument {
	private String name;
	private String documentTypeId;
	@CustomJoin(joinId = "documentTypeId", value = {"name"} , isInclude = true)
	private DocumentTypeMaster documentTypeMaster;
	private MasterStatus status;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDocumentTypeId() {
		return documentTypeId;
	}

	public void setDocumentTypeId(String documentTypeId) {
		this.documentTypeId = documentTypeId;
	}

	public MasterStatus getStatus() {
		return status;
	}

	public void setStatus(MasterStatus status) {
		this.status = status;
	}

	public DocumentTypeMaster getDocumentTypeMaster() {
		return documentTypeMaster;
	}

	public void setDocumentTypeMaster(DocumentTypeMaster documentTypeMaster) {
		this.documentTypeMaster = documentTypeMaster;
	}

	@Override
	public String toString() {
		return "DocumentSubTypeMaster [name=" + name + ", documentTypeId="
				+ documentTypeId + ", documentTypeMaster=" + documentTypeMaster
				+ ", status=" + status + "]";
	}

}
