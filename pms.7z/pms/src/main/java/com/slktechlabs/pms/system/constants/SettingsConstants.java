package com.slktechlabs.pms.system.constants;

import java.io.File;

import org.apache.log4j.Logger;

public class SettingsConstants {

	private static Logger logger = Logger.getLogger(SettingsConstants.class);
	
	public static String saveFolderLocation;

	public static String mongoDbBackupLocation;

	public static String mongoDbExceptionLocation;

	public static String fileBackupLocation;

	public static String hmisDataPath;
	public static String DOCUMENT_ROOT_PATH;
	public static String PATIENT_PHOTO_PATH;
	public static String USER_PHOTO_PATH;
	public static String SCHEME_DOCUMENT_PATH;
	public static String INSURANCE_DOCUMENT_PATH;
	public static String ITEM_PHOTO_PATH;
	public static String PATIENT_DOCUMENT_PATH;
	public static String TEMP_FILES_PATH;
	public static String CANDIDATE_DOCUMENT_PATH;
	public static String EMPLOYEE_DOCUMENT_PATH;
	public static String PRINT_SETTING_TEMPLATE_IMAGE_PATH;	
	public static String defaultItemPhotoPath;
	public static String defaultPatientMalePhotoPath;
	public static String defaultPatientFemalePhotoPath;
	public static String defaultUserPhotoPath;
	public static String VISIT_DOCUMENT_PATH;

	public static void setDataPath(String dataPath) {

		saveFolderLocation = dataPath;

		mongoDbBackupLocation = saveFolderLocation + File.separator + "MongoBackUp";

		File file = new File(mongoDbBackupLocation);

		if (!file.isDirectory()) {
			file.mkdirs();
		}

		mongoDbExceptionLocation = saveFolderLocation + File.separator + "MongoExceptionBackUp";

		file = new File(mongoDbExceptionLocation);

		if (!file.isDirectory()) {
			file.mkdirs();
		}

		fileBackupLocation = saveFolderLocation + File.separator + "fileBackUp";

		file = new File(fileBackupLocation);

		if (!file.isDirectory()) {
			file.mkdirs();
		}

		
		hmisDataPath = saveFolderLocation + File.separator + "HMIS_DATA";

		PATIENT_PHOTO_PATH = hmisDataPath + File.separator + "patientPhoto";
		
		file = new File(PATIENT_PHOTO_PATH);

		if (!file.isDirectory()) {
			file.mkdirs();
		}
		
		USER_PHOTO_PATH = hmisDataPath + File.separator + "userPhoto";
		
		file = new File(USER_PHOTO_PATH);

		if (!file.isDirectory()) {
			file.mkdirs();
		}
		
		SCHEME_DOCUMENT_PATH = hmisDataPath + File.separator + "schemeDocument";
		
		file = new File(SCHEME_DOCUMENT_PATH);

		if (!file.isDirectory()) {
			file.mkdirs();
		}
		
		INSURANCE_DOCUMENT_PATH = hmisDataPath + File.separator + "insuranceDocument";
		
		file = new File(INSURANCE_DOCUMENT_PATH);

		if (!file.isDirectory()) {
			file.mkdirs();
		}
		
		ITEM_PHOTO_PATH = hmisDataPath + File.separator + "itemPhoto";
		
		file = new File(ITEM_PHOTO_PATH);

		if (!file.isDirectory()) {
			file.mkdirs();
		}
		
		PATIENT_DOCUMENT_PATH = hmisDataPath + File.separator + "patientDocument";
		
		file = new File(PATIENT_DOCUMENT_PATH);

		if (!file.isDirectory()) {
			file.mkdirs();
		}
		
		PRINT_SETTING_TEMPLATE_IMAGE_PATH = hmisDataPath + File.separator + "printTemplateImage";
		
		file = new File(PRINT_SETTING_TEMPLATE_IMAGE_PATH);

		if (!file.isDirectory()) {
			file.mkdirs();
		}
		
		logger.info("");
		defaultItemPhotoPath = DOCUMENT_ROOT_PATH + File.separator + "resource" + File.separator + "default.jpg";
		defaultPatientMalePhotoPath = DOCUMENT_ROOT_PATH + File.separator + "resource" + File.separator + "default_male.jpg";
		defaultPatientFemalePhotoPath = DOCUMENT_ROOT_PATH + File.separator + "resource" + File.separator + "default_female.jpg";
		defaultUserPhotoPath = DOCUMENT_ROOT_PATH + File.separator + "resource" + File.separator + "default.jpg";
		
		// copy default data to new directories
		/*try {
			copyFileToDirectory(defaultImagePhotoPath, ITEM_PHOTO_PATH);
			copyFileToDirectory(defaultPatientPhotoPath, PATIENT_PHOTO_PATH);
			copyFileToDirectory(defaultUserPhotoPath, USER_PHOTO_PATH);
		} catch (IOException e) {
			logger.error(e.getMessage(), e);
		}*/
		
		TEMP_FILES_PATH = DOCUMENT_ROOT_PATH + File.separator + "HMIS-App-Temp";

		File tempFolder = new File(TEMP_FILES_PATH);

		if (!tempFolder.isDirectory()) {
			tempFolder.mkdirs();
		}
		
		CANDIDATE_DOCUMENT_PATH = hmisDataPath + File.separator + "Candidate-Documents";
		
		File candidateDoc = new File(CANDIDATE_DOCUMENT_PATH);

		if (!candidateDoc.isDirectory()) {
			candidateDoc.mkdirs();
		}
		
		EMPLOYEE_DOCUMENT_PATH = hmisDataPath + File.separator + "Employee-Documents";
		
		File employeeDoc = new File(EMPLOYEE_DOCUMENT_PATH);

		if (!employeeDoc.isDirectory()) {
			employeeDoc.mkdirs();
		}
		
		VISIT_DOCUMENT_PATH = hmisDataPath + File.separator + "Visit-Documents";
		
		File visitDoc = new File(VISIT_DOCUMENT_PATH);

		if (!visitDoc.isDirectory()) {
			visitDoc.mkdirs();
		}
		
	}
	
//	private static void copyFileToDirectory(String src, String destDir ) throws IOException {
//		
//		File srcFile = new File(src);
//		File destDirFile = new File(destDir);
//		
//		FileUtils.copyFileToDirectory(srcFile, destDirFile);
//	}
}
