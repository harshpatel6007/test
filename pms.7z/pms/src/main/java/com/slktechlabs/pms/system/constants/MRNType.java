package com.slktechlabs.pms.system.constants;

public enum MRNType {
	VisitNumberPattern("Visit Number Pattern");
	
	private String mrnType;

	private MRNType(String mrnType) {
		this.mrnType = mrnType;
	}

	public String getPolicy() {
		return mrnType;
	}

	@Override
	public String toString() {
		return mrnType;
	}

}
