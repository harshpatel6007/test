package com.slktechlabs.pms.system.model.bill;

import java.util.List;

public class ExpenseDetails {

	private Double schemeReliefAmount;
	private Double schemeReceivedAmount;
	private Double schemeLossAmount;
	private Double insuranceReliefAmount;
	private Double insuranceReceivedAmount;
	private Double insuranceLossAmount;
	private Double totalFundAmount;
	
	private Double concessionAmount;
	private Double usedWaiveAmount;
	private double emcsRelief;
}
