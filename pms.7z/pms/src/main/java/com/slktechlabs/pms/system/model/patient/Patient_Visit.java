package com.slktechlabs.pms.system.model.patient;

import com.slktechlabs.pms.system.model.visit.Visit;

public class Patient_Visit {

	private Patient patient;
	private Visit visit;

	public Patient getPatient() {
		return patient;
	}

	public void setPatient(Patient patient) {
		this.patient = patient;
	}

	public Visit getVisit() {
		return visit;
	}

	public void setVisit(Visit visit) {
		this.visit = visit;
	}

	@Override
	public String toString() {
		return "Patient_Visit [patient=" + patient + ", visit=" + visit + "]";
	}

}
