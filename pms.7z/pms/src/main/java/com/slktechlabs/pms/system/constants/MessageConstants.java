package com.slktechlabs.pms.system.constants;

public class MessageConstants {

	public enum UserMessagesEnum {

		ADD_SUCCESS("${data} added successfully."), 
		UPDATE_SUCCESS("${data} updated successfully."),
		DELETE_SUCCESS("${data} deleted successfully."),
		ADD_FAILURE("${data} could not be added."), 
		UPDATE_FAILURE("${data} could not be updated."),
		DELETE_FAILURE("${data} could not be deleted."), 
		UNIQUE("The ${data} you have entered already exists in the system."
				+ " Please enter another ${data}"),
		INSUFFICIENT_AMOUNT("Th balance in patient account is insufficient. "
				+ "Available balance : ${data}"),
		REFRENCE_EXIST("This record is being referred in ${data} and "
				+ "so cannot be deleted");

		String message;

		private UserMessagesEnum(String message) {
			this.message = message;
		}

		public String getMessage() {
			return message;
		}

		public String message(String... datas) {
			String msg =  message;
			
			if (this == UNIQUE) {
				if (datas.length > 0) {
					String string = datas[0];
					msg = msg.replace("${data}", string);
				}
			} else {
				for (int i = 0; i < datas.length; i++) {
					String string = datas[i];
					msg= msg.replaceFirst("\\$\\{data\\}", string);
				}
				msg = msg.replace("${data}", "XXX");
			}
			return msg;
		}
	}
	
	public final static String VERSION_ERROR = "Client Not compatible with Server ,Please update Your Client Application. ";
	public final static String LOGIN_FAIL_APPLICATION_CODE_DIFFER = "Application Mode Not Compatible with Server";
	public final static String LOGIN_SUC = "Logged in Successfully.";
	public final static String LOGIN_FAIL = "User Name Or Password does not Exist.";
	public final static String INACTIVE_USER = "Sorry, you cannot login as user is inactive.";
	
	public final static String LOGOUT_SUC = "Logout Successfully.";
	
	public static final String USER_NOT_FOUND = "No User Found For Given Query.";
	public static final String PASSWORD_CHANGE_SUC = "Password Changed Successfully.";
	public static final String USER_PHOTO_UPLOAD_SUC = "User Photo Uploaded Successfully.";
	public static final String USER_SIGNATURE_UPLOAD_SUC = "User Signature Uploaded Successfully.";
	public static final String PASSWORD_CHANGE_FAILED = "User Does Not Has Role To Change Password.";
	public static final String APP_TYPE_NOT_SUPPORTED = "App Type Not Supported";
	public static final String FILE_UPLOAD = "File uploaded successfully";
}

