package com.slktechlabs.pms.system.constants;

public enum RoleGroupEnum {
	
	USER_MANAGEMENT(RoleAccessEnum.IS_ADMIN),
	
	MASTERS(RoleAccessEnum.RELIGION_MASTER_VIEW, RoleAccessEnum.RELIGION_MASTER_MANAGE, 
			RoleAccessEnum.RELATION_MASTER_VIEW, RoleAccessEnum.RELATION_MASTER_MANAGE, 
			RoleAccessEnum.COUNTRY_MASTER_VIEW, RoleAccessEnum.COUNTRY_MASTER_MANAGE, 
			RoleAccessEnum.STATE_MASTER_VIEW, RoleAccessEnum.STATE_MASTER_MANAGE),
			
	ROLE( RoleAccessEnum.ROLE_VIEW , RoleAccessEnum.ROLE_MANAGE); 
	
	
	private RoleAccessEnum[] accesses;
	
	private RoleGroupEnum(RoleAccessEnum...access) {
		this.accesses = access;
	}

	public RoleAccessEnum[] getAccesses() {
		return accesses;
	}
}
