package com.slktechlabs.pms.system.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.slktechlabs.pms.system.constants.MasterStatus;
import com.slktechlabs.pms.system.constants.MessageConstants.UserMessagesEnum;
import com.slktechlabs.pms.system.constants.StatusConstants;
import com.slktechlabs.pms.system.dao.RoleDao;
import com.slktechlabs.pms.system.model.SearchCriteria;
import com.slktechlabs.pms.system.model.Response.ResponseBean;
import com.slktechlabs.pms.system.model.role.Role;
import com.slktechlabs.pms.system.util.ResponseGenerator;

@Service
public class RoleService extends HMISService<Role,String> {

	RoleDao roleDao;
	
	@Autowired
	UserService userService;
	
	@Autowired
	public RoleService(	RoleDao roleDao) {
		super(roleDao);
		this.roleDao=roleDao;
	}

	public List<Role> autoSearchRole(SearchCriteria searchCriteria){
		return roleDao.autoSearchRole(searchCriteria);
	}
	
	public List<Role> searchRole(SearchCriteria searchCriteria){
		return roleDao.searchRole(searchCriteria);
	}

	public ResponseBean checkNameAvailabilityAndRoleStatus(Role role, boolean isEditMode) {
		boolean isExist = roleDao.uniqueCheck("name", role.getName(), role.getId());
		if(isExist){
			return ResponseGenerator.generateResponse(StatusConstants.error,
					UserMessagesEnum.UNIQUE.message("Role Name"));
		}
		if(isEditMode && (role.getStatus() == MasterStatus.INACTIVE)) {
			boolean isRoleUsed = userService.checkRoleUsed(role.getId());
			if(isRoleUsed) {
				return ResponseGenerator.generateResponse(StatusConstants.error, 
						UserMessagesEnum.REFRENCE_EXIST.message("User"));
			}
		}
		return ResponseGenerator.generateResponse(StatusConstants.success, null);
	}

	public ResponseBean changeStatus(String roleId, MasterStatus status) {
		if(status == MasterStatus.INACTIVE){
			boolean isRoleUsed = userService.checkRoleUsed(roleId);
			if(isRoleUsed) {
				return ResponseGenerator.generateResponse(StatusConstants.error, 
						UserMessagesEnum.REFRENCE_EXIST.message("User"));
			}
		}
		roleDao.changeStatus(roleId, status);
		return ResponseGenerator.generateResponse(StatusConstants.success,
				UserMessagesEnum.UPDATE_SUCCESS.message("Role Status"));
	}
}
