package com.slktechlabs.pms.system.model.visit;

public enum AppointmentRepeatType {

	WEEKLY("Weekly"),
	MONTHLY("Monthly"),
	DAILY("Daily");
	
	private String repeatBy;
	
	private AppointmentRepeatType(String repeatBy) {
		this.repeatBy = repeatBy;
	}

	public String getRepeatBy() {
		return repeatBy;
	}
	
}
