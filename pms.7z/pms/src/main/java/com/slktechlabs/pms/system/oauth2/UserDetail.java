package com.slktechlabs.pms.system.oauth2;

import com.slktechlabs.pms.system.constants.AppType;
import com.slktechlabs.pms.system.model.role.Role;

public class UserDetail {

	private String userMongoId;
	private String token_id;
	private String userId;
	private Role role;
	private String displayUserName;
	private String userType;
	private String macAddress;
	private String hostPcName;
	private AppType appType;
	
	public String getUserMongoId() {
		return userMongoId;
	}
	public void setUserMongoId(String userMongoId) {
		this.userMongoId = userMongoId;
	}
	public String getToken_id() {
		return token_id;
	}
	public void setToken_id(String token_id) {
		this.token_id = token_id;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public Role getRole() {
		return role;
	}
	public void setRole(Role role) {
		this.role = role;
	}
	public String getDisplayUserName() {
		return displayUserName;
	}
	public void setDisplayUserName(String displayUserName) {
		this.displayUserName = displayUserName;
	}
	public String getUserType() {
		return userType;
	}
	public void setUserType(String userType) {
		this.userType = userType;
	}
	public String getMacAddress() {
		return macAddress;
	}
	public void setMacAddress(String macAddress) {
		this.macAddress = macAddress;
	}
	public String getHostPcName() {
		return hostPcName;
	}
	public void setHostPcName(String hostPcName) {
		this.hostPcName = hostPcName;
	}
	public AppType getAppType() {
		return appType;
	}
	public void setAppType(AppType appType) {
		this.appType = appType;
	}
	
	@Override
	public String toString() {
		return "UserDetail [userMongoId=" + userMongoId + ", token_id="
				+ token_id + ", userId=" + userId + ", role=" + role
				+ ", displayUserName=" + displayUserName + ", userType="
				+ userType + ", macAddress=" + macAddress + ", hostPcName="
				+ hostPcName + ", appType=" + appType + "]";
	}

}
