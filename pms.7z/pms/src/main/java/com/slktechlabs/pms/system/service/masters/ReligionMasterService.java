package com.slktechlabs.pms.system.service.masters;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.slktechlabs.pms.system.dao.masters.ReligionMasterDao;
import com.slktechlabs.pms.system.model.SearchCriteria;
import com.slktechlabs.pms.system.model.master.ReligionMaster;
import com.slktechlabs.pms.system.service.HMISService;

@Service
public class ReligionMasterService extends HMISService<ReligionMaster, String>{
	
	ReligionMasterDao religionMasterDao;
	
	@Autowired
	public ReligionMasterService(ReligionMasterDao religionMasterDao) {
		super(religionMasterDao);
		this.religionMasterDao = religionMasterDao;
	}
	
	public List<ReligionMaster> search(SearchCriteria searchCriteria){
		return religionMasterDao.search(searchCriteria);
	}

}
