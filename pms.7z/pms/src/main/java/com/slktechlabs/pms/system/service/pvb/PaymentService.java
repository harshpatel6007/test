package com.slktechlabs.pms.system.service.pvb;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.slktechlabs.pms.system.dao.HMISDao;
import com.slktechlabs.pms.system.dao.pvb.Paymentdao;
import com.slktechlabs.pms.system.model.bill.PaymentCollection;
import com.slktechlabs.pms.system.service.HMISService;

@Service
public class PaymentService extends HMISService<PaymentCollection, String>{

	private Paymentdao paymentdao;
	
	@Autowired
	public PaymentService(Paymentdao paymentdao) {
		super(paymentdao);
		this.paymentdao = paymentdao;
	}

}
