package com.slktechlabs.pms.system.model.visit;

import java.util.Date;

import com.slktechlabs.pms.system.annotation.CustomJoin;
import com.slktechlabs.pms.system.model.master.DocumentSubTypeMaster;

public class ScanDocumentDetails {
	private String uuid;
	private String documentTypeId;
	private String documentSubTypeId;
	@CustomJoin(joinId = "documentSubTypeId", value = "name")
	private DocumentSubTypeMaster documentSubTypeMaster;
	private String documentFileName;
	private String documentStoragePath;
	private Date uploadDate;
	private Date lastViewedDate;

	public String getDocumentTypeId() {
		return documentTypeId;
	}

	public void setDocumentTypeId(String documentTypeId) {
		this.documentTypeId = documentTypeId;
	}

	public String getDocumentSubTypeId() {
		return documentSubTypeId;
	}

	public void setDocumentSubTypeId(String documentSubTypeId) {
		this.documentSubTypeId = documentSubTypeId;
	}

	public String getDocumentFileName() {
		return documentFileName;
	}

	public void setDocumentFileName(String documentFileName) {
		this.documentFileName = documentFileName;
	}

	public String getUuid() {
		return uuid;
	}

	public void setUuid(String uuid) {
		this.uuid = uuid;
	}

	public String getDocumentStoragePath() {
		return documentStoragePath;
	}

	public void setDocumentStoragePath(String documentStoragePath) {
		this.documentStoragePath = documentStoragePath;
	}

	public Date getUploadDate() {
		return uploadDate;
	}

	public void setUploadDate(Date uploadDate) {
		this.uploadDate = uploadDate;
	}

	public Date getLastViewedDate() {
		return lastViewedDate;
	}

	public void setLastViewedDate(Date lastViewedDate) {
		this.lastViewedDate = lastViewedDate;
	}

	public DocumentSubTypeMaster getDocumentSubTypeMaster() {
		return documentSubTypeMaster;
	}

	public void setDocumentSubTypeMaster(
			DocumentSubTypeMaster documentSubTypeMaster) {
		this.documentSubTypeMaster = documentSubTypeMaster;
	}

	@Override
	public String toString() {
		return "ScanDocumentDetails [uuid=" + uuid + ", documentTypeId="
				+ documentTypeId + ", documentSubTypeId=" + documentSubTypeId
				+ ", documentSubTypeMaster=" + documentSubTypeMaster
				+ ", documentFileName=" + documentFileName
				+ ", documentStoragePath=" + documentStoragePath
				+ ", uploadDate=" + uploadDate + ", lastViewedDate="
				+ lastViewedDate + "]";
	}

}
