package com.slktechlabs.pms.system.util;

import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.slktechlabs.pms.system.oauth2.UserDetail;

public class RequestUtils {

	private static final Logger logger = Logger.getLogger(RequestUtils.class);
	
	public static HttpServletRequest getRequest() {
		HttpServletRequest request = ((ServletRequestAttributes) RequestContextHolder.currentRequestAttributes()).getRequest();
		return request;
	}
	
	public static String getTokenID(){
		return getTokenID(getRequest());
	}
	
	public static String getTokenID(HttpServletRequest request) {
		String token_id = null;
		HttpSession httpSession = request.getSession();
		if(httpSession != null){
			token_id =  (String) httpSession.getAttribute("token_id");
		}
		return token_id;
	}

	public static UserDetail getUserDetail() {
		return getUserDetail(getRequest());
	}
	
	public static UserDetail getUserDetail(HttpServletRequest request) {
		logger.info(new Date() + " request :-- " + request.hashCode());
		UserDetail userDetail = (UserDetail) request.getSession()
				.getAttribute("userDetail");
		return userDetail;
	}

}
