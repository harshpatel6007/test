package com.slktechlabs.pms.system.model.patient;

import java.util.List;

import com.slktechlabs.pms.system.model.visit.Visit;

public class PatientDetail {

	private Patient patient;
	private List<Visit> visits;
	
	public Patient getPatient() {
		return patient;
	}
	public void setPatient(Patient patient) {
		this.patient = patient;
	}
	public List<Visit> getVisits() {
		return visits;
	}
	public void setVisits(List<Visit> visits) {
		this.visits = visits;
	}
	
	@Override
	public String toString() {
		return "PatientDetail [patient=" + patient + ", visits=" + visits + "]";
	}
	
}
