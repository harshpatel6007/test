package com.slktechlabs.pms.system.model.visit;

public enum AppointmentStatus {

	PENDING("Pending"),
	COMPLETE("Complete"),
	IN_PROGRESS("In Progress"),
	CANCELLED("Cancelled");

	private String status;
	
	private AppointmentStatus(String status) {
		this.status = status;
	}

	public String getStatus() {
		return status;
	}
	
	
}
