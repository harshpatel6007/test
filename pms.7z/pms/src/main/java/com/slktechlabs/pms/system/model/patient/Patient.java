package com.slktechlabs.pms.system.model.patient;

import java.util.Date;
import java.util.List;

import org.springframework.data.annotation.Transient;
import org.springframework.data.mongodb.core.mapping.Document;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.slktechlabs.pms.system.annotation.ApplyCustomJoin;
import com.slktechlabs.pms.system.annotation.CustomJoin;
import com.slktechlabs.pms.system.constants.TitleType;
import com.slktechlabs.pms.system.model.AbstractDocument;
import com.slktechlabs.pms.system.model.ConcessionTypeMaster;
import com.slktechlabs.pms.system.model.OccupationMaster;
import com.slktechlabs.pms.system.model.PatientTypeMaster;
import com.slktechlabs.pms.system.model.RefferMaster;
import com.slktechlabs.pms.system.model.master.ReligionMaster;
import com.slktechlabs.pms.system.util.MyUtils;

@Document(collection = "patientCollection")
public class Patient extends AbstractDocument {

	private TitleType titleType;
	private String firstName;
	private String middleName;
	private String lastName;
	private String gender;
	private Date dateOfBirth;
	private String age;
	private String phoneNumber;
	private String emailId;

	private String referalDoctor;
	@CustomJoin(joinId = "referalDoctor", value = { "name" }, isInclude = true)
	private RefferMaster refferMaster;
	@Transient
	private String refferalOther;
	private String concession;
	@CustomJoin(joinId = "concession", value = { "name" }, isInclude = true)
	private ConcessionTypeMaster concessionTypeMaster;

	private String patientType;
	@CustomJoin(joinId = "patientType", value = { "name" }, isInclude = true)
	private PatientTypeMaster patientTypeMaster;

	private String religion;
	@CustomJoin(joinId = "religion", value = { "name" }, isInclude = true)
	private ReligionMaster religionMaster;

	private String occupation;
	@CustomJoin(joinId = "occupation", value = { "name" }, isInclude = true)
	private OccupationMaster occupationMaster;

	@ApplyCustomJoin
	private Address address;
	private Date registrationDate;
	private String patientId;
	private String createdBy;

	@ApplyCustomJoin
	private List<PatientRelation> relationships;
	@ApplyCustomJoin
	private List<EmergencyContact> emergencyContacts;

	private String patientPhotoStoragePath;
	private String patientPhotoName;
	@Transient
	private Boolean isWalkIn;

	public TitleType getTitleType() {
		return titleType;
	}

	public void setTitleType(TitleType titleType) {
		this.titleType = titleType;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getMiddleName() {
		return middleName;
	}

	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public Date getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public RefferMaster getRefferMaster() {
		return refferMaster;
	}

	public void setRefferMaster(RefferMaster refferMaster) {
		this.refferMaster = refferMaster;
	}

	public String getConcession() {
		return concession;
	}

	public void setConcession(String concession) {
		this.concession = concession;
	}

	public ConcessionTypeMaster getConcessionTypeMaster() {
		return concessionTypeMaster;
	}

	public void setConcessionTypeMaster(
			ConcessionTypeMaster concessionTypeMaster) {
		this.concessionTypeMaster = concessionTypeMaster;
	}

	public String getPatientType() {
		return patientType;
	}

	public void setPatientType(String patientType) {
		this.patientType = patientType;
	}

	public PatientTypeMaster getPatientTypeMaster() {
		return patientTypeMaster;
	}

	public void setPatientTypeMaster(PatientTypeMaster patientTypeMaster) {
		this.patientTypeMaster = patientTypeMaster;
	}

	public String getReligion() {
		return religion;
	}

	public void setReligion(String religion) {
		this.religion = religion;
	}

	public ReligionMaster getReligionMaster() {
		return religionMaster;
	}

	public void setReligionMaster(ReligionMaster religionMaster) {
		this.religionMaster = religionMaster;
	}

	public String getOccupation() {
		return occupation;
	}

	public void setOccupation(String occupation) {
		this.occupation = occupation;
	}

	public OccupationMaster getOccupationMaster() {
		return occupationMaster;
	}

	public void setOccupationMaster(OccupationMaster occupationMaster) {
		this.occupationMaster = occupationMaster;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	public Date getRegistrationDate() {
		return registrationDate;
	}

	public void setRegistrationDate(Date registrationDate) {
		this.registrationDate = registrationDate;
	}

	public String getPatientId() {
		return patientId;
	}

	public void setPatientId(String patientId) {
		this.patientId = patientId;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public List<PatientRelation> getRelationships() {
		return relationships;
	}

	public void setRelationships(List<PatientRelation> relationships) {
		this.relationships = relationships;
	}

	public List<EmergencyContact> getEmergencyContacts() {
		return emergencyContacts;
	}

	public void setEmergencyContacts(List<EmergencyContact> emergencyContacts) {
		this.emergencyContacts = emergencyContacts;
	}

	public String getReferalDoctor() {
		return referalDoctor;
	}

	public void setReferalDoctor(String referalDoctor) {
		this.referalDoctor = referalDoctor;
	}

	public String getPatientPhotoStoragePath() {
		return patientPhotoStoragePath;
	}

	public void setPatientPhotoStoragePath(String patientPhotoStoragePath) {
		this.patientPhotoStoragePath = patientPhotoStoragePath;
	}

	public String getPatientPhotoName() {
		return patientPhotoName;
	}

	public void setPatientPhotoName(String patientPhotoName) {
		this.patientPhotoName = patientPhotoName;
	}

	public String getAge() {
		return age;
	}

	public void setAge(String age) {
		this.age = age;
	}

	public Boolean getIsWalkIn() {
		return isWalkIn;
	}

	public void setIsWalkIn(Boolean isWalkIn) {
		this.isWalkIn = isWalkIn;
	}

	public String getRefferalOther() {
		return refferalOther;
	}

	public void setRefferalOther(String refferalOther) {
		this.refferalOther = refferalOther;
	}

	@Override
	public String toString() {
		return "Patient [titleType=" + titleType + ", firstName=" + firstName
				+ ", middleName=" + middleName + ", lastName=" + lastName
				+ ", gender=" + gender + ", dateOfBirth=" + dateOfBirth
				+ ", age=" + age + ", phoneNumber=" + phoneNumber
				+ ", emailId=" + emailId + ", referalDoctor=" + referalDoctor
				+ ", refferMaster=" + refferMaster + ", refferalOther="
				+ refferalOther + ", concession=" + concession
				+ ", concessionTypeMaster=" + concessionTypeMaster
				+ ", patientType=" + patientType + ", patientTypeMaster="
				+ patientTypeMaster + ", religion=" + religion
				+ ", religionMaster=" + religionMaster + ", occupation="
				+ occupation + ", occupationMaster=" + occupationMaster
				+ ", address=" + address + ", registrationDate="
				+ registrationDate + ", patientId=" + patientId
				+ ", createdBy=" + createdBy + ", relationships="
				+ relationships + ", emergencyContacts=" + emergencyContacts
				+ ", patientPhotoStoragePath=" + patientPhotoStoragePath
				+ ", patientPhotoName=" + patientPhotoName + ", isWalkIn="
				+ isWalkIn + "]";
	}

	@JsonIgnore
	public String getFullName() {
		String fullName = "";
		fullName = fullName.trim() + MyUtils.getString(getFirstName()).trim();
		fullName = fullName.trim() + " "
				+ MyUtils.getString(getMiddleName()).trim();
		fullName = fullName.trim() + " "
				+ MyUtils.getString(getLastName()).trim();
		return fullName.trim().isEmpty() ? "-" : fullName.trim();

	}
}
