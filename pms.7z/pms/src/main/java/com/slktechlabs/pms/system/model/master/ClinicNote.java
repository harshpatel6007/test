package com.slktechlabs.pms.system.model.master;

import java.util.List;

import com.slktechlabs.pms.system.model.AbstractDocument;

public class ClinicNote extends AbstractDocument {

	private List<String> dignosisMasterId;
	private int pulse;
	private int bloodPresure;
	private int bloodPresure1;
	private int height;
	private int weight;
	private int temparature;
	private List<String> drugAllergyMasterId;
	private boolean diabetic;
	private boolean hypertension;
	private String otherAllergy;

	public List<String> getDignosisMasterId() {
		return dignosisMasterId;
	}

	public void setDignosisMasterId(List<String> dignosisMasterId) {
		this.dignosisMasterId = dignosisMasterId;
	}

	public int getPulse() {
		return pulse;
	}

	public void setPulse(int pulse) {
		this.pulse = pulse;
	}

	public int getBloodPresure() {
		return bloodPresure;
	}

	public void setBloodPresure(int bloodPresure) {
		this.bloodPresure = bloodPresure;
	}

	public int getBloodPresure1() {
		return bloodPresure1;
	}

	public void setBloodPresure1(int bloodPresure1) {
		this.bloodPresure1 = bloodPresure1;
	}

	public int getHeight() {
		return height;
	}

	public void setHeight(int height) {
		this.height = height;
	}

	public int getWeight() {
		return weight;
	}

	public void setWeight(int weight) {
		this.weight = weight;
	}

	public int getTemparature() {
		return temparature;
	}

	public void setTemparature(int temparature) {
		this.temparature = temparature;
	}

	public List<String> getDrugAllergyMasterId() {
		return drugAllergyMasterId;
	}

	public void setDrugAllergyMasterId(List<String> drugAllergyMasterId) {
		this.drugAllergyMasterId = drugAllergyMasterId;
	}

	public boolean isDiabetic() {
		return diabetic;
	}

	public void setDiabetic(boolean diabetic) {
		this.diabetic = diabetic;
	}

	public boolean isHypertension() {
		return hypertension;
	}

	public void setHypertension(boolean hypertension) {
		this.hypertension = hypertension;
	}

	public String getOtherAllergy() {
		return otherAllergy;
	}

	public void setOtherAllergy(String otherAllergy) {
		this.otherAllergy = otherAllergy;
	}

	@Override
	public String toString() {
		return "ClinicNote [dignosisMasterId=" + dignosisMasterId + ", pulse="
				+ pulse + ", bloodPresure=" + bloodPresure + ", bloodPresure1="
				+ bloodPresure1 + ", height=" + height + ", weight=" + weight
				+ ", temparature=" + temparature + ", drugAllergyMasterId="
				+ drugAllergyMasterId + ", diabetic=" + diabetic
				+ ", hypertension=" + hypertension + ", otherAllergy="
				+ otherAllergy + "]";
	}

}
