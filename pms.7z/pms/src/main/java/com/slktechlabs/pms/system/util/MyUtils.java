/*
 * To change this template, choose Tools | Templates and open the template in the editor.
 */
package com.slktechlabs.pms.system.util;

import java.time.LocalDate;
import java.time.Period;
import java.time.ZoneId;
import java.util.Calendar;
import java.util.Date;

/**
 * 
 * Common String and Date related utils.
 * 
 */
/**
 * @author rahul.yadav
 *
 */
public class MyUtils {

	public static final String DISPLAY_NONE = "display:none;";

	public static String getDefaultValue(String value) {
		if (value == null || value.equals("")) {
			return "-";
		}
		return value;
	}

	public static String getDefaultValue(Double dvalue) {
		if (dvalue == null) {
			return "-";
		}
		return dvalue.toString();
	}

	public static String getDefaultValue(Integer value) {
		if (value == null) {
			return "-";
		}
		return value.toString();
	}

	public static String getStringValue(String value) {
		if (value == null) {
			return "";
		}
		return value;
	}

	public static String getStringValue(Double dvalue) {
		if (dvalue == null) {
			return "";
		}
		return dvalue.toString();
	}

	public static String getStringValue(Long lvalue) {
		if (lvalue == null) {
			return "";
		}
		return lvalue.toString();
	}

	public static String getStringValue(Integer value) {
		if (value == null) {
			return "";
		}
		return value.toString();
	}

	public static String getStringValueForIntake(Double dvalue) {
		if (dvalue == 0.0) {
			return "-";
		}
		return dvalue.toString();
	}

	public static Double getDoubleFromString(String field) {
		if (field != null && !field.isEmpty()) {
			return Double.parseDouble(field);
		}
		return 0.0;
	}

	public static Double getDoubleFromValue(Double value) {
		if (value == null) {
			return 0.0;
		}
		return value;
	}

	public static Integer getIntegerFromString(String field) {
		if (field != null && !field.isEmpty()) {
			return Integer.parseInt(field);
		}
		return 0;
	}

	public static Integer getIntegerFromValue(Integer value) {
		if (value == null) {
			return 0;
		}
		return value;
	}

	/**
	 * functions to have same return string to all the project strings.
	 */
	public static String DEFAULT_EMPTY_STRING = "";

	public static String getString(String val) {
		if (val == null) {
			return DEFAULT_EMPTY_STRING;
		}
		return val.trim().toString();
	}

	public static String getString(Integer val) {
		if (val == null) {
			return DEFAULT_EMPTY_STRING;
		}
		return val.toString();
	}

	public static String getString(Double val) {
		if (val == null) {
			return DEFAULT_EMPTY_STRING;
		}
		return val.toString();
	}

	public static String getString(Float val) {
		if (val == null) {
			return DEFAULT_EMPTY_STRING;
		}
		return val.toString();
	}

	public static String getString(Boolean val) {
		if (val == null) {
			return "No";
		} else if (val) {
			return "Yes";
		} else {
			return "No";
		}
	}

	public static boolean getBooleanFromValue(Boolean value) {
		if (value == null) {
			return false;
		}
		return value;
	}

	public static String getValueFromBoolean(Boolean value) {
		if (value == null) {
			return "";
		} else {
			return value ? "Yes" : "No";
		}

	}

	/**
	 * Compare to Arrays of Integer. Used to perform bitwise or operator between
	 * two integer Array
	 * 
	 * @param first
	 *            the firstArray
	 * @param second
	 *            the secondArray
	 * @return the integer[]
	 */
	public static Integer[] compare(Integer[] first, Integer[] second)
			throws ArrayIndexOutOfBoundsException {
		Integer[] result = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
				0, 0, 0, 0, 0, 0, 0 };
		for (int i = 0; i < result.length; i++) {
			result[i] = first[i].intValue() | second[i].intValue();
		}
		return result;
	}

	public static String generateRandomString(int length) {

		StringBuffer buffer = new StringBuffer();
		String characters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ123456789@#";

		int charactersLength = characters.length();

		for (int i = 0; i < length; i++) {
			double index = Math.random() * charactersLength;
			buffer.append(characters.charAt((int) index));
		}
		return buffer.toString();
	}

	public static String checkFirstValue(String string) {
		string = string.startsWith(",") ? string.substring(1) : string;
		string = string.startsWith(" ,") ? string.substring(2) : string;
		string = string.startsWith("  ,") ? string.substring(3) : string;
		return string;
	}

	public static String checkLastValue(String string) {
		string = string.endsWith(",") ? string
				.substring(0, string.length() - 1) : string;
		string = string.endsWith(", ") ? string.substring(0,
				string.length() - 2) : string;
		return string;
	}
	
	/**
     * Get age in years from Date of Birth
     * 
     * @param date
     *            date
     * @return age in years
     */
    public static int getAgeFromDOB(Date date) {
        Calendar dob = Calendar.getInstance();
        dob.setTime(date);
        Calendar today = Calendar.getInstance();
        return today.get(Calendar.YEAR) - dob.get(Calendar.YEAR);
    }

	/**
	 * Get Age in months and years from Date of birth
	 * 
	 * @param date
	 *            date
	 * @return age in months
	 */
    public static String getAgeInDayMonthsAndYearsFromDOB(Date birthDate) {

    	LocalDate today = LocalDate.now();
    	LocalDate birthday = birthDate.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();

    	Period period = Period.between(birthday, today);

    	// Create new Age object
    	if (period.getYears() == 0) {
    		return period.getMonths() + "m " + period.getDays() + "d";
    	} else {
    		return period.getYears() + "y " + period.getMonths() + "m";
    	}
    }

	/* Used for css purpose */
	public static String getStringCss(Date date) {
		if (date == null) {
			return DISPLAY_NONE;
		}
		return "";
	}

	public static String getStringCss(String string) {
		if (string == null) {
			return DISPLAY_NONE;
		} else if (string.equals("")) {
			return DISPLAY_NONE;
		}
		return "";
	}

	public static String getStringCss(Boolean value) {
		if (value == null) {
			return DISPLAY_NONE;
		}
		return "";
	}

	public static String getStringCss(Integer value) {
		if (value == null) {
			return DISPLAY_NONE;
		}
		return "";
	}

	public static String getStringCss(Double value) {
		if (value == null) {
			return DISPLAY_NONE;
		}
		return "";
	}

	public static String getStringCssForCheckBox(Boolean value) {
		if (value == null) {
			return DISPLAY_NONE;
		}
		String valueString = MyUtils.getValueFromBoolean(value);
		return valueString.equals("Yes") ? "" : DISPLAY_NONE;
	}

	/**
	 * Used for hide blog in print if every field has no data nd display none
	 * accordingly
	 * 
	 * @param string
	 *            the string
	 * @param value
	 *            the flag
	 * @return the boolean
	 */
	public static Boolean checkBoolean(String string, Boolean value) {
		return string == null || string.equals("") ? value : false;
	}

	public static Boolean checkBoolean(Integer integer, Boolean value) {
		return integer == null ? value : false;
	}

	public static Boolean checkBoolean(Double double1, Boolean value) {
		return double1 == null ? value : false;
	}

	/**
	 * Used for hide blog in print if every field has no data nd display none
	 * accordingly
	 * 
	 * @param Boolean
	 *            the boolean Value
	 * @param value
	 *            the flag
	 * @return the boolean
	 */
	public static Boolean checkBoolean(Boolean booleanstring, Boolean value) {
		return booleanstring == null ? value : false;
	}

	public static boolean isDefaultEditorContent(String htmlString) {
		return htmlString
				.equalsIgnoreCase("<html dir=\"ltr\"><head></head><body contenteditable=\"true\"></body></html>");
	}
	
	public static boolean isDefaultEditorContentExists(String htmlString) {
		return htmlString
				.equalsIgnoreCase("<html dir=\"ltr\"><head></head><body contenteditable=\"true\">");
	}
	
	
	/**
	 * @param value
	 * @return Rounded off value by two digit
	 */
	public static double getDecimalRoundOff(double value) {
		return Math.round(value * 100.0) / 100.0;
	}

	
	/**
	 * @param value
	 * @param digit
	 * @return Rounded off value by specified digit
	 */
	public static double getDecimalRoundOffUptoDigit(double value, int digit) {
		return Math.round(value * Math.pow(10.0, digit))
				/ Math.pow(10.0, digit);

	}
	
	/**
	 * 
	 * @param str (String Amount)
	 * @return String (with comma)
	 * 
	 */
	public static String getCommaSeparatedDoubleString(String str) {

		String splitDot = str;
		String first = "";
		String second = "";
		String responseString = "";
		String[] amount = splitDot.split("\\.");

		for (String string : amount) {
			first = amount[0];
			second = amount[1];
		}

		String newTextFormat = "";

		for (int i = first.toCharArray().length - 1; i >= 0; i--) {
			char charact = first.toCharArray()[i];
			if (newTextFormat.length() != 0) {
				int textLength = newTextFormat.replace(",", "").length();

				if (textLength < 5) {
					if (textLength % 3 == 0) {
						newTextFormat = "," + newTextFormat;
					}
				} else {
					if ((textLength - 3) % 2 == 0) {
						newTextFormat = "," + newTextFormat;
					}
				}
			}
			newTextFormat = charact + newTextFormat;
		}
		responseString = newTextFormat + "." + second;
		return responseString;
	}
	
	public static void main(String[] args) {
		Calendar cal = Calendar.getInstance();
		cal.setTime(new Date());
		cal.add(Calendar.DATE, -62);
		System.out.println(getAgeInDayMonthsAndYearsFromDOB(cal.getTime()));
	}
	
	public static String getHTMLEditorContent(String htmlString) {
		if (htmlString == null) {
			return DEFAULT_EMPTY_STRING;
		} else {
			htmlString = htmlString.substring(htmlString.indexOf(">", htmlString.indexOf("<body")) + 1, htmlString.indexOf("</body>"));
			// remove p tag if content is enclosed in p tag
			// if(htmlString.startsWith("<p") && htmlString.endsWith("</p>")){
			// htmlString = htmlString.substring(htmlString.indexOf(">",
			// htmlString.indexOf("<p")) + 1, htmlString.indexOf("</p>"));
			// }
			return htmlString;
		}
	}
	
}
