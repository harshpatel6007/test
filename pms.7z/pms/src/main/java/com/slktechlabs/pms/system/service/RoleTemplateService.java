package com.slktechlabs.pms.system.service;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.slktechlabs.pms.system.dao.RoleTemplateDao;
import com.slktechlabs.pms.system.model.role.RoleTemplate;

@Service
public class RoleTemplateService extends HMISService<RoleTemplate, String> {

	RoleTemplateDao roleTemplateDao;
	
	Logger logger = Logger.getLogger(getClass());

	@Autowired
	public RoleTemplateService(RoleTemplateDao reportTemplateDao) {
		super(reportTemplateDao);
		this.roleTemplateDao = reportTemplateDao;
	}
	
	@Autowired
	RoleService roleService;

	public List<RoleTemplate> findAll() {

		List<RoleTemplate> result = roleTemplateDao.findAll();

		return result;
	}

	public void changeAccess(RoleTemplate group) {
		roleTemplateDao.changeAccess(group);
	}

	public void addAccess(RoleTemplate group) {
		roleTemplateDao.addAccess(group);
	}
	
}
