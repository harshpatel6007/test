package com.slktechlabs.pms.system.controller.pvb;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import com.slktechlabs.pms.system.service.pvb.ExpenseService;

@Controller("expense")
public class ExpenseController {

	@Autowired
	private ExpenseService expenseService;
}
