package com.slktechlabs.pms.system.controller.masters;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.slktechlabs.pms.system.annotation.RequestBodyParam;
import com.slktechlabs.pms.system.constants.MessageConstants.UserMessagesEnum;
import com.slktechlabs.pms.system.constants.StatusConstants;
import com.slktechlabs.pms.system.model.SearchCriteria;
import com.slktechlabs.pms.system.model.UserTypeMaster;
import com.slktechlabs.pms.system.model.Response.ResponseBean;
import com.slktechlabs.pms.system.service.UserTypeMasterService;
import com.slktechlabs.pms.system.util.ResponseGenerator;

@Controller
@RequestMapping("userType")
public class UserTypeMasterController {
	
	Logger logger = Logger.getLogger(this.getClass());
	
	@Autowired
	UserTypeMasterService userTypeMasterService;
	
	@RequestMapping(value = "add", method = RequestMethod.POST)
	@ResponseBody
	public ResponseBean createUser(@RequestBody UserTypeMaster userTypeMaster) {
		logger.info("In the UserTypeMaster Add");
		logger.info("userTypeMaster :: >>"+userTypeMaster);
		
		Boolean exist = userTypeMasterService.uniqueCheck("name", userTypeMaster.getName(), userTypeMaster.getId());
		if(exist){
			return ResponseGenerator.generateResponse(StatusConstants.error, UserMessagesEnum.UNIQUE.message("name"));
		}
		userTypeMasterService.save(userTypeMaster, "User Added");
			return ResponseGenerator.generateResponse(StatusConstants.success,
					UserMessagesEnum.ADD_SUCCESS.message("UserTypeMaster"));
		}
	
	@RequestMapping(value ="update", method= RequestMethod.POST)
	@ResponseBody
	public ResponseBean update(@RequestBody UserTypeMaster userTypeMaster) {
		Boolean exist = userTypeMasterService.uniqueCheck("name", userTypeMaster.getName(), userTypeMaster.getId());
		if(exist){
			return ResponseGenerator.generateResponse(StatusConstants.error, UserMessagesEnum.UNIQUE.message("name"));
		}
		userTypeMasterService.update(userTypeMaster, "UserType Master Update");
		return ResponseGenerator.generateResponse(StatusConstants.success,
				UserMessagesEnum.UPDATE_SUCCESS.message("User type master"), userTypeMaster);
	}
	@RequestMapping(value ="search", method= RequestMethod.POST)
	@ResponseBody
	public ResponseBean search(@RequestBody SearchCriteria searchCriteria) {
		logger.info("In the Search Method");
		return ResponseGenerator.generateResponse(StatusConstants.success,
				userTypeMasterService.search(searchCriteria));
	}
	
	@RequestMapping(value ="delete", method= RequestMethod.POST)
	@ResponseBody
	public ResponseBean delete(@RequestBodyParam String id) {
		userTypeMasterService.delete(id);
		return ResponseGenerator.generateResponse(StatusConstants.success,
				UserMessagesEnum.DELETE_SUCCESS.message("User Type Master"));
	}
	
	@RequestMapping(value ="get", method= RequestMethod.POST)
	@ResponseBody
	public ResponseBean get(@RequestBodyParam String id) {
		return ResponseGenerator.generateResponse(StatusConstants.success,
				userTypeMasterService.findOne(id));
	}
	
}
