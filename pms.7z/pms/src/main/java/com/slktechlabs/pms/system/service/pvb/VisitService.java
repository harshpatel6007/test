package com.slktechlabs.pms.system.service.pvb;

import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.bson.types.ObjectId;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.slktechlabs.pms.system.constants.MRNType;
import com.slktechlabs.pms.system.dao.pvb.VisitDao;
import com.slktechlabs.pms.system.model.patient.Patient;
import com.slktechlabs.pms.system.model.visit.ScanDocumentDetails;
import com.slktechlabs.pms.system.model.visit.Visit;
import com.slktechlabs.pms.system.model.visit.VisitStatus;
import com.slktechlabs.pms.system.service.HMISService;
import com.slktechlabs.pms.system.service.LastCountDetailService;
import com.slktechlabs.pms.system.service.SystemMRNConfigurationService;
import com.slktechlabs.pms.system.util.MyUtils;

@Service
public class VisitService extends HMISService<Visit, String>{

	private VisitDao visitDao;
	
	@Autowired
	public VisitService(VisitDao visitDao) {
		super(visitDao);
		this.visitDao = visitDao;
	}
	
	@Autowired
	PatientService patientService;
	
	@Autowired
	private LastCountDetailService lastCountDetailService;
	
	@Autowired
	private SystemMRNConfigurationService systemMRNConfigurationService;
	
	@Autowired
	private BillService billService;

	private Logger logger = Logger.getLogger(getClass());
	
	public List<Visit> getApponitedVisitsForUser(String userId, Date from, Date to) {
		return visitDao.getAppointedVisitsforUser(userId, from, to);
	}

	public Visit addVisit(Patient patient) {
		return createVisitAndBill(patient.getId(), 
				MyUtils.getBooleanFromValue(patient.getIsWalkIn()));
	}

	public List<Visit> getVisitsForUser(String userId, Date from, Date to) {
		return visitDao.getVisitsForUser(userId, from, to);
	}

	public List<Visit> getVisitsOfPatient(String patientId) {
		return visitDao.getVisitsOfPatient(patientId);
	}

	public Visit createVisitFromWalkIn(String patientId) {
		return createVisitAndBill(patientId, true);
	}

	private Visit createVisitAndBill(String patientId, boolean isWalkin) {
		Visit visit = new Visit();
		visit.setCreatedBy(getLoggedUserMongoId());
		visit.setCreatedDate(new Date());
		visit.setPatientId(patientId);
		visit.setStatus(VisitStatus.SCHEDULED);
		visit.setIsWalkIn(isWalkin);
		visit.setVisitNumber(systemMRNConfigurationService.generateSequenceNumberByMRNType(MRNType.VisitNumberPattern));
		visit.setId(new ObjectId().toHexString());
		billService.generateBillForVisit(visit);
		return save(visit, isWalkin ? "Add Walkin Visit" : "Add Visit");
	}

	public Visit updateScanDocument(ScanDocumentDetails scanDocumentDetails,
			String visitId) {
		return visitDao.updateScanDocument(scanDocumentDetails, visitId);		
	}

	public ScanDocumentDetails getScanDocumentByUuid(String documentUuid) {
		Visit visit = visitDao.getScanDocumentByUuid(documentUuid);
		
		ScanDocumentDetails scanDocumentDetails = null;
		for(ScanDocumentDetails documentDetails : visit.getScanDocumentDetails()){
			if(documentDetails.getUuid().equals(documentUuid)){
				scanDocumentDetails = documentDetails; 
			}
		}
		return scanDocumentDetails;
	}

	public List<String> getBillNumberOfVisit(String visitId) {
		return billService.getBillNumberOfVisit(visitId);
	}

	public void changeStatus(String visitId, String userId, VisitStatus status) {
		visitDao.changeStatus(visitId, userId, status);
	}
	
	
	
}
