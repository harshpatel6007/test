package com.slktechlabs.pms.system.oauth2;

import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpSessionEvent;
import javax.servlet.http.HttpSessionListener;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Component;

@Component
public class SessionListener implements HttpSessionListener  {

	private static final Logger logger = Logger.getLogger(SessionListener.class);
	
	@Override
	public void sessionCreated(HttpSessionEvent se) {
		
	}

	@Override
	public void sessionDestroyed(HttpSessionEvent se) {
		
		HttpSession session = se.getSession();
		
		String token_id = (String) session.getAttribute("token_id");
		
		logger.info("sessionDestroyed -- > " +  token_id);
        
	}
}
