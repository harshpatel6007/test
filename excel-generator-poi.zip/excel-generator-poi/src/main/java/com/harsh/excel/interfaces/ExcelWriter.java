package com.harsh.excel.interfaces;

import java.util.Collection;

import org.apache.poi.ss.usermodel.Sheet;

public interface ExcelWriter {

	<T> void createRowFromObject(Sheet sheet, T t);
	<T> void createRowsFromCollection(Sheet sheet, Collection<T> collection);
	<T> void createHeaderRow(Sheet sheet, T t);
	int getNextRowCount(Sheet sheet);
}
