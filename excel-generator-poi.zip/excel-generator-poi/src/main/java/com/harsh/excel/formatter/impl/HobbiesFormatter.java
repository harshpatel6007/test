package com.harsh.excel.formatter.impl;

import java.util.Collection;
import java.util.stream.Collectors;

import com.harsh.excel.formatter.CollectionFormatter;

public class HobbiesFormatter implements CollectionFormatter {

	@Override
	public <T> String format(Collection<T> t) {		
		return t.stream().map(val -> ((Object)val).toString()).collect(Collectors.joining("/"));
	}

}
