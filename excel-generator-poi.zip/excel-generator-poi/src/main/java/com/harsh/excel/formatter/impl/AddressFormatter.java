package com.harsh.excel.formatter.impl;

import com.harsh.excel.formatter.ObjectFormatter;
import com.harsh.excel.tester.Address;

public class AddressFormatter implements ObjectFormatter<Address, String> {

	@Override
	public String format(Address t) {		
		return t.getHouseNo() + ", " + t.getStreetName() + ", " + t.getArea() + ", " + t.getCity() + ", " + t.getState() + ", " + t.getCountry();
	}

}
