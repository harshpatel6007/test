package com.harsh.excel.formatter.impl;

import java.text.SimpleDateFormat;
import java.util.Date;

import com.harsh.excel.formatter.DateFormatter;

public class DOLFormatter implements DateFormatter {

	@Override
	public String format(Date date) {
		if(date == null) {
			return "Still Working";
		} 
		SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
		return sdf.format(date);
	}

}
