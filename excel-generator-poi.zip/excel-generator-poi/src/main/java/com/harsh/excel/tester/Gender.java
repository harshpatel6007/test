package com.harsh.excel.tester;

public enum Gender {

	MALE,
	FEMALE,
	OTHER;
}
