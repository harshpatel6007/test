package com.harsh.excel.formatter;

import java.util.Date;

public interface DateFormatter {

	public String format(Date date);
	
}
