package com.harsh.excel.tester;

import java.beans.IntrospectionException;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.util.Arrays;
import java.util.List;

public class PrimitiveTest {

	public static void main(String[] args) throws IllegalAccessException, IllegalArgumentException, InvocationTargetException, IntrospectionException {
		Test t = new Test();
		for(Field field : t.getClass().getDeclaredFields()) {
			System.out.println(field.getName() + " is numeric : " + isNumericField(field) + " " + field.getType());
			field.setAccessible(true);
			Object value = field.get(t);
			
			if(value instanceof Byte) {
				System.out.println("field is instance of byte");
			} else if (value instanceof Short) {
				System.out.println("field is instance of short");
			} else if (value instanceof Integer) {
				System.out.println("field is instance of int");
			} else if (value instanceof Float) {
				System.out.println("field is instance of float");
			} else if (value instanceof Long) {
				System.out.println("field is instance of lomng");
			} else if (value instanceof Double) {
				System.out.println("field is instance of double");
			} else {
				System.out.println("field is not instance of any class");
			}
			
			
			System.out.println("value : " + ((double) value));
		}
		
		
	}
	
	private static boolean isNumericField(Field field) {
		if(Number.class.isAssignableFrom(field.getType())) {
			return true;
		}
		if(field.getType().isPrimitive()) {
			List<String> primitiveNumericTypes =  Arrays.asList("double", "long", "float", "int", "byte", "short");
			if(primitiveNumericTypes.contains(field.getType().getName())) {
				return true;
			}
		}
		return false;
	}
}

class Test {
	byte b = 5;
	int t = 10;
	short s = 89;
	double d = 90.876;
	long l = 999l;
	float f = 656.76f;
	private Byte bObj = 5;
	private Integer intObj = 10;
	private Short shortObj = 89;
	private Double doubleObj = 90.876;
	private Long longObj = 999l;
	private Float floatObj = 656.76f;
	public byte getB() {
		return b;
	}
	public void setB(byte b) {
		this.b = b;
	}
	public int getT() {
		return t;
	}
	public void setT(int t) {
		this.t = t;
	}
	public short getS() {
		return s;
	}
	public void setS(short s) {
		this.s = s;
	}
	public double getD() {
		return d;
	}
	public void setD(double d) {
		this.d = d;
	}
	public long getL() {
		return l;
	}
	public void setL(long l) {
		this.l = l;
	}
	public float getF() {
		return f;
	}
	public void setF(float f) {
		this.f = f;
	}
	
	public Byte getbObj() {
		return bObj;
	}
	public void setbObj(Byte bObj) {
		this.bObj = bObj;
	}
	public Integer getIntObj() {
		return intObj;
	}
	public void setIntObj(Integer intObj) {
		this.intObj = intObj;
	}
	public Short getShortObj() {
		return shortObj;
	}
	public void setShortObj(Short shortObj) {
		this.shortObj = shortObj;
	}
	public Double getDoubleObj() {
		return doubleObj;
	}
	public void setDoubleObj(Double doubleObj) {
		this.doubleObj = doubleObj;
	}
	public Long getLongObj() {
		return longObj;
	}
	public void setLongObj(Long longObj) {
		this.longObj = longObj;
	}
	public Float getFloatObj() {
		return floatObj;
	}
	public void setFloatObj(Float floatObj) {
		this.floatObj = floatObj;
	}
	
	
}
