package com.harsh.excel.interfaces;

import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;

import com.harsh.excel.writer.BeanWriter;
import com.harsh.excel.writer.SimpleExcelWriter;

public interface ExcelGenerator {

	public boolean createWorkbook();
	public Workbook getWorkbook();
	public boolean createWorkSheet();
	public boolean createWorkWithName(String name);
	public Sheet getSheetFromName(String sheetName);
	public Sheet getSheetAtIndex(int index);
	public int getNumberOfSheetInworkbook();
	public BeanWriter getBeanWriter();
	public SimpleExcelWriter getDefaultWriter();
}
