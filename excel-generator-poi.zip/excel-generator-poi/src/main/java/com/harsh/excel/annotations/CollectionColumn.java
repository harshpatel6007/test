package com.harsh.excel.annotations;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import com.harsh.excel.formatter.CollectionFormatter;

@Retention(RetentionPolicy.RUNTIME)
@Target({ ElementType.FIELD })
public @interface CollectionColumn {

	public int excelCellType();
	public Class<? extends CollectionFormatter> iteratorClass();
}
