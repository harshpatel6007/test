package com.harsh.excel.annotations;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import com.harsh.excel.formatter.ObjectFormatter;

@Retention(RetentionPolicy.RUNTIME)
@Target({ ElementType.FIELD })
public @interface CustomTypeColumn {

	public int excelCellType();
	@SuppressWarnings("rawtypes")
	public Class<? extends ObjectFormatter> formatter();
}
