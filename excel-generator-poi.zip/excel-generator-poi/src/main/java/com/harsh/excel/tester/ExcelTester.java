package com.harsh.excel.tester;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.poi.ss.usermodel.Sheet;

import com.harsh.excel.impl.ExcelGeneratorImpl;
import com.harsh.excel.interfaces.ExcelGenerator;
import com.harsh.excel.writer.BeanWriter;

public class ExcelTester {

	public static void main(String[] args) {
		List<Employee> empList = new ArrayList<>();
		for(int i = 0; i < 10; i++) {
			Employee employee = new Employee();
			employee.setAge(i);
			employee.setCompanyName("Company - " + i);
			employee.setDateOfJoining(new Date());
			employee.setDateOfLeaving(null);
			employee.setDepartment("Dept - " + i);
			employee.setEmployeeId((long)i);
			employee.setFirstName("First Name " + i);
			employee.setGender(i % 2 == 0 ? Gender.MALE : Gender.FEMALE);
			employee.setLastName("Last Name " + i);
			employee.setMarried((i % 2) == 0);
			employee.setMiddleName("Middle Name " + i);
			List<String> list = new ArrayList<>();
			list.add("Cricket");
			list.add("foos Ball");
			list.add("Table Tennis");
			employee.setHobbies(list);
			empList.add(employee);	
			Address add = new Address();
			add.setHouseNo("A-102");
			add.setStreetName("Uma Sharnam");
			add.setArea("Gota");
			add.setCity("Ahmedabad");
			add.setState("Gujarat");
			add.setCountry("India");
			employee.setAddress(add);
		}
		
		ExcelGenerator excelGenerator = new ExcelGeneratorImpl();
		excelGenerator.createWorkbook();
		excelGenerator.createWorkWithName("Employee Details");
		BeanWriter beanWriter = excelGenerator.getBeanWriter();
		Sheet sheet = excelGenerator.getSheetFromName("Employee Details");
		beanWriter.createHeaderRow(sheet, empList.get(0));
		beanWriter.createRowFromObject(sheet, empList.get(0));
		beanWriter.createRowsFromCollection(sheet, empList);
		
		beanWriter.createEmptyRow(sheet);
		
		beanWriter.createHeaderRow(sheet, empList.get(0));
		beanWriter.createRowFromObject(sheet, empList.get(0));
		beanWriter.createRowsFromCollection(sheet, empList);
		System.out.println("sheet completed"
				+ " " + empList.get(0));
		
		
		try {
			FileOutputStream out = new FileOutputStream(new File("E:/java/excel-util/excels/employee.xlsx"));
			excelGenerator.getWorkbook().write(out);
			out.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
