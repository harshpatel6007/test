package com.harsh.excel.writer;

import java.lang.reflect.Field;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.xssf.usermodel.XSSFFont;

import com.harsh.excel.annotations.Column;
import com.harsh.excel.annotations.Header;
import com.harsh.excel.interfaces.ExcelWriter;

public abstract class AbstractExcelHeaderWriter implements ExcelWriter {

	@Override
	public int getNextRowCount(Sheet sheet) {
		return sheet.getPhysicalNumberOfRows();
	}
	
	@Override
	public <T> void createHeaderRow(Sheet sheet, T t) {
		if (t.getClass().isAnnotationPresent(Header.class)) {
			Header header = t.getClass().getAnnotation(Header.class);
			createHeaderUsingAnnotation(header, sheet);
		} else {
			createHeaderUsingClass(t.getClass(), sheet);
		}
	}
	
	private <T> void createHeaderUsingClass(Class<T> klass, Sheet sheet) {

		Row row = sheet.createRow(getNextRowCount(sheet));

		int i = 0;
		for (Field field : klass.getDeclaredFields()) {
			Cell cell = row.createCell(i);
			cell.setCellStyle(getHeaderStyle(sheet, 12));
			if(field.isAnnotationPresent(Column.class)) {
				Column column = field.getAnnotation(Column.class);
				cell.setCellValue(column.name());
			} else {
				cell.setCellValue(field.getName());
			}			
			sheet.setColumnWidth(i, 5000);
			i++;
		}

	}

	private void createHeaderUsingAnnotation(Header header, Sheet sheet) {

		Row row = sheet.createRow(getNextRowCount(sheet));
		
		int i = 0;
		for (String str : header.heading()) {
			Cell cell = row.createCell(i);
			cell.setCellStyle(getHeaderStyle(sheet, 12));
			cell.setCellValue(str);
			sheet.setColumnWidth(i, 5000);
			i++;
		}

	}

	public static CellStyle getHeaderStyle(Sheet sheet, int fontSize) {
		
		CellStyle cellStyle = sheet.getWorkbook().createCellStyle();
		cellStyle = sheet.getWorkbook().createCellStyle();
		Font font = sheet.getWorkbook().createFont();
		font.setFontName(XSSFFont.DEFAULT_FONT_NAME);
		font.setFontHeightInPoints((short) fontSize);
		font.setBoldweight(XSSFFont.BOLDWEIGHT_BOLD);
		font.setColor(IndexedColors.BLACK.index);
		cellStyle.setFont(font);
		cellStyle.setAlignment(CellStyle.ALIGN_CENTER);
		cellStyle.setBorderBottom(CellStyle.BORDER_THIN);
		cellStyle.setBorderLeft(CellStyle.BORDER_THIN);
		cellStyle.setBorderRight(CellStyle.BORDER_THIN);
		cellStyle.setBorderTop(CellStyle.BORDER_THIN);
		return cellStyle;
	}
	
	
}
