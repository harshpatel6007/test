package com.harsh.excel.utils;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import org.apache.poi.ss.usermodel.Cell;

public class ReflectionUtils {

	private static List<String> primitiveNumericTypes = Arrays.asList("double", "long", "float", "int", "byte", "short");
	private static final String JAVA_IMPL_TITLE = "Java Runtime Environment";
	private static final String JAVA_IMPL_VENDOR = "Oracle Corporation";

	public static boolean isNumericField(Field field) {
		if (Number.class.isAssignableFrom(field.getType())) {
			return true;
		}
		if (field.getType().isPrimitive()) {
			if (primitiveNumericTypes.contains(field.getType().getName())) {
				return true;
			}
		}
		return false;
	}

	public static void setNumericCellValue(Cell cell, Object value) {
		if (value instanceof Byte) {
			cell.setCellValue((byte) value);
		} else if (value instanceof Short) {
			cell.setCellValue((short) value);
		} else if (value instanceof Integer) {
			cell.setCellValue((int) value);
		} else if (value instanceof Float) {
			cell.setCellValue((float) value);
		} else if (value instanceof Long) {
			cell.setCellValue((long) value);
		} else if (value instanceof Double) {
			cell.setCellValue((double) value);
		}
	}

	public static <T> Object createObjectFromClass(Class<T> klass) {
		Object object = null;
		try {
			Class<?> clazz = Class.forName(klass.getName());
			object = clazz.newInstance();
		} catch (Exception e) {
			e.printStackTrace();
			throw new IllegalArgumentException("Error Occured during Create Object " + "From Class " + klass.getName());
		}
		return object;
	}

	public static Object getMethodValue(Object classInstance, String methodName, Object fieldValue) {
		Object objValue = null;
		try {
			//use this logic because Class#getMethod(class, args) not working for generic types like collection etc. 
			for(Method method : classInstance.getClass().getDeclaredMethods()) {
				if(method.getName().equals(methodName)) {
					objValue = method.invoke(classInstance, fieldValue);
				}
			}
		} catch (IllegalAccessException | IllegalArgumentException | InvocationTargetException e) {
			System.out.println("Error Occurred during invoke " + methodName + " on class " + classInstance.getClass().getName());
			e.printStackTrace();
		} catch (SecurityException e) {
			System.out.println("Not able to invoke " + methodName + " on class " + classInstance.getClass().getName());
			e.printStackTrace();
		}
		return objValue;
	}
	
	public static <T> boolean isJavaClass(Class<T> klass) {
		if(klass.isPrimitive()){
			return true;
		}
		if(klass.getPackage() != null) {
			if(klass.getPackage().getImplementationTitle() != null 
					&& klass.getPackage().getImplementationTitle().equals(JAVA_IMPL_TITLE) 
					&& klass.getPackage().getImplementationVendor() != null 
					&& klass.getPackage().getImplementationVendor().equals(JAVA_IMPL_VENDOR)) {
				return true;
			}
		}
		return false;
	}

	public static boolean isStringField(Field field) {
		if(field.getType().isAssignableFrom(String.class) 
				|| field.getType().isAssignableFrom(Character.class)
				|| field.getType().getName().equals("char")) {
			return true;
		}
		return false;
	}

	public static boolean isBooleanField(Field field) {	
		return Boolean.class.isAssignableFrom(field.getType()) || field.getType().getName().equals("boolean");
	}

	public static boolean isDateField(Field field) {
		return field.getType().isAssignableFrom(Date.class);
	}
}
