package com.harsh.excel.tester;

import java.util.Date;
import java.util.List;

import org.apache.poi.ss.usermodel.Cell;

import com.harsh.excel.annotations.CollectionColumn;
import com.harsh.excel.annotations.Column;
import com.harsh.excel.annotations.CustomTypeColumn;
import com.harsh.excel.annotations.DateColumn;
import com.harsh.excel.annotations.IgnoreDefaultValue;
import com.harsh.excel.formatter.impl.AddressFormatter;
import com.harsh.excel.formatter.impl.DOLFormatter;
import com.harsh.excel.formatter.impl.HobbiesFormatter;

//@Header(heading={"First Name", "Middle Name", "Last Name", "Employee Id", "Company Name", "Age", "Married", 
//		"Gender", "Date Of Joining", "Date Of Leaving", "Department", "Hobbies"})
public class Employee {

	@Column(name = "First Name")
	private String firstName;
	@Column(name = "Middle Name")
	private String middleName;
	@Column(name = "Last Name")
	private String lastName;
	@Column(name = "Employee Id")
	private Long employeeId;
	@Column(name = "Company")
	private String companyName;
	@Column(name = "Age")
	private int age;
	@Column(name = "Married")
	private boolean married;
	@Column(name = "Gender")
	private Gender gender;
	@Column(name = "Date Of Joining")
	private Date dateOfJoining;
	@Column(name = "Date Of Leaving")
	@DateColumn(dateFormatter=DOLFormatter.class)
	@IgnoreDefaultValue
	private Date dateOfLeaving;
	@Column(name = "Department")
	private String department;
	@Column(name = "Hobbies")
	@CollectionColumn(excelCellType=Cell.CELL_TYPE_STRING, iteratorClass=HobbiesFormatter.class)
	private List<String> hobbies;
	@Column(name = "Address")
	@CustomTypeColumn(excelCellType=Cell.CELL_TYPE_STRING, formatter=AddressFormatter.class)
	private Address address;
	
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getMiddleName() {
		return middleName;
	}
	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public Long getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(Long employeeId) {
		this.employeeId = employeeId;
	}
	public String getCompanyName() {
		return companyName;
	}
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public boolean isMarried() {
		return married;
	}
	public void setMarried(boolean married) {
		this.married = married;
	}
	public Gender getGender() {
		return gender;
	}
	public void setGender(Gender gender) {
		this.gender = gender;
	}
	public Date getDateOfJoining() {
		return dateOfJoining;
	}
	public void setDateOfJoining(Date dateOfJoining) {
		this.dateOfJoining = dateOfJoining;
	}
	public Date getDateOfLeaving() {
		return dateOfLeaving;
	}
	public void setDateOfLeaving(Date dateOfLeaving) {
		this.dateOfLeaving = dateOfLeaving;
	}
	public String getDepartment() {
		return department;
	}
	public void setDepartment(String department) {
		this.department = department;
	}
	public List<String> getHobbies() {
		return hobbies;
	}
	public void setHobbies(List<String> hobbies) {
		this.hobbies = hobbies;
	}
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}
	
	@Override
	public String toString() {
		return "Employee [firstName=" + firstName + ", middleName=" + middleName + ", lastName=" + lastName
				+ ", employeeId=" + employeeId + ", companyName=" + companyName + ", age=" + age + ", married="
				+ married + ", gender=" + gender + ", dateOfJoining=" + dateOfJoining + ", dateOfLeaving="
				+ dateOfLeaving + ", department=" + department + ", hobbies=" + hobbies + ", address=" + address + "]";
	}
	
}
