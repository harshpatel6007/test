package com.harsh.excel.formatter;

import java.util.Collection;

public interface CollectionFormatter {

	public <T> String format(Collection<T> t);
}
