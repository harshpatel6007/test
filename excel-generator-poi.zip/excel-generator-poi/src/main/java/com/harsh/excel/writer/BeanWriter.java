package com.harsh.excel.writer;

import java.lang.reflect.Field;
import java.util.Arrays;
import java.util.Collection;
import java.util.Date;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.xssf.usermodel.XSSFCell;

import com.harsh.excel.annotations.CollectionColumn;
import com.harsh.excel.annotations.CustomTypeColumn;
import com.harsh.excel.annotations.DateColumn;
import com.harsh.excel.annotations.ExcelIgnore;
import com.harsh.excel.annotations.IgnoreDefaultValue;
import com.harsh.excel.formatter.CollectionFormatter;
import com.harsh.excel.formatter.DateFormatter;
import com.harsh.excel.formatter.ObjectFormatter;
import com.harsh.excel.formatter.impl.DefaultCollectionFormatter;
import com.harsh.excel.interfaces.ExcelWriter;
import com.harsh.excel.utils.DateUtils;
import com.harsh.excel.utils.ReflectionUtils;

public class BeanWriter extends AbstractExcelHeaderWriter implements ExcelWriter {

	@Override
	public <T> void createRowsFromCollection(Sheet sheet, Collection<T> collection) {
		collection.stream().forEach(t -> createRowFromObject(sheet, t));
	}
	
	@Override
	public <T> void createRowFromObject(Sheet sheet, T t) {

		Row row = sheet.createRow(getNextRowCount(sheet));

		int i = 0;
		
		for (Field field : t.getClass().getDeclaredFields()) {
			
			if(field.getClass().isAnnotationPresent(ExcelIgnore.class)) {
				continue;
			}
			
			Object value = null;
			field.setAccessible(true);
			try {
				value = field.get(t);
			} catch (IllegalArgumentException | IllegalAccessException e) {
				System.out.println("error occured during read value for field : " + field.getName());
				e.printStackTrace();
			}
			Cell cell = row.createCell(i);
			insertValueInCell(field, value, cell);
			i++;
		}

	}
	
	public void createEmptyRow(Sheet sheet) {
		sheet.createRow(getNextRowCount(sheet));
	}

	private void insertValueInCell(Field field, Object value, Cell cell) {
		
		if (value != null || field.isAnnotationPresent(IgnoreDefaultValue.class)) {
			
			if(field.getType().isEnum()) {
				setEnumValue(cell, field, value);
			} else if (ReflectionUtils.isStringField(field)) {
				setStringCellValue(cell, value);
			} else if (ReflectionUtils.isBooleanField(field)) {
				setBooleanCellValue(cell, value);
			} else if (ReflectionUtils.isNumericField(field)) {
				setNumericValue(cell, value);
			} else if (ReflectionUtils.isDateField(field)) {
				setDateValue(cell, field, value);
			} else if (Collection.class.isAssignableFrom(field.getType())) {
				setCollectionValue(cell, field, value);
			} else if(!Arrays.asList(Cell.CELL_TYPE_BOOLEAN, Cell.CELL_TYPE_NUMERIC, Cell.CELL_TYPE_STRING).contains(cell.getCellType())
					&& !ReflectionUtils.isJavaClass(field.getType())) {
				setCustomCellValue(cell, field, value);
			} else {
				System.out.println("Its Strange !!, Note able to identify field type");
			}
		} else {
			cell.setCellValue("-");
		}

	}

	private void setCustomCellValue(Cell cell, Field field, Object value) {
		if(field.isAnnotationPresent(CustomTypeColumn.class)) {
			CustomTypeColumn customTypeColumn = field.getAnnotation(CustomTypeColumn.class);
			cell.setCellType(customTypeColumn.excelCellType());
			Object objectFormatter = ReflectionUtils.createObjectFromClass(customTypeColumn.formatter());
			Object objValue = ReflectionUtils.getMethodValue(objectFormatter, ObjectFormatter.class.getDeclaredMethods()[0].getName(),
					value);
			setCellValueAccordingToCellType(cell, customTypeColumn.excelCellType(), objValue);
		}
	}

	private void setCellValueAccordingToCellType(Cell cell, int cellType, Object objValue) {
		switch (cellType) {
			case Cell.CELL_TYPE_BOOLEAN:
				cell.setCellValue((boolean)objValue);
				break;
			case Cell.CELL_TYPE_NUMERIC:
				ReflectionUtils.setNumericCellValue(cell, objValue);
				break;
			case Cell.CELL_TYPE_STRING:
				cell.setCellValue((String)objValue);
				break;
			default:
				break;
		}
	}

	private void setStringCellValue(Cell cell, Object value) {
		cell.setCellType(XSSFCell.CELL_TYPE_STRING);
		cell.setCellValue((String) value);
	}

	private void setBooleanCellValue(Cell cell, Object value) {
		cell.setCellType(XSSFCell.CELL_TYPE_BOOLEAN);
		Boolean bool = (Boolean) value;
		cell.setCellValue(bool == null ? false : bool.booleanValue());
	}

	private void setNumericValue(Cell cell, Object value) {
		cell.setCellType(XSSFCell.CELL_TYPE_NUMERIC);
		ReflectionUtils.setNumericCellValue(cell, value);
	}

	private void setDateValue(Cell cell, Field field, Object value) {
		if (field.isAnnotationPresent(DateColumn.class)) {
			Object stringDate = getDateFromAnnotation(field, value);
			cell.setCellType(XSSFCell.CELL_TYPE_STRING);
			cell.setCellValue((String) stringDate);
		} else if (value instanceof Long) {
			Date date = new Date((long) value);
			cell.setCellType(XSSFCell.CELL_TYPE_STRING);
			cell.setCellValue(DateUtils.getDefaultDateTimeFormat(date));
		} else {
			Date date = (Date) value;
			cell.setCellType(XSSFCell.CELL_TYPE_STRING);
			cell.setCellValue(DateUtils.getDefaultDateFormat(date));
		}
	}

	private void setEnumValue(Cell cell, Field field, Object value) {
		cell.setCellType(XSSFCell.CELL_TYPE_STRING);
		for(Object enumConstant : field.getType().getEnumConstants()) {
			if(enumConstant.equals(value)) {
				cell.setCellValue(value.toString());
				break;
			}
		}
	}

	private void setCollectionValue(Cell cell, Field field, Object value) {
		Object collectionIterator = null;
		int cellType = Cell.CELL_TYPE_STRING;
		if(field.isAnnotationPresent(CollectionColumn.class)) {
			CollectionColumn collectionColumn = field.getAnnotation(CollectionColumn.class);
			collectionIterator = ReflectionUtils.createObjectFromClass(collectionColumn.iteratorClass());
			cellType = collectionColumn.excelCellType();
		} else {
			collectionIterator = ReflectionUtils.createObjectFromClass(DefaultCollectionFormatter.class);
		}
		Object collectionValue = ReflectionUtils.getMethodValue(collectionIterator, CollectionFormatter.class.getDeclaredMethods()[0].getName(),
				value);
		cell.setCellType(cellType);
		setCellValueAccordingToCellType(cell, cellType, collectionValue);
	}

	private Object getDateFromAnnotation(Field field, Object value) {
		DateColumn dateColumn = field.getAnnotation(DateColumn.class);
		Object dateFormatter = ReflectionUtils.createObjectFromClass(dateColumn.dateFormatter());
		return ReflectionUtils.getMethodValue(dateFormatter, DateFormatter.class.getDeclaredMethods()[0].getName(),
				value);
	}
	
}
