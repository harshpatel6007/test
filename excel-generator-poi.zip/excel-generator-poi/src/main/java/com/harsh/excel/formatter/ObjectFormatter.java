package com.harsh.excel.formatter;

public interface ObjectFormatter<T, V> {

	public V format(T t);
}
