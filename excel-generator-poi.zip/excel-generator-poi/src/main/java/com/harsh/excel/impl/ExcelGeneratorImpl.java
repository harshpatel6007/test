package com.harsh.excel.impl;

import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.harsh.excel.interfaces.ExcelGenerator;
import com.harsh.excel.writer.BeanWriter;
import com.harsh.excel.writer.SimpleExcelWriter;

public class ExcelGeneratorImpl implements ExcelGenerator {

	private Workbook workbook;
	private BeanWriter beanWriter;
	private SimpleExcelWriter defaultWriter;
	
	@Override
	public boolean createWorkbook() {
		if(workbook != null) {
			return false; 
		}
		workbook = new XSSFWorkbook();
		return true;
	}
	
	@Override
	public Workbook getWorkbook() {	
		return workbook;
	}	

	@Override
	public boolean createWorkSheet() {
		assert workbook != null;
		workbook.createSheet();
		return true;
	}
	

	@Override
	public boolean createWorkWithName(String sheetName) {
		assert workbook != null;
		workbook.createSheet(sheetName);
		return true;
	}

	@Override
	public Sheet getSheetFromName(String sheetName) {
		assert workbook != null;
		return workbook.getSheet(sheetName);
	}

	@Override
	public Sheet getSheetAtIndex(int index) {
		assert workbook != null;
		return workbook.getSheetAt(index);
	}

	@Override
	public int getNumberOfSheetInworkbook() {
		assert workbook != null;
		return workbook.getNumberOfSheets();
	}

	@Override
	public BeanWriter getBeanWriter() {
		assert workbook != null;
		if(beanWriter == null) {
			beanWriter = new BeanWriter();
		}
		return beanWriter;
	}

	@Override
	public SimpleExcelWriter getDefaultWriter() {
		assert workbook != null;
		if(defaultWriter == null) {
			defaultWriter = new SimpleExcelWriter();
		}
		return defaultWriter;
	}

}
