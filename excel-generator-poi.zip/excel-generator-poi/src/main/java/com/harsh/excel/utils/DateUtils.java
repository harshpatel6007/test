package com.harsh.excel.utils;

import java.text.SimpleDateFormat;
import java.util.Date;

public class DateUtils {

	private static final String DEFAULT_DATE_FORMAT = "dd/MM/YYYY";
	private static final String DEFAULT_DATE_TIME_FORMAT = "dd/MM/YYYY HH:mm";
	
	public static String getDefaultDateTimeFormat(Date date) {
		SimpleDateFormat dateFormat = new SimpleDateFormat(DEFAULT_DATE_TIME_FORMAT);
		return dateFormat.format(date);
	}
	
	public static String getDefaultDateFormat(Date date) {
		SimpleDateFormat dateFormat = new SimpleDateFormat(DEFAULT_DATE_FORMAT);
		return dateFormat.format(date);
	}
}
