package com.fn.challenge.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fn.challenge.enums.UserType;
import com.fn.challenge.model.Coupon;
import com.fn.challenge.repository.CouponRepository;
import com.fn.challenge.service.DiscountService;

@Service
public class DiscountServiceImpl implements DiscountService {

	@Autowired
	CouponRepository couponRepository;
	
	/* (non-Javadoc)
	 * @see com.fn.challenge.service.DiscountService#calculateDiscount(com.fn.challenge.enums.UserType, java.lang.Double)
	 */
	@Override
	public Double calculateDiscount(UserType userType, Double amount) {
		List<Coupon> coupons = couponRepository.getCouponApplicableOnUserTypeAndAmount(userType, amount);
		Double discount = 0.0;
		for(Coupon coupon : coupons) {
			discount += getDiscountFromCoupon(coupon, amount);
			System.out.println("Calculate Discount on coupon : " + coupon + ", discount : " + discount);
		}
		return discount;
	}

	/**
	 * calculate discount applied on given amount for given coupon
	 * 
	 * @param coupon
	 * @param amount
	 * @return
	 */
	private Double getDiscountFromCoupon(Coupon coupon, Double amount) {
		Double applicableAmtForDiscount = getAmountApplicableForDiscount(coupon, amount);
		return applicableAmtForDiscount * coupon.getDiscountPercent() / 100.0;
	}

	/**
	 * Get amount applicable for discount
	 * 
	 * @param coupon
	 * @param amount
	 * @return
	 */
	private Double getAmountApplicableForDiscount(Coupon coupon, Double amount) {
		if(amount > coupon.getEndAmount()) {
			return coupon.getEndAmount() - coupon.getStartAmount();
		}
		return amount - coupon.getStartAmount();
	}

}
