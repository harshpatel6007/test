package com.fn.challenge.repository.impl;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

import javax.annotation.PostConstruct;

import org.springframework.stereotype.Repository;

import com.fn.challenge.enums.UserType;
import com.fn.challenge.model.Coupon;
import com.fn.challenge.repository.CouponRepository;
import com.fn.challenge.util.CouponImporter;

@Repository
public class CouponRepositoryImpl implements CouponRepository {

private List<Coupon> coupons;
	
	/**
	 * Import coupons from file
	 */
	@PostConstruct
	private void importCoupons() {
		System.out.println("Import discount Coupons");
		String filePath = "Discount.csv";
		try {
			coupons = CouponImporter.importCouponsFromFile(filePath);
		} catch (IOException e) {
			System.err.println("Something Wrong with Input File, Message : " + e.getMessage());
			e.printStackTrace();
		}
		System.out.println(coupons);
	}
	
	
	/* (non-Javadoc)
	 * @see com.fn.challenge.repository.CouponRepository#getCouponByUserType(com.fn.challenge.enums.UserType)
	 */
	@Override
	public List<Coupon> getCouponByUserType(UserType userType) {
		return coupons.stream().filter(coupon -> coupon.getUserType() == userType).collect(Collectors.toList());
	}


	/* (non-Javadoc)
	 * @see com.fn.challenge.repository.CouponRepository#getCouponApplicableOnUserTypeAndAmount(com.fn.challenge.enums.UserType, java.lang.Double)
	 */
	@Override
	public List<Coupon> getCouponApplicableOnUserTypeAndAmount(UserType userType, Double amount) {
		List<Coupon> applicableCoupons = new ArrayList<Coupon>();
		
		List<Coupon> couponList = getCouponByUserType(userType);
		Collections.sort(couponList);//sort coupons based on amount
		
		System.out.println("applicable coupons on user type : " + couponList);
		
		for(Coupon coupon : couponList) {
			if( amount > coupon.getEndAmount() || (amount > coupon.getStartAmount() && amount <= coupon.getEndAmount()) ) {
				applicableCoupons.add(coupon);
			}
		}
		
		return applicableCoupons;
	}

}
