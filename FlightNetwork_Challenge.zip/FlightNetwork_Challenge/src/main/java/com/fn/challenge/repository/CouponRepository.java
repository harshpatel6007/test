package com.fn.challenge.repository;

import java.util.List;

import com.fn.challenge.enums.UserType;
import com.fn.challenge.model.Coupon;

public interface CouponRepository {

	/**
	 * Search coupons by {@link UserType}
	 * 
	 * @param userType
	 * @return
	 */
	List<Coupon> getCouponByUserType(UserType userType);

	/**
	 * Get coupons applicable on given Amount. 
	 * 
	 * @param amount
	 * @return
	 */
	List<Coupon> getCouponApplicableOnUserTypeAndAmount(UserType userType, Double amount);
}
