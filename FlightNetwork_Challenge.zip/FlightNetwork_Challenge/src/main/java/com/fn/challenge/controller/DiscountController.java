package com.fn.challenge.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.fn.challenge.enums.UserType;
import com.fn.challenge.service.DiscountService;

/**
 * Main controller responsible for REST.
 *
 */
@RestController
public class DiscountController {

	private static final String AMOUNT_CAN_NOT_BE_LESS_THAN_0 = "Amount can not be less than 0";
	private static final String INVALID_USER_TYPE = "Invalid user type";
	
	@Autowired
	private DiscountService discountService;
	
	@GetMapping("/discount/{userType}/{amount}")
	@ResponseBody
	public String getPriceAfterDiscount(@PathVariable String userType, @PathVariable Double amount) {
		
		System.out.println("User type : " + userType + " Amount : " + amount);
		
		if(amount < 0) {
			return AMOUNT_CAN_NOT_BE_LESS_THAN_0;
		}
		
		try {
			UserType.valueOf(userType);
		} catch(RuntimeException e) {
			return INVALID_USER_TYPE;
		}
		
		Double discount = discountService.calculateDiscount(UserType.valueOf(userType), amount);
		return "Discounted amount is : " + (amount - discount) ;
	}
}
