package com.fn.challenge.service;

import com.fn.challenge.enums.UserType;

public interface DiscountService {

	/**
	 * Calculate final discount on given expense.
	 * 
	 * @param userExpense
	 * @return
	 */
	public Double calculateDiscount(UserType userType, Double amount);
}
