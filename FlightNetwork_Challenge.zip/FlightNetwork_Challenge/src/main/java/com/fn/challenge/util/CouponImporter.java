package com.fn.challenge.util;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import com.fn.challenge.enums.UserType;
import com.fn.challenge.model.Coupon;

public class CouponImporter {

	private static final String COMMA = ",";

	/**
	 * Read file at given location and import Coupon data
	 * 
	 * @param filePath
	 * @return
	 * @throws IOException 
	 */
	public static List<Coupon> importCouponsFromFile(String filePath) throws IOException {
		List<Coupon> coupons = new ArrayList<Coupon>();
		
		File file = getFile(filePath);
		String line;
		BufferedReader reader = null;
		try {
			reader = new BufferedReader(new FileReader(file));
			reader.readLine();//skip first line
			while((line = reader.readLine()) != null) {
				Coupon coupon = parseLine(line);
				coupons.add(coupon);
			}
		} catch (FileNotFoundException e) {
			//Should not happen
			e.printStackTrace();
			throw e;
		} catch (IOException e) {
			//Should not happen
			e.printStackTrace();
			throw e;
		} catch (RuntimeException e) {
			throw new IllegalArgumentException(e.getMessage());
		} 
		
		finally {
			try {
				if(reader != null) {
					reader.close();
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		return coupons;
		
	}

	/**
	 * Convert line into {@link Coupon} model </br>
	 * Note : Since the input file is already given did not perform validation here
	 * 
	 * @param line
	 * @return
	 */
	private static Coupon parseLine(String line) {
		String[] array = line.split(COMMA);
		
		doBasicValidation(array, line);
		
		Coupon coupon = new Coupon();
		coupon.setUserType(UserType.valueOf(array[0]));
		coupon.setStartAmount(Double.parseDouble(array[1]));
		coupon.setEndAmount(Double.parseDouble(array[2]));
		coupon.setDiscountPercent(Double.parseDouble(array[3]));
		
		return coupon;
	}

	private static void doBasicValidation(String[] array, String line) {
		if(array.length < 4) {
			throw new IllegalArgumentException("Input is not valid, please correct line : " + line);
		}
		
		if(Double.parseDouble(array[1]) < 0 || Double.parseDouble(array[2]) < 0 || Double.parseDouble(array[3]) < 0) {
			throw new IllegalArgumentException("Coupon start or end amount or disscount can not be negative"
					+ ", please correct line : " + line);
		}

		if(Double.parseDouble(array[1]) > Double.parseDouble(array[2])) {
			throw  new IllegalArgumentException("Coupon's Start Amount can not be greater than end amount"
					+ ", please correct line : " + line);
		}
	}

	/**
	 * Validate file path and return file object
	 * 
	 * @param filePath
	 * @return
	 */
	private static File getFile(String filePath) {
		
		if(!filePath.toLowerCase().endsWith(".csv")) {
			throw new IllegalArgumentException("File extension is not csv");
		}
		File file = new File(filePath);
		if(!file.exists()) {
			throw new IllegalArgumentException("File path : " + filePath + " Not exists");
		}
		return file;
	}
}
