package com.fn.challenge.enums;

public enum UserType {
	Standard, Premium;
}
