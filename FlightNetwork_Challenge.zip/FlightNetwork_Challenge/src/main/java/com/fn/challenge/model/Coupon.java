package com.fn.challenge.model;

import com.fn.challenge.enums.UserType;

/**
 * POJO Represent Discount Slab
 */
public class Coupon implements Comparable<Coupon>{

	private UserType userType;
	private Double startAmount;
	private Double endAmount;
	private Double discountPercent;
	
	public UserType getUserType() {
		return userType;
	}
	public void setUserType(UserType userType) {
		this.userType = userType;
	}
	public Double getStartAmount() {
		return startAmount;
	}
	public void setStartAmount(Double startAmount) {
		this.startAmount = startAmount;
	}
	public Double getEndAmount() {
		return endAmount;
	}
	public void setEndAmount(Double endAmount) {
		this.endAmount = endAmount;
	}
	public Double getDiscountPercent() {
		return discountPercent;
	}
	public void setDiscountPercent(Double discountPercent) {
		this.discountPercent = discountPercent;
	}

	@Override
	public int compareTo(Coupon o) {
		return this.getStartAmount().compareTo(o.getStartAmount());
	}

	@Override
	public String toString() {
		return "Coupon [userType=" + userType + ", startAmount=" + startAmount + ", endAmount=" + endAmount
				+ ", discountPercent=" + discountPercent + "]";
	}
}
