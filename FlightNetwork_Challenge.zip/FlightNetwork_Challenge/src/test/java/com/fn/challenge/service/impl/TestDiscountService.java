package com.fn.challenge.service.impl;

import static org.junit.Assert.assertTrue;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.fn.challenge.enums.UserType;
import com.fn.challenge.service.DiscountService;

@RunWith(SpringRunner.class)
@SpringBootTest
public class TestDiscountService {

	@Autowired
	private DiscountService discountService;
	
	@Test
	public void test_Zero_discount() {
		assertTrue(discountService.calculateDiscount(UserType.Premium, 0.0) == 0.0);
	}
	
	@Test
	public void test_Discount_with_single_coupon() {
		assertTrue(discountService.calculateDiscount(UserType.Premium, 600.0) == 10);
	}
	
	@Test
	public void test_Discount_with_multiple_coupon() {
		assertTrue(discountService.calculateDiscount(UserType.Premium, 6000.0) == 1000.0);
	}
	
	@Test
	public void test_Discount_with_boundary_amount() {
		assertTrue(discountService.calculateDiscount(UserType.Premium, 3000.0) == 350.0);
	}
}
