package com.fn.challenge.service.util;

import static org.junit.Assert.assertTrue;

import java.io.File;
import java.io.IOException;

import org.junit.Test;

import com.fn.challenge.util.CouponImporter;

public class TestCouponImporter {

	@Test(expected = IllegalArgumentException.class)
	public void test_wrong_path() throws IOException {
		CouponImporter.importCouponsFromFile("Test.csv");
	}
	
	@Test
	public void test_invalid_file() throws IOException {
		File f = new File("Invalid_Input.csv");
		if(!f.exists()) {
			f.createNewFile();
		}
		assertTrue(CouponImporter.importCouponsFromFile(f.getPath()).isEmpty());
	}
	
	@Test(expected = IllegalArgumentException.class)
	public void test_invalid_file_format() throws IOException {
		CouponImporter.importCouponsFromFile("Test.xml");
	}
	
//	@Test(expected = IllegalArgumentException.class)
//	public void test_negative_end_amount() throws IOException {
//		CouponImporter.importCouponsFromFile("Negative_Value.csv");
//	}
//	
//	@Test(expected = IllegalArgumentException.class)
//	public void test_wrong_start_and_end_amount() throws IOException {
//		CouponImporter.importCouponsFromFile("Wrong_Amount.csv");
//	}
//	
//	@Test(expected = IllegalArgumentException.class)
//	public void test_without_percentage() throws IOException {
//		CouponImporter.importCouponsFromFile("Without_Discount_Percentage.csv");
//	}
	
	@Test
	public void test_valid_data() throws IOException {
		assertTrue(CouponImporter.importCouponsFromFile("Discount.csv").size() == 7);
	}
}
