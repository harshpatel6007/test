package com.fn.challenge.repository.impl;

import static org.junit.Assert.assertTrue;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.fn.challenge.enums.UserType;
import com.fn.challenge.repository.CouponRepository;

@RunWith(SpringRunner.class)
@SpringBootTest
public class TestCouponRepository {

	@Autowired
	private CouponRepository couponRepository;
	
	@Test
	public void testGetCouponByUserType_Standard() {
		assertTrue(couponRepository.getCouponByUserType(UserType.Standard).size() == 3);
	}
	
	@Test
	public void testGetCouponByUserType_Premium() {
		assertTrue(couponRepository.getCouponByUserType(UserType.Premium).size() == 4);
	}
	
	@Test
	public void testGetCouponApplicableOnUserTypeAndAmount_Multiple_Coupons() {
		assertTrue(couponRepository.getCouponApplicableOnUserTypeAndAmount(UserType.Premium, 6000.0).size() == 4);
	}
	
	@Test
	public void testGetCouponApplicableOnUserTypeAndAmount_max_Amount() {
		assertTrue(couponRepository.getCouponApplicableOnUserTypeAndAmount(UserType.Premium, Double.MAX_VALUE).size() == 4);
	}
	
	@Test
	public void testGetCouponApplicableOnUserTypeAndAmount_min_Amount() {
		assertTrue(couponRepository.getCouponApplicableOnUserTypeAndAmount(UserType.Premium, Double.MIN_VALUE).size() == 0);
	}
	
	@Test
	public void testGetCouponApplicableOnUserTypeAndAmount_Lowest_Amount() {
		assertTrue(couponRepository.getCouponApplicableOnUserTypeAndAmount(UserType.Premium, 200.0).isEmpty());
	}
}
