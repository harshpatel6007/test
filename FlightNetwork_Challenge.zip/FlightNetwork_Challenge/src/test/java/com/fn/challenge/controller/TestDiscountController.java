package com.fn.challenge.controller;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.fn.challenge.enums.UserType;

@RunWith(SpringRunner.class)
@SpringBootTest
public class TestDiscountController {

	private static final String AMOUNT_CAN_NOT_BE_LESS_THAN_0 = "Amount can not be less than 0";
	private static final String INVALID_USER_TYPE = "Invalid user type";
	
	@Autowired
	DiscountController discountController;
	
	@Test
	public void testInvalidUserType() {
		String result = discountController.getPriceAfterDiscount("xyz", 124563.0);
		assertEquals(INVALID_USER_TYPE, result);
	}
	
	@Test
	public void testInvalidAmount() {
		String result = discountController.getPriceAfterDiscount(UserType.Standard.name(), -100.0);
		assertEquals(AMOUNT_CAN_NOT_BE_LESS_THAN_0, result);
	}
	
	@Test
	public void testValidStandardExpense() {
		String result = discountController.getPriceAfterDiscount(UserType.Standard.name(), 2000.0);
		assertTrue(result.contains("1900"));
	}
	
	@Test
	public void testValidPremiumExpenseWithMultipleCoupons() {
		String result = discountController.getPriceAfterDiscount(UserType.Premium.name(), 6000.0);
		assertTrue(result.contains("5000"));
	}
}
