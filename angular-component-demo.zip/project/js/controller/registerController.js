myAppControllers.controller('registerCtrl', function ($scope) {
    $scope.message = "Welcome to registration Page";
});