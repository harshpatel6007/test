package com.thoughtworks.test.challenge2;

import java.util.List;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.StringHttpMessageConverter;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.web.client.RestTemplate;

import com.thoughtworks.test.ch1.model.Input;
import com.thoughtworks.test.ch2.model.Challenge2Input;
import com.thoughtworks.test.ch2.model.Challenge2Output;

public class Challenge2 {

	public static void getInput() {
		RestTemplate restTemplate = new RestTemplate();
        restTemplate.getMessageConverters().add(new MappingJackson2HttpMessageConverter());
        restTemplate.getMessageConverters().add(new StringHttpMessageConverter());
		
        String main = "https://http-hunt.thoughtworks-labs.net/challenge/input";
        HttpHeaders headers = new HttpHeaders();
        headers.set("userId", "wWGhm4SeJ");
        headers.setContentType(MediaType.APPLICATION_JSON);
        
        HttpEntity<Input> entityReq = new HttpEntity<Input>(null, headers);
        
        ResponseEntity<Challenge2Input> respEntity = restTemplate
        	    .exchange(main, HttpMethod.GET, entityReq, Challenge2Input.class);
        
        Challenge2Input input = respEntity.getBody();
        System.out.println(input);
        
        System.out.println("Message : " + input.getHiddenTools() + " tools : " + input.getTools());
        
        List<String> tooldFound = Logic2.getTools(input.getHiddenTools(), input.getTools());
        System.out.println("Founf Tools : " + tooldFound);
        
        sendOutput(tooldFound);
	}
	
	public static void sendOutput(List<String> foundTools) {
		RestTemplate restTemplate = new RestTemplate();
        restTemplate.getMessageConverters().add(new MappingJackson2HttpMessageConverter());
        restTemplate.getMessageConverters().add(new StringHttpMessageConverter());
		
        String main = "https://http-hunt.thoughtworks-labs.net/challenge/output";
        HttpHeaders headers = new HttpHeaders();
        headers.set("userId", "wWGhm4SeJ");
        headers.setContentType(MediaType.APPLICATION_JSON);
        
        Challenge2Output output = new Challenge2Output();
        output.setToolsFound(foundTools);
        HttpEntity<Challenge2Output> entityReq = new HttpEntity<Challenge2Output>(output, headers);
        
        ResponseEntity<String> respEntity = restTemplate
        	    .exchange(main, HttpMethod.POST, entityReq, String.class);
        
        System.out.println("Message : " + respEntity.getBody());
	}

}
