package com.thoughtworks.test.ch3.model;

import java.util.List;

public class Challenge3Output {

	private List<ToolUsage> toolsSortedOnUsage;

	public List<ToolUsage> getToolsSortedOnUsage() {
		return toolsSortedOnUsage;
	}

	public void setToolsSortedOnUsage(List<ToolUsage> toolsSortedOnUsage) {
		this.toolsSortedOnUsage = toolsSortedOnUsage;
	}

	@Override
	public String toString() {
		return "Challenge3Output [toolsSortedOnUsage=" + toolsSortedOnUsage + "]";
	}
	
}
