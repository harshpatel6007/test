package com.thoughtworks.test.ch4.model;

import java.util.List;

public class Challenge4Output {

	private List<String> toolsToTakeSorted;

	public List<String> getToolsToTakeSorted() {
		return toolsToTakeSorted;
	}

	public void setToolsToTakeSorted(List<String> toolsToTakeSorted) {
		this.toolsToTakeSorted = toolsToTakeSorted;
	}

	@Override
	public String toString() {
		return "Challenge4Output [toolsToTakeSorted=" + toolsToTakeSorted + "]";
	}
	
}
