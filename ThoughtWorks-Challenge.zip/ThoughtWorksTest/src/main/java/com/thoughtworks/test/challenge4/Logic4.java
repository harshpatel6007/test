package com.thoughtworks.test.challenge4;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import com.thoughtworks.test.ch4.model.CompositeComparator;
import com.thoughtworks.test.ch4.model.Tool;
import com.thoughtworks.test.ch4.model.ValueComparator;
import com.thoughtworks.test.ch4.model.WeightComparator;

public class Logic4 {

	public static List<String> getToolsToTakeSorted(List<Tool> tools, long maximumWeight) {
		Collections.sort(tools, new CompositeComparator(Arrays.asList(new WeightComparator(), new ValueComparator())));
		System.out.println("Tools : " + tools);
		List<String> result = new ArrayList<>();
		for(Tool tool : tools) {
			if(tool.getWeight() <= maximumWeight) {
				maximumWeight -= tool.getWeight();
				result.add(tool.getName());
			}
		}
		return result;
	}

}
