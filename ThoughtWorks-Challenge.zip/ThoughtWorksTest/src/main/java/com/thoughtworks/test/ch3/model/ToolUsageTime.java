package com.thoughtworks.test.ch3.model;

public class ToolUsageTime {

	private String name;
    private String useStartTime;
    private String useEndTime;
	
    public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getUseStartTime() {
		return useStartTime;
	}
	public void setUseStartTime(String useStartTime) {
		this.useStartTime = useStartTime;
	}
	public String getUseEndTime() {
		return useEndTime;
	}
	public void setUseEndTime(String useEndTime) {
		this.useEndTime = useEndTime;
	}

	@Override
	public String toString() {
		return "ToolUsageTime [name=" + name + ", useStartTime=" + useStartTime + ", useEndTime=" + useEndTime + "]";
	}
    
}
