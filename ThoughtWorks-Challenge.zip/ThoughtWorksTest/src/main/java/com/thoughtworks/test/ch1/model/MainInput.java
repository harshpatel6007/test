package com.thoughtworks.test.ch1.model;

public class MainInput {

	private String stage;
	private String statement;
	private String instructions;
	private SampleInput sampleInput;
	private SampleOutput sampleOutput;
	
	public String getStage() {
		return stage;
	}
	public void setStage(String stage) {
		this.stage = stage;
	}
	public String getStatement() {
		return statement;
	}
	public void setStatement(String statement) {
		this.statement = statement;
	}
	public String getInstructions() {
		return instructions;
	}
	public void setInstructions(String instructions) {
		this.instructions = instructions;
	}
	public SampleInput getSampleInput() {
		return sampleInput;
	}
	public void setSampleInput(SampleInput sampleInput) {
		this.sampleInput = sampleInput;
	}
	public SampleOutput getSampleOutput() {
		return sampleOutput;
	}
	public void setSampleOutput(SampleOutput sampleOutput) {
		this.sampleOutput = sampleOutput;
	}
	@Override
	public String toString() {
		return "MainInput [stage=" + stage + ", statement=" + statement + ", instructions=" + instructions
				+ ", sampleInput=" + sampleInput + ", sampleOutput=" + sampleOutput + "]";
	}
}
