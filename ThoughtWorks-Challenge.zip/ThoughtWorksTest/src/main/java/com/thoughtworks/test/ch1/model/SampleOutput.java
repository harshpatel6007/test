package com.thoughtworks.test.ch1.model;

import com.thoughtworks.test.ch4.model.Challenge4Output;

public class SampleOutput {

	private Challenge4Output output;

	public Challenge4Output getOutput() {
		return output;
	}
	public void setOutput(Challenge4Output output) {
		this.output = output;
	}

	@Override
	public String toString() {
		return "SampleOutput [output=" + output + "]";
	}
	
}
