package com.thoughtworks.test.ch4.model;

import java.util.Comparator;

public class ValueComparator implements Comparator<Tool>{

	@Override
	public int compare(Tool o1, Tool o2) {
		return o1.getValue().compareTo(o2.getValue());
	}

}
