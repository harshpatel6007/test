package com.thoughtworks.test.ch3.model;

import java.util.List;

public class Challenge3Input {

	private List<ToolUsageTime> toolUsage;

	public List<ToolUsageTime> getToolUsage() {
		return toolUsage;
	}

	public void setToolUsage(List<ToolUsageTime> toolUsage) {
		this.toolUsage = toolUsage;
	}

	@Override
	public String toString() {
		return "Challenge3Input [toolUsage=" + toolUsage + "]";
	}
	
	
}
