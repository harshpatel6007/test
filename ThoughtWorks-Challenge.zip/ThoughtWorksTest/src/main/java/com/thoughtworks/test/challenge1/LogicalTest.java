package com.thoughtworks.test.challenge1;

import java.util.HashMap;
import java.util.Map;

public class LogicalTest {

	private static Map<Integer, Character> map = new HashMap<>();
	private static Map<Character, Integer> reverseMap = new HashMap<>();
	
	static {
		for(int i = 1; i <= 26; i++) {
			map.put(i, new Character((char)(i + 64)));
			reverseMap.put(new Character((char)(i + 64)), i);
		}
	}
	
	public static void main(String[] args) {
		//A FAMOUS EXPLORER ONCE SAID, THAT THE EXTRAORDINARY IS IN WHAT WE DO, NOT WHO WE ARE. GO EXPLORE!
		String input = "F KFRTZX JCUQTWJW TSHJ XFNI, YMFY YMJ JCYWFTWINSFWD NX NS BMFY BJ IT, STY BMT BJ FWJ. LT JCUQTWJ!";
		int key = 5;
		
		decryptString(input, key);
	}

	public static String decryptString(String input, int key) {
		char[] inputArr = input.toCharArray();
		for(int i = 0; i < inputArr.length; i++) {
			Character ch = inputArr[i];
			if(Character.isLetter(ch)) {
				int count = reverseMap.get(ch);
				if(count > key) {
					inputArr[i] = map.get(count - key);
				} else {
					inputArr[i] = map.get(26 - (key - count));
				} 
			}
		}
		return new String(inputArr); 
	}
}
