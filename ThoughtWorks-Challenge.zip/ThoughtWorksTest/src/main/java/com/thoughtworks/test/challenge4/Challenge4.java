package com.thoughtworks.test.challenge4;

import java.util.Arrays;
import java.util.List;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.StringHttpMessageConverter;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.web.client.RestTemplate;

import com.thoughtworks.test.ch1.model.Input;
import com.thoughtworks.test.ch4.model.Challenge4Input;
import com.thoughtworks.test.ch4.model.Challenge4Output;

public class Challenge4 {

	public static void getInput() {
		RestTemplate restTemplate = new RestTemplate();
        restTemplate.getMessageConverters().add(new MappingJackson2HttpMessageConverter());
        restTemplate.getMessageConverters().add(new StringHttpMessageConverter());
		
        String main = "https://http-hunt.thoughtworks-labs.net/challenge/input";
        HttpHeaders headers = new HttpHeaders();
        headers.set("userId", "wWGhm4SeJ");
        headers.setContentType(MediaType.APPLICATION_JSON);
        
        HttpEntity<Input> entityReq = new HttpEntity<Input>(null, headers);
        
        ResponseEntity<Challenge4Input> respEntity = restTemplate
        	    .exchange(main, HttpMethod.GET, entityReq, Challenge4Input.class);
        
        Challenge4Input input = respEntity.getBody();
        System.out.println(input);

		System.out.println("Tools : " + input.getTools());
		System.out.println("weights : " + input.getMaximumWeight());
        
		List<String> result = Logic4.getToolsToTakeSorted(input.getTools(), input.getMaximumWeight());
		System.out.println("Tools sorted : " + result);
		sendOutput(result);
	}
	
	public static void sendOutput(List<String> tooldFound) {
		RestTemplate restTemplate = new RestTemplate();
        restTemplate.getMessageConverters().add(new MappingJackson2HttpMessageConverter());
        restTemplate.getMessageConverters().add(new StringHttpMessageConverter());
		
        String main = "https://http-hunt.thoughtworks-labs.net/challenge/output";
        HttpHeaders headers = new HttpHeaders();
        headers.set("userId", "wWGhm4SeJ");
        headers.setContentType(MediaType.APPLICATION_JSON);
        
        Challenge4Output output = new Challenge4Output();
        output.setToolsToTakeSorted(tooldFound);
        HttpEntity<Challenge4Output> entityReq = new HttpEntity<Challenge4Output>(output, headers);
        
        ResponseEntity<String> respEntity = restTemplate
        	    .exchange(main, HttpMethod.POST, entityReq, String.class);
        
        System.out.println("Message : " + respEntity.getBody());
	}
}
