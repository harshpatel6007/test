package com.thoughtworks.test;

import java.util.List;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.StringHttpMessageConverter;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.web.client.RestTemplate;

import com.thoughtworks.test.ch1.model.MainInput;
import com.thoughtworks.test.challenge4.Challenge4;
import com.thoughtworks.test.challenge4.Logic4;

@SpringBootApplication
public class ThoughtWorksTestApplication {

	public static void main(String[] args) {
		SpringApplication.run(ThoughtWorksTestApplication.class, args);
//		getAndDecryptMessage();
		Challenge4.getInput();
	}

	private static void getAndDecryptMessage() {
		RestTemplate restTemplate = new RestTemplate();
		restTemplate.getMessageConverters().add(new MappingJackson2HttpMessageConverter());
		restTemplate.getMessageConverters().add(new StringHttpMessageConverter());

		String main = "https://http-hunt.thoughtworks-labs.net/challenge";
		HttpHeaders headers = new HttpHeaders();
		headers.set("userId", "wWGhm4SeJ");
		headers.setContentType(MediaType.APPLICATION_JSON);

		HttpEntity<MainInput> entityReq = new HttpEntity<MainInput>(null, headers);

		ResponseEntity<MainInput> respEntity = restTemplate.exchange(main, HttpMethod.GET, entityReq, MainInput.class);

		MainInput input = respEntity.getBody();
		System.out.println(input);

		System.out.println("Tools : " + input.getSampleInput().getInput().getTools());
		System.out.println("weights : " + input.getSampleInput().getInput().getMaximumWeight());
		
		List<String> result = Logic4.getToolsToTakeSorted(input.getSampleInput().getInput().getTools(), input.getSampleInput().getInput().getMaximumWeight());
		System.out.println("Result : " + result);
		Challenge4.sendOutput(result);
	}
	
	
	
}
