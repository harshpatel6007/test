package com.thoughtworks.test.ch1.model;

public class Output {

	private String message;

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	@Override
	public String toString() {
		return "Output [message=" + message + "]";
	}
	
}
