package com.thoughtworks.test.ch4.model;

import java.util.Comparator;

public class WeightComparator implements Comparator<Tool>{

	@Override
	public int compare(Tool o1, Tool o2) {
		return o2.getWeight().compareTo(o1.getWeight());
	}

}
