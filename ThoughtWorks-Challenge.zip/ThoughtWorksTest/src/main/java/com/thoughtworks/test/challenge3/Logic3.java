package com.thoughtworks.test.challenge3;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import com.thoughtworks.test.ch3.model.ToolUsage;
import com.thoughtworks.test.ch3.model.ToolUsageTime;

public class Logic3 {

	private static SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss"); 
	
	public static List<ToolUsage> getToolsByHighUsage(List<ToolUsageTime> toolUsage) throws ParseException {
		Map<String, Long> map = new HashMap<>();
		for(ToolUsageTime usageTime : toolUsage) {
			String name = usageTime.getName();
			Date start = dateFormat.parse(usageTime.getUseStartTime());
			Date end = dateFormat.parse(usageTime.getUseEndTime());
			long mins = (end.getTime() - start.getTime()) / (1000 * 60);
			if(map.get(name) == null) {
				map.put(name, mins);
			} else {
				map.put(name, map.get(name) + mins);
			}
		}
		List<ToolUsage> list = new ArrayList<>();
		for(Entry<String, Long> entry : map.entrySet()) {
			ToolUsage usage = new ToolUsage();
			usage.setName(entry.getKey());
			usage.setTimeUsedInMinutes(entry.getValue());
			list.add(usage);
		}
		Collections.sort(list);
		return list;
	}

	public static void main(String[] args) throws ParseException {
		Date d1 = dateFormat.parse("2017-01-30 10:15:00") ;
		Date d2 = dateFormat.parse("2017-01-30 10:20:00");
		
		long mins = (d2.getTime() - d1.getTime()) / (1000 * 60);
		System.out.println("mins" + mins);
	}
}
