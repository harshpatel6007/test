package com.thoughtworks.test.ch4.model;

import java.util.Comparator;
import java.util.List;

public class CompositeComparator implements Comparator<Tool> {

	private List<Comparator<Tool>> list;
	
	public CompositeComparator(List<Comparator<Tool>> comparators) {
		this.list = comparators;
	}

	@Override
	public int compare(Tool o1, Tool o2) {
		for(Comparator<Tool> comparator : list) {
			int value = comparator.compare(o1, o2);
			if(value != 0) {
				return value;
			} 
		}
		return 0;
		
	}
	
	
}
