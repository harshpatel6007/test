package com.thoughtworks.test.ch1.model;

public class Input {

	private String encryptedMessage;
	private int key;
	
	public String getEncryptedMessage() {
		return encryptedMessage;
	}
	public void setEncryptedMessage(String encryptedMessage) {
		this.encryptedMessage = encryptedMessage;
	}
	public int getKey() {
		return key;
	}
	public void setKey(int key) {
		this.key = key;
	}

	@Override
	public String toString() {
		return "Input [encryptedMessage=" + encryptedMessage + ", key=" + key + "]";
	}
}
