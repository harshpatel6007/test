package com.thoughtworks.test.ch3.model;

public class ToolUsage implements Comparable<ToolUsage> {

	private String name;
	private Long timeUsedInMinutes = 0l;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Long getTimeUsedInMinutes() {
		return timeUsedInMinutes;
	}
	public void setTimeUsedInMinutes(Long timeUsedInMinutes) {
		this.timeUsedInMinutes = timeUsedInMinutes;
	}

	@Override
	public String toString() {
		return "ToolUsage [name=" + name + ", timeUsedInMinutes=" + timeUsedInMinutes + "]";
	}
	@Override
	public int compareTo(ToolUsage o) {
		return o.getTimeUsedInMinutes().compareTo(timeUsedInMinutes);
	}
	
}
