package com.thoughtworks.test.ch4.model;

import java.util.List;

public class Challenge4Input {

	private List<Tool> tools;
	private long maximumWeight;
	
	public List<Tool> getTools() {
		return tools;
	}
	public void setTools(List<Tool> tools) {
		this.tools = tools;
	}
	public long getMaximumWeight() {
		return maximumWeight;
	}
	public void setMaximumWeight(long maximumWeight) {
		this.maximumWeight = maximumWeight;
	}

	@Override
	public String toString() {
		return "Challenge4Output [tools=" + tools + ", maximumWeight=" + maximumWeight + "]";
	}
	
}
