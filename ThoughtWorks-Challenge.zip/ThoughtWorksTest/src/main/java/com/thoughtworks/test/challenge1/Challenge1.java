package com.thoughtworks.test.challenge1;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.StringHttpMessageConverter;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.web.client.RestTemplate;

import com.thoughtworks.test.ch1.model.Input;
import com.thoughtworks.test.ch1.model.Output;

public class Challenge1 {

	public static void getInput() {
		RestTemplate restTemplate = new RestTemplate();
        restTemplate.getMessageConverters().add(new MappingJackson2HttpMessageConverter());
        restTemplate.getMessageConverters().add(new StringHttpMessageConverter());
		
        String main = "https://http-hunt.thoughtworks-labs.net/challenge/input";
        HttpHeaders headers = new HttpHeaders();
        headers.set("userId", "wWGhm4SeJ");
        headers.setContentType(MediaType.APPLICATION_JSON);
        
        HttpEntity<Input> entityReq = new HttpEntity<Input>(null, headers);
        
        ResponseEntity<Input> respEntity = restTemplate
        	    .exchange(main, HttpMethod.GET, entityReq, Input.class);
        
        Input input = respEntity.getBody();
        System.out.println(input);
        
        System.out.println("Message : " + input.getEncryptedMessage());
        
        String message = LogicalTest.decryptString(input.getEncryptedMessage(), input.getKey());
        System.out.println("Decrepetd Message : " + message);
        
        sendOutput(message);
	}
	
	private static void sendOutput(String message) {
		RestTemplate restTemplate = new RestTemplate();
        restTemplate.getMessageConverters().add(new MappingJackson2HttpMessageConverter());
        restTemplate.getMessageConverters().add(new StringHttpMessageConverter());
		
        String main = "https://http-hunt.thoughtworks-labs.net/challenge/output";
        HttpHeaders headers = new HttpHeaders();
        headers.set("userId", "wWGhm4SeJ");
        headers.setContentType(MediaType.APPLICATION_JSON);
        
        Output output = new Output();
        output.setMessage(message);
        HttpEntity<Output> entityReq = new HttpEntity<Output>(output, headers);
        
        ResponseEntity<String> respEntity = restTemplate
        	    .exchange(main, HttpMethod.POST, entityReq, String.class);
        
        System.out.println("Message : " + respEntity.getBody());
	}


}
