package com.thoughtworks.test.challenge2;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Logic2 {

	public static void main(String[] args) {
		String input = "opekandifehgujnsr";
		List<String> tools = Arrays.asList("knife", "guns", "rope");
		
		List<String> res = getTools(input, tools);
		System.out.println(res);
	}

	public static List<String> getTools(String input, List<String> tools) {
		List<String> list = new ArrayList<>();
		for(String tool : tools) {
			if(isToolexists(input, tool)) {
				list.add(tool);
			}
		}
		return list;
	}

	private static boolean isToolexists(String input, String tool) {
		int index = 0;
		for(char ch : tool.toCharArray()) {
			if((index = input.indexOf(ch, index)) < 0) {
				return false;
			}
		}
		return true;
	}
}
