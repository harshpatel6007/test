package com.thoughtworks.test.ch2.model;

import java.util.List;

public class Challenge2Input {

	private String hiddenTools;
	private List<String> tools;

	public String getHiddenTools() {
		return hiddenTools;
	}
	public void setHiddenTools(String hiddenTools) {
		this.hiddenTools = hiddenTools;
	}
	public List<String> getTools() {
		return tools;
	}
	public void setTools(List<String> tools) {
		this.tools = tools;
	}
	
	@Override
	public String toString() {
		return "Challenge2Input [hiddenTools=" + hiddenTools + ", tools=" + tools + "]";
	}
	
}
