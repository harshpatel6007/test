package com.thoughtworks.test.ch1.model;

import com.thoughtworks.test.ch4.model.Challenge4Input;

public class SampleInput {

	private Challenge4Input input;

	public Challenge4Input getInput() {
		return input;
	}

	public void setInput(Challenge4Input input) {
		this.input = input;
	}

	@Override
	public String toString() {
		return "SampleInput [input=" + input + "]";
	}

	
	
}
