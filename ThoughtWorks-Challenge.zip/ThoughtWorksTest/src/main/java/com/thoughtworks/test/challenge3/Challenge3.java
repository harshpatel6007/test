package com.thoughtworks.test.challenge3;

import java.text.ParseException;
import java.util.List;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.StringHttpMessageConverter;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.web.client.RestTemplate;

import com.thoughtworks.test.ch1.model.Input;
import com.thoughtworks.test.ch3.model.Challenge3Input;
import com.thoughtworks.test.ch3.model.Challenge3Output;
import com.thoughtworks.test.ch3.model.ToolUsage;

public class Challenge3 {

	public static void getInput() {
		RestTemplate restTemplate = new RestTemplate();
        restTemplate.getMessageConverters().add(new MappingJackson2HttpMessageConverter());
        restTemplate.getMessageConverters().add(new StringHttpMessageConverter());
		
        String main = "https://http-hunt.thoughtworks-labs.net/challenge/input";
        HttpHeaders headers = new HttpHeaders();
        headers.set("userId", "wWGhm4SeJ");
        headers.setContentType(MediaType.APPLICATION_JSON);
        
        HttpEntity<Input> entityReq = new HttpEntity<Input>(null, headers);
        
        ResponseEntity<Challenge3Input> respEntity = restTemplate
        	    .exchange(main, HttpMethod.GET, entityReq, Challenge3Input.class);
        
        Challenge3Input input = respEntity.getBody();
        System.out.println(input);
        
        System.out.println("Tool Usages : " + input.getToolUsage());
        
        List<ToolUsage> tooldFound;
		try {
			tooldFound = Logic3.getToolsByHighUsage(input.getToolUsage());
			System.out.println("Tool Usages Output : " + tooldFound);
			sendOutput(tooldFound);
		} catch (ParseException e) {
			e.printStackTrace();
		}
	}
	
	public static void sendOutput(List<ToolUsage> tooldFound) {
		RestTemplate restTemplate = new RestTemplate();
        restTemplate.getMessageConverters().add(new MappingJackson2HttpMessageConverter());
        restTemplate.getMessageConverters().add(new StringHttpMessageConverter());
		
        String main = "https://http-hunt.thoughtworks-labs.net/challenge/output";
        HttpHeaders headers = new HttpHeaders();
        headers.set("userId", "wWGhm4SeJ");
        headers.setContentType(MediaType.APPLICATION_JSON);
        
        Challenge3Output output = new Challenge3Output();
        output.setToolsSortedOnUsage(tooldFound);
        HttpEntity<Challenge3Output> entityReq = new HttpEntity<Challenge3Output>(output, headers);
        
        ResponseEntity<String> respEntity = restTemplate
        	    .exchange(main, HttpMethod.POST, entityReq, String.class);
        
        System.out.println("Message : " + respEntity.getBody());
	}
}
