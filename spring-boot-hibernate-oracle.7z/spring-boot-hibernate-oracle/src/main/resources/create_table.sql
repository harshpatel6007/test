create table CUSTOMER (
  ID NUMBER(19,0) NOT NULL,
	CUSTOMERNAME VARCHAR2(100),
	EMAIL VARCHAR2(200),
  REGISTERED_DATE timestamp,
	CREATED_DATE TIMESTAMP,
  CREATED_BY VARCHAR2(10),
  MODIFIED_DATE TIMESTAMP,
  MODIFIED_BY VARCHAR2(10),
  PRIMARY KEY(ID)
);

create table ADDRESS (
  ID NUMBER(19,0) NOT NULL,
  HOUSE_NUMBER VARCHAR2(30),
  STREET VARCHAR2(100),
  AREA VARCHAR2(100),
  CITY VARCHAR2(100),
  STATE VARCHAR2(100),
  COUNTRY VARCHAR2(100),
  PINCODE VARCHAR2(10),
  PRIMARY KEY(ID)
);

--remove all table except address and customer from database
--set serveroutput on format word_wrapped;
declare     
  cursor c1 is 
    select tname from tab where tabtype = 'TABLE';
begin
  for recrd in c1 LOOP    
    if recrd.tname not in('CUSTOMER', 'ADDRESS') then
        execute immediate 'drop table ' || recrd.tname || ' cascade constraints ';
    else
        dbms_output.put_line('table name : ' || recrd.tname || ' not delete');
    end if;
  end LOOP;
end;