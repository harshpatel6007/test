package com.harsh.hibernate.message;

public class CommonSubstitute {

	public static final String DEFAULT_LOGGED_USER = "System";
}
