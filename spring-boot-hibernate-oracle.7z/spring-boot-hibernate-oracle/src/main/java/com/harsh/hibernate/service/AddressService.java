package com.harsh.hibernate.service;

public interface AddressService {

}
