package com.harsh.hibernate.service.impl;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.harsh.hibernate.dao.CustomerDao;
import com.harsh.hibernate.entity.Customer;
import com.harsh.hibernate.service.CustomerService;

@Service
public class CustomerServiceImpl implements CustomerService {

	@Autowired
	EntityManager entityManager;
	
	@Autowired
	CustomerDao customerDao;
	
	@SuppressWarnings("unchecked")
	@Override
	public List<Customer> searchCustomerByNameAndEmail(String custName, String email) {
		String queryString = "from Customer where customerName = :custName and email = :email";
		Query query = entityManager.createQuery(queryString).setParameter("custName", custName);
		query.setParameter("email", email);
		query.setParameter("custName", custName);
		return query.getResultList();
	}

	
}
