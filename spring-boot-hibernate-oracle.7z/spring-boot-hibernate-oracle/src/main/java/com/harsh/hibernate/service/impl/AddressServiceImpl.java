package com.harsh.hibernate.service.impl;

import org.springframework.stereotype.Service;

import com.harsh.hibernate.service.AddressService;

@Service
public class AddressServiceImpl implements AddressService {

}
