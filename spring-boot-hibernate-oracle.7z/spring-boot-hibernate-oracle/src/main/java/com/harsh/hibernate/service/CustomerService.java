package com.harsh.hibernate.service;

import java.util.List;

import com.harsh.hibernate.entity.Customer;

public interface CustomerService {

	public List<Customer> searchCustomerByNameAndEmail(String custName, String email);
}
