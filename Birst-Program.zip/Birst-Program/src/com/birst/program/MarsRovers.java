package com.birst.program;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class MarsRovers {

	//validation messages
	private static final String INVALID_INITIAL_POSITION = "Initial Direction is not proper";
	private static final String DIRECTION_PATH_INVALID_CHARACTERS = "Direction path contains direction other than L, M or R";
	private static final String SPACE_NOT_EXISTS = "Input is not separated by space and must be of length greater than ";
	private static final String NEGATIVES_IN_INPUT = "Input is null or containes negative integers whihc are not allowed as per assumption of input";
	private static final String ROVER_INITIAL_POSITION_IS_NOT_CORRECT = "Rover initial position is not correct";
	private static final String INVALID_DIRECTION_PATH = "Rover moving outside of surface, Direction path is not valid";
	private static final String INVALID_INPUT = "Invalid Input";
	
	private static String FILE_PATH = "E:/workspace/java-practice/Birst-Program/input.txt";//define input file path here
	private static final Map<Character, Character> leftDir = new HashMap<>();
	private static final Map<Character, Character> rightDir = new HashMap<>();

	//stores data to get new direction when we move left or right
	static {
		leftDir.put('N', 'W');
		leftDir.put('S', 'E');
		leftDir.put('E', 'N');
		leftDir.put('W', 'S');
		
		rightDir.put('N', 'E');
		rightDir.put('S', 'W');
		rightDir.put('E', 'S');
		rightDir.put('W', 'N');
	}
	
	private static void setFilePath(String path) {
		FILE_PATH = path;
	}
	
	/**
	 * Test code with different scenarios
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		String folder = "E:/workspace/java-practice/Birst-Program/";
		//Proper Input
		System.out.println(findPositionOfRover());

		//Empty file Error
		setFilePath(folder + "invalid_input1.txt");
		System.out.println(findPositionOfRover());
		
		//negative co ordinates
		setFilePath(folder + "invalid_input2.txt");
		System.out.println(findPositionOfRover());
		
		//wrong current position
		setFilePath(folder + "invalid_input3.txt");
		System.out.println(findPositionOfRover());
		
		//wrong moving position 
		setFilePath(folder + "invalid_input4.txt");
		System.out.println(findPositionOfRover());
	}

	/**
	 * read  and validate input
	 * 
	 * @return
	 */
	private static String findPositionOfRover() {

		File file = new File(FILE_PATH);
		BufferedReader br = null;
		try {
			br = new BufferedReader(new FileReader(file));

			int platX = 0, platY = 0;
			int rover1X = 0, rover1Y = 0;
			String rover1Path = null, rover2Path = null, rover1CurrDir = null, rover2CurrDir = null;
			int rover2X = 0, rover2Y = 0;
			
			String line = br.readLine();
//			System.out.println("Line : " + line);
			validateString(line, 3);
			
			String[] coordinatesOfPlatue = line.split(" ");
			platX = Integer.parseInt(coordinatesOfPlatue[0]);
			platY = Integer.parseInt(coordinatesOfPlatue[1]);
			
			line = br.readLine();
			validateString(line, 5);
			String[] roverInitPos = line.split(" ");
			validateArraySize(roverInitPos, 3);
			rover1X = Integer.parseInt(roverInitPos[0]);
			rover1Y = Integer.parseInt(roverInitPos[1]);
			rover1CurrDir = roverInitPos[2];
			validateDirection(rover1CurrDir);
		
			rover1Path = br.readLine();
			validatePath(rover1Path);
			
			line = br.readLine();
			validateString(line, 5);
			String[] rover2InitPos = line.split(" ");
			validateArraySize(rover2InitPos, 3);
			rover2X = Integer.parseInt(rover2InitPos[0]);
			rover2Y = Integer.parseInt(rover2InitPos[1]);
			rover2CurrDir = rover2InitPos[2];
			validateDirection(rover2CurrDir);
			
			rover2Path = br.readLine();
			validatePath(rover2Path);
			
//			System.out.println("Plat x : " + platX + " Plat Y : " + platY);
//			System.out.println("Rover 1, x : " + rover1X + " y : " + rover1Y + " dir : " + rover1CurrDir + " path : " + rover1Path);
//			System.out.println("Rover 2, x : " + rover2X + " y : " + rover2Y + " dir : " + rover2CurrDir + " path : " + rover2Path);
			
			getFinalPositionOfRover(rover1X, rover1Y, rover1CurrDir, rover1Path, platX, platY);
			getFinalPositionOfRover(rover2X, rover2Y, rover2CurrDir, rover2Path, platX, platY);
			
		} catch (FileNotFoundException e) {
			//should never happen
			e.printStackTrace();
		} catch (IOException e) {
			//happen when no of lines are less than required(5 in our case)
			return INVALID_INPUT;
		} catch (IllegalArgumentException e) {
			//Validation error
			return e.getMessage();
		}
		finally {
			if(br != null) {
				try {
					br.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
		return "";
	}

	/**
	 * Print final position of rover
	 * 
	 * @param x
	 * @param y
	 * @param position
	 * @param path
	 * @param platX
	 * @param platY
	 */
	private static void getFinalPositionOfRover(int x, int y, String position, String path, int platX, int platY) {
		
		Character currentPosition = position.charAt(0);
		
		for(Character ch : path.toCharArray()) {
			switch (ch) {
			case 'L':
				//change current position - move to left
				currentPosition = leftDir.get(currentPosition);
				break;
			case 'M':
				//increment/decrement x or y co ordinate as per current position
				if(currentPosition == 'N') {
					y++;
				}
				else if(currentPosition == 'S') {
					y--;
				}
				else if(currentPosition == 'E') {
					x++;
				}
				else {
					x--;
				}
				break;
			case 'R':
				//change current position - move to right
				currentPosition = rightDir.get(currentPosition);
				break;
			default:
				//do nothing
				break;
			}
			
			//check reach at the border of surface
			if(platX > 0 && x > platX) throw new IllegalArgumentException(INVALID_DIRECTION_PATH);
			if(platY > 0 && y > platY) throw new IllegalArgumentException(INVALID_DIRECTION_PATH);
		}
		
		System.out.println(x + " " + y + " " + currentPosition);
	}

	/**
	 * validate array size
	 * 
	 * @param roverInitPos
	 * @param i
	 */
	private static void validateArraySize(String[] roverInitPos, int i) {
		if(roverInitPos.length != i) {
			throw new IllegalArgumentException(ROVER_INITIAL_POSITION_IS_NOT_CORRECT);
		}		
	}

	/**
	 * Check space and negative integers in string
	 * 
	 * @param input
	 * @param i
	 */
	private static void validateString(String input, int i) {
		//negative integers are not allowed as per assumption of of input
		if(input == null || input.contains("-")) {
			throw new IllegalArgumentException(NEGATIVES_IN_INPUT);
		}
		if(input.length() < i || !input.contains(" ")) {
			throw new IllegalArgumentException(SPACE_NOT_EXISTS + i);
		}
	}
	
	/**
	 * check valid characters for Moving direction
	 * 
	 * @param rover1Path
	 */
	private static void validatePath(String rover1Path) {
		if(!rover1Path.matches("[LMR]+")) {
			throw new IllegalArgumentException(DIRECTION_PATH_INVALID_CHARACTERS);
		}
	}
	
	/**
	 * check valid direction
	 * 
	 * @param rover2CurrDir
	 */
	private static void validateDirection(String rover2CurrDir) {
		if(!rover2CurrDir.matches("[NSEW]")) {
			throw new IllegalArgumentException(INVALID_INITIAL_POSITION);
		}
	}
}
